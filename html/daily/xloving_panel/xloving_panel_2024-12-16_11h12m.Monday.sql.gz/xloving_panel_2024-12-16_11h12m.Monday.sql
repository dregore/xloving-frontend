-- MariaDB dump 10.19  Distrib 10.11.6-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: db2    Database: xloving_panel
-- ------------------------------------------------------
-- Server version	8.4.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `xloving_panel`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `xloving_panel` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_bin */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `xloving_panel`;

--
-- Table structure for table `cache`
--

DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache` (
  `key` varchar(255) NOT NULL,
  `value` mediumtext NOT NULL,
  `expiration` int NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache`
--

LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_locks`
--

DROP TABLE IF EXISTS `cache_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_locks` (
  `key` varchar(255) NOT NULL,
  `owner` varchar(255) NOT NULL,
  `expiration` int NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_locks`
--

LOCK TABLES `cache_locks` WRITE;
/*!40000 ALTER TABLE `cache_locks` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_locks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_batches`
--

DROP TABLE IF EXISTS `job_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `job_batches` (
  `id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `total_jobs` int NOT NULL,
  `pending_jobs` int NOT NULL,
  `failed_jobs` int NOT NULL,
  `failed_job_ids` longtext NOT NULL,
  `options` mediumtext,
  `cancelled_at` int DEFAULT NULL,
  `created_at` int NOT NULL,
  `finished_at` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_batches`
--

LOCK TABLES `job_batches` WRITE;
/*!40000 ALTER TABLE `job_batches` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_batches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) NOT NULL,
  `payload` longtext NOT NULL,
  `attempts` tinyint unsigned NOT NULL,
  `reserved_at` int unsigned DEFAULT NULL,
  `available_at` int unsigned NOT NULL,
  `created_at` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES
(1,'0001_01_01_000000_create_users_table',1),
(2,'0001_01_01_000001_create_cache_table',1),
(3,'0001_01_01_000002_create_jobs_table',1),
(4,'2024_08_12_112610_create_orders_table',2),
(5,'2024_08_13_090506_update_orders_table',3),
(6,'2024_09_03_103125_update_orders_table',4),
(7,'2024_10_31_103740_update_orders_table',5),
(8,'2024_10_31_122026_update_orders_table',6),
(9,'2024_10_31_124229_update_orders_table',7),
(10,'2024_11_18_154802_create_telescope_entries_table',8),
(11,'2024_11_19_091958_update_orders_table',9);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `orders` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL DEFAULT 'install',
  `attempts` int NOT NULL DEFAULT '3',
  `delay_min` int NOT NULL DEFAULT '0',
  `delay_max` int NOT NULL DEFAULT '0',
  `delete` tinyint(1) NOT NULL DEFAULT '0',
  `url` varchar(255) DEFAULT NULL,
  `minutes` int NOT NULL DEFAULT '0',
  `seconds` int NOT NULL DEFAULT '0',
  `like` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `app_name` text,
  `app_bundle` text,
  `amount` int DEFAULT '1',
  `retention` varchar(255) NOT NULL DEFAULT '0',
  `country` varchar(255) DEFAULT 'any',
  `fill_type` varchar(255) DEFAULT 'fast',
  `open_time` varchar(255) DEFAULT '5 - 10',
  `share` tinyint DEFAULT '0',
  `deeplink_page` tinyint DEFAULT '0',
  `scroll_duration` int DEFAULT '30',
  `search_term` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=482 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
INSERT INTO `orders` VALUES
(3,'install',3,1,4,0,NULL,1,23,0,'2024-08-12 12:48:16','2024-09-17 14:33:50','2024-09-17 14:33:50','rgregreg','ergregreg',1,'0','any','fast','5 - 10',0,0,30,NULL),
(4,'tiktok',3,1,4,1,NULL,1,23,1,'2024-08-12 13:41:03','2024-09-17 14:33:51','2024-09-17 14:33:51',NULL,NULL,6,'0','any','fast','5 - 10',0,0,30,NULL),
(5,'tiktok',3,1,4,1,NULL,1,23,1,'2024-08-12 13:44:10','2024-09-17 14:33:52','2024-09-17 14:33:52',NULL,NULL,5,'0','any','fast','5 - 10',0,0,30,NULL),
(6,'tiktok',3,1,4,1,NULL,1,23,1,'2024-08-12 13:48:03','2024-09-17 14:33:53','2024-09-17 14:33:53',NULL,NULL,6,'0','any','fast','5 - 10',0,0,30,NULL),
(7,'tiktok',3,1,4,1,NULL,1,23,1,'2024-08-12 13:55:02','2024-09-17 14:33:54','2024-09-17 14:33:54',NULL,NULL,3,'0','any','fast','5 - 10',0,0,30,NULL),
(8,'tiktok',3,1,4,1,NULL,1,23,1,'2024-08-12 13:56:10','2024-09-17 14:33:55','2024-09-17 14:33:55',NULL,NULL,3,'0','any','fast','5 - 10',0,0,30,NULL),
(9,'tiktok',3,1,4,1,NULL,1,23,1,'2024-08-12 13:57:26','2024-09-17 14:33:56','2024-09-17 14:33:56',NULL,NULL,3,'0','any','fast','5 - 10',0,0,30,NULL),
(13,'install',3,1,4,1,NULL,1,23,1,'2024-08-13 10:37:06','2024-09-17 14:33:57','2024-09-17 14:33:57',NULL,NULL,2,'1','any','fast',NULL,1,0,30,NULL),
(14,'install',3,1,4,1,NULL,1,23,1,'2024-08-13 11:00:45','2024-09-17 14:33:58','2024-09-17 14:33:58','fdgfdgdfg','dfgfdgfdgdfg',1,'1','any','fast',NULL,1,0,30,NULL),
(15,'install',3,1,4,0,NULL,1,23,1,'2024-08-13 11:02:07','2024-09-17 14:33:59','2024-09-17 14:33:59','ewfewfew','ewfewf.ewf.ewfewf',1,'1','any','fast',NULL,1,0,30,NULL),
(16,'install',3,1,4,1,NULL,1,23,1,'2024-08-13 11:03:50','2024-09-17 14:34:01','2024-09-17 14:34:01','Live Wallpapers, 4K Wallpapers','hd.uhd.live.wallpapers.topwallpapers',1,'1','any','fast',NULL,1,0,30,NULL),
(17,'install',3,1,4,1,NULL,1,23,1,'2024-08-13 11:47:02','2024-09-17 14:34:02','2024-09-17 14:34:02','fgfdgdfg','thyh6565h',1,'1','any','fast',NULL,1,0,30,NULL),
(18,'install',3,1,4,1,NULL,1,23,1,'2024-08-13 11:47:32','2024-09-17 14:34:03','2024-09-17 14:34:03','11111','232.232.232',1,'1','any','fast',NULL,1,0,30,NULL),
(19,'tiktok',3,1,4,1,NULL,1,23,1,'2024-08-13 11:48:03','2024-09-17 14:34:04','2024-09-17 14:34:04',NULL,NULL,1,'1','any','fast',NULL,1,0,30,NULL),
(20,'tiktok',3,1,4,1,NULL,1,23,1,'2024-08-13 14:11:37','2024-09-17 14:34:05','2024-09-17 14:34:05',NULL,NULL,5,'1','any','fast',NULL,0,0,30,NULL),
(21,'youtube',3,1,4,1,'https://www.tiktok.com/@hajrovicellmaa/video/7390774794104442118',1,23,1,'2024-08-13 14:12:28','2024-09-17 14:34:06','2024-09-17 14:34:06',NULL,NULL,1,'1','any','fast',NULL,1,0,30,NULL),
(22,'install',3,1,4,1,NULL,1,23,1,'2024-08-13 15:53:41','2024-09-17 14:34:07','2024-09-17 14:34:07','Avatar World','https://play.google.com/store/apps/details?id=com.pazugames.avatarworld',3,'1','any','fast',NULL,1,0,30,NULL),
(23,'install',3,1,4,1,NULL,1,23,1,'2024-08-13 15:57:03','2024-09-17 14:34:08','2024-09-17 14:34:08','Avatar World','https://play.google.com/store/apps/details?id=com.pazugames.avatarworld',1,'1','any','fast',NULL,1,0,30,NULL),
(24,'install',3,1,4,1,NULL,1,23,1,'2024-08-13 15:57:42','2024-09-17 14:34:09','2024-09-17 14:34:09','Avatar World','https://play.google.com/store/apps/details?id=com.pazugames.avatarworld',3,'1','any','fast',NULL,1,0,30,NULL),
(25,'install',3,1,4,1,NULL,1,23,1,'2024-08-13 16:00:50','2024-09-17 14:34:10','2024-09-17 14:34:10','Avatar World','https://play.google.com/store/apps/details?id=com.pazugames.avatarworld',2,'1','any','fast',NULL,1,0,30,NULL),
(26,'install',3,1,4,1,NULL,1,23,1,'2024-08-13 16:04:20','2024-09-17 14:34:11','2024-09-17 14:34:11','Avatar World','https://play.google.com/store/apps/details?id=com.pazugames.avatarworld',2,'1','any','fast',NULL,1,0,30,NULL),
(27,'install',3,1,4,1,NULL,1,23,1,'2024-08-13 16:08:56','2024-09-17 14:34:12','2024-09-17 14:34:12','ZINIO - Magazine Newsstand','com.zinio.mobile.android.reader',1,'1','any','fast',NULL,1,0,30,NULL),
(28,'tiktok',3,1,4,1,NULL,1,23,1,'2024-08-14 08:05:59','2024-09-17 14:34:13','2024-09-17 14:34:13',NULL,NULL,1,'1','any','fast',NULL,1,0,30,NULL),
(29,'tiktok',3,1,4,1,NULL,1,23,1,'2024-08-14 09:03:57','2024-09-17 14:34:14','2024-09-17 14:34:14',NULL,NULL,1,'1','CR','fast',NULL,0,0,30,NULL),
(30,'tiktok',3,1,4,1,'https://www.tiktok.com/@hajrovicellmaa/video/7390774794104442118',1,23,0,'2024-08-14 09:12:16','2024-09-17 14:34:15','2024-09-17 14:34:15',NULL,NULL,1,'1','any','fast',NULL,0,0,30,NULL),
(31,'youtube',2,2,5,1,'https://www.youtube.com/watch?v=sZxaOqn00Is',3,21,0,'2024-08-14 09:13:16','2024-09-17 14:34:20','2024-09-17 14:34:20',NULL,NULL,2,'1','AR','fast',NULL,1,0,30,NULL),
(32,'youtube',3,1,4,1,'https://www.youtube.com/watch?v=Iolscfq2K84',1,23,1,'2024-08-14 11:34:39','2024-09-17 14:34:21','2024-09-17 14:34:21',NULL,NULL,1,'1','any','fast',NULL,1,0,30,NULL),
(33,'youtube',3,1,4,1,'https://www.youtube.com/watch?v=7LwlV0nxIj8',0,15,1,'2024-08-18 13:57:55','2024-09-17 14:34:22','2024-09-17 14:34:22',NULL,NULL,3,'1','any','fast',NULL,1,0,30,NULL),
(34,'install',3,1,4,1,NULL,0,23,0,'2024-08-26 07:48:05','2024-09-17 14:34:23','2024-09-17 14:34:23','Taxi Millionaire','com.HappyLobster.TaxiMilionaire',30,'1','any','fast',NULL,1,0,30,NULL),
(36,'install',3,1,4,1,NULL,0,23,0,'2024-08-27 12:16:48','2024-09-17 14:34:24','2024-09-17 14:34:24','Keep Balance','com.kadka.keepbalance',20,'1','any','fast',NULL,1,0,30,NULL),
(37,'install',3,1,4,1,NULL,0,23,0,'2024-08-27 12:18:34','2024-09-17 14:34:25','2024-09-17 14:34:25','Keep Balance','com.kadka.keepbalance',20,'1','any','fast',NULL,1,0,30,NULL),
(38,'install',3,1,4,1,NULL,0,23,0,'2024-08-27 13:12:19','2024-09-17 14:34:27','2024-09-17 14:34:27','Bullet Armageddon','bullet.armageddon',20,'1','any','fast',NULL,1,0,30,NULL),
(39,'install',2,1,4,1,NULL,0,23,0,'2024-08-28 07:30:10','2024-09-17 14:34:28','2024-09-17 14:34:28','Mecha Operator','com.NinthPlanet.MechaOperator',30,'1','any','fast',NULL,1,0,30,NULL),
(40,'install',3,1,4,1,NULL,0,23,0,'2024-08-28 07:30:36','2024-09-17 14:34:29','2024-09-17 14:34:29','Counter Squad Online','counter.squad.online',30,'1','any','fast',NULL,1,0,30,NULL),
(41,'install',2,1,4,1,NULL,0,23,0,'2024-08-28 07:50:12','2024-09-17 14:34:30','2024-09-17 14:34:30','Cereal Collector','com.HappyLobster.CerealCollector',30,'1','any','fast',NULL,1,0,30,NULL),
(42,'install',2,1,4,1,NULL,0,23,0,'2024-08-28 09:15:28','2024-09-17 14:34:31','2024-09-17 14:34:31','Cereal Collector','com.HappyLobster.CerealCollector',40,'1','any','fast',NULL,1,0,30,NULL),
(43,'install',3,1,4,1,NULL,1,23,0,'2024-08-28 13:59:46','2024-09-17 14:34:32','2024-09-17 14:34:32','Crowded Maze','com.uzum.crowdedmaze',20,'1','any','fast',NULL,1,0,30,NULL),
(44,'install',2,1,4,1,NULL,1,23,0,'2024-08-28 14:15:38','2024-09-17 14:34:33','2024-09-17 14:34:33','Egg Path','com.onemoreplay.egg.path',40,'1','any','fast',NULL,1,0,30,NULL),
(45,'install',2,1,4,0,NULL,1,23,0,'2024-08-28 14:21:34','2024-09-17 14:34:34','2024-09-17 14:34:34','Car and City','com.mugames.sportsinc',30,'1','any','fast',NULL,1,0,30,NULL),
(46,'youtube',2,1,4,1,'https://www.youtube.com/watch?v=NLwEyp1SU9Y',0,23,1,'2024-08-29 09:36:45','2024-09-17 14:34:35','2024-09-17 14:34:35',NULL,NULL,10,'1','any','fast',NULL,1,0,30,NULL),
(47,'tiktok',2,1,4,1,'https://www.tiktok.com/@blictvofficial/video/7406400918482177286',0,10,1,'2024-08-29 10:04:44','2024-09-17 14:34:36','2024-09-17 14:34:36',NULL,NULL,5,'1','any','fast',NULL,0,0,30,NULL),
(48,'install',2,1,4,1,NULL,0,23,0,'2024-08-29 11:42:26','2024-09-17 14:34:37','2024-09-17 14:34:37','Antz','com.HappyLobster.Antz',50,'1','any','fast',NULL,1,0,30,NULL),
(49,'install',2,1,4,0,NULL,0,23,0,'2024-08-30 19:26:20','2024-09-17 14:34:38','2024-09-17 14:34:38','TunnelGo','com.HappyLobster.TunnelGo',50,'1','any','fast',NULL,1,0,30,NULL),
(50,'install',2,1,4,0,NULL,0,23,0,'2024-08-30 19:27:06','2024-09-17 14:34:39','2024-09-17 14:34:39','Balance Man','com.HappyLobster.BalanceMan',50,'1','any','fast',NULL,1,0,30,NULL),
(51,'install',2,1,4,0,NULL,1,23,0,'2024-09-01 12:10:50','2024-09-17 14:34:40','2024-09-17 14:34:40','Lovels','com.HappyLobster.LoveIs',50,'1','any','fast',NULL,1,0,30,NULL),
(52,'install',2,1,4,1,NULL,1,23,0,'2024-09-01 16:36:55','2024-09-17 14:34:41','2024-09-17 14:34:41','BagSlapper','com.HappyLobster.BagSlapper',100,'1','any','fast',NULL,1,0,30,NULL),
(53,'install',2,1,4,0,NULL,0,23,0,'2024-09-01 16:40:49','2024-09-17 14:34:42','2024-09-17 14:34:42','BagSlapper','com.HappyLobster.BagSlapper',100,'1','any','fast',NULL,1,0,30,NULL),
(54,'install',2,1,4,0,NULL,1,23,0,'2024-09-02 07:12:16','2024-09-17 14:34:43','2024-09-17 14:34:43','Fridge Master','games.coruja.fridgeMaster',100,'1','any','fast',NULL,1,0,30,NULL),
(55,'install',2,1,4,0,NULL,0,23,0,'2024-09-02 12:14:27','2024-09-17 14:34:44','2024-09-17 14:34:44','Empire Rise','games.coruja.empireRise',100,'1','any','fast',NULL,1,0,30,NULL),
(56,'install',2,1,4,0,NULL,1,23,0,'2024-09-02 12:14:57','2024-09-17 14:34:45','2024-09-17 14:34:45','Empire Rise','games.coruja.empireRise',50,'1','any','fast',NULL,1,0,30,NULL),
(57,'install',3,1,4,0,NULL,0,23,0,'2024-09-03 06:51:15','2024-09-17 14:34:50','2024-09-17 14:34:50','Hospitalizer','com.HappyLobster.Hospitalizer',100,'1','any','fast',NULL,1,0,30,NULL),
(58,'install',2,1,4,0,NULL,0,23,0,'2024-09-03 06:54:58','2024-09-17 14:34:51','2024-09-17 14:34:51','Pixel Invaders','games.coruja.pixelInvaders',100,'1','any','fast',NULL,1,0,30,NULL),
(59,'install',2,1,4,0,NULL,1,23,0,'2024-09-03 06:55:44','2024-09-17 14:34:52','2024-09-17 14:34:52','Tipsy Ball','games.coruja.tipsyBall',100,'1','any','fast',NULL,1,0,30,NULL),
(60,'install',2,1,4,0,NULL,1,23,0,'2024-09-03 06:56:39','2024-09-17 14:35:10','2024-09-17 14:35:10','Ice Melt Race','games.coruja.iceMeltRace',100,'1','any','fast',NULL,1,0,30,NULL),
(61,'install',3,1,4,1,NULL,1,23,0,'2024-09-03 10:23:41','2024-09-17 14:35:11','2024-09-17 14:35:11','wfewf','wefewfwe',1,'1','any','fast',NULL,1,1,30,NULL),
(62,'install',2,1,4,0,NULL,1,23,0,'2024-09-03 17:03:37','2024-09-17 14:35:12','2024-09-17 14:35:12','Farm Life','com.onemoreplay.farm.life',100,'1','any','fast',NULL,1,0,30,NULL),
(63,'youtube',2,1,4,1,'https://www.youtube.com/watch?v=XU7Tz77kNvQ',0,23,1,'2024-09-04 09:18:25','2024-09-17 14:35:13','2024-09-17 14:35:13',NULL,NULL,50,'1','any','fast',NULL,1,0,30,NULL),
(64,'youtube',3,1,4,1,'rgegegerg',1,23,1,'2024-09-04 10:00:59','2024-09-17 14:35:14','2024-09-17 14:35:14',NULL,NULL,1,'1','any','fast',NULL,1,0,30,NULL),
(65,'youtube',2,1,4,1,'https://youtu.be/UrKl9-OhBqEhttps://youtu.be/UrKl9-OhBqE',0,31,1,'2024-09-04 13:40:58','2024-09-17 14:35:15','2024-09-17 14:35:15',NULL,NULL,150,'1','any','fast',NULL,1,0,30,NULL),
(66,'install',2,1,4,0,NULL,1,23,0,'2024-09-05 10:40:01','2024-09-17 14:35:16','2024-09-17 14:35:16','Jump and Slash','com.winaaagame.jumpslash',50,'1','any','fast',NULL,1,0,30,NULL),
(67,'install',2,1,4,0,NULL,1,23,0,'2024-09-05 10:41:03','2024-09-17 14:35:17','2024-09-17 14:35:17','Farm Life','com.onemoreplay.farm.life',50,'1','any','fast',NULL,1,0,30,NULL),
(68,'youtube',2,1,4,1,'https://youtu.be/F8XVhxKFJKU?si=M8UYEJnJbDH1HQ-V',0,31,1,'2024-09-07 10:14:13','2024-09-17 14:35:18','2024-09-17 14:35:18',NULL,NULL,100,'1','any','fast',NULL,1,0,30,NULL),
(69,'youtube',1,1,4,1,'https://www.youtube.com/watch?v=6rir4uzbYqE',0,32,1,'2024-09-07 17:37:08','2024-09-17 14:35:19','2024-09-17 14:35:19',NULL,NULL,10,'1','any','fast',NULL,1,0,30,NULL),
(70,'youtube',1,1,4,1,'https://www.youtube.com/watch?v=3kYJF6q9k6M',0,51,1,'2024-09-07 18:07:28','2024-09-17 14:35:20','2024-09-17 14:35:20',NULL,NULL,50,'1','any','fast',NULL,1,0,30,NULL),
(71,'tiktok',2,1,4,1,'https://www.tiktok.com/@ktotyt777/video/7070829341856386306',0,10,1,'2024-09-08 14:29:32','2024-09-17 14:35:21','2024-09-17 14:35:21',NULL,NULL,5,'1','any','fast',NULL,0,0,30,NULL),
(72,'install',3,1,4,1,NULL,1,23,0,'2024-09-09 09:19:10','2024-09-10 09:50:09','2024-09-10 09:50:09','dfdsfd','sdf.sdfds.fdsf',1,'1','KZ','fast',NULL,1,0,30,NULL),
(73,'install',3,1,4,0,NULL,1,23,0,'2024-09-09 09:24:01','2024-09-10 09:57:39','2024-09-10 09:57:39','dsdsfds','sdfds.dsfds.fs',1,'1','US','fast',NULL,1,0,30,NULL),
(75,'tiktok',3,1,4,1,'https://www.tiktok.com/@ajanjes/video/7401888769634274565',0,11,1,'2024-09-09 10:18:57','2024-09-17 14:35:22','2024-09-17 14:35:22',NULL,NULL,5,'1','any','fast',NULL,0,0,30,NULL),
(76,'install',3,1,4,1,NULL,1,23,0,'2024-09-09 10:21:42','2024-09-17 14:35:23','2024-09-17 14:35:23','gfdgfd','fdgfd.fdgfd.fdgdf',1,'1','any','fast',NULL,1,0,30,NULL),
(77,'tiktok',2,1,4,1,'https://www.tiktok.com/@ajanjes/video/7401888769634274565',0,11,1,'2024-09-09 10:35:06','2024-09-17 14:35:24','2024-09-17 14:35:24',NULL,NULL,5,'1','any','fast',NULL,0,0,30,NULL),
(84,'tiktok',2,1,4,1,'https://www.tiktok.com/@callmenevenka/video/7409691137662782726',0,11,1,'2024-09-09 14:44:46','2024-09-17 14:35:25','2024-09-17 14:35:25',NULL,NULL,15,'1','any','fast',NULL,0,0,30,NULL),
(85,'tiktok',2,1,4,1,'https://www.tiktok.com/@randalainen/video/7405881954018561298',0,11,1,'2024-09-09 15:55:37','2024-09-17 14:35:26','2024-09-17 14:35:26',NULL,NULL,17,'1','any','fast',NULL,0,0,30,NULL),
(86,'tiktok',2,1,4,1,'https://www.tiktok.com/@randalainen/video/7405881954018561298',0,12,1,'2024-09-09 16:11:07','2024-09-17 14:35:27','2024-09-17 14:35:27',NULL,NULL,17,'1','any','fast',NULL,0,0,30,NULL),
(87,'tiktok',2,1,4,1,'https://www.tiktok.com/@randalainen/video/7405881954018561298',0,11,1,'2024-09-09 16:17:26','2024-09-17 14:35:28','2024-09-17 14:35:28',NULL,NULL,12,'1','any','fast',NULL,0,0,30,NULL),
(88,'install',3,1,4,1,NULL,1,23,0,'2024-09-10 09:59:57','2024-09-10 10:00:32','2024-09-10 10:00:32','3453242','rwefrew.wefwef.wfeewfwe',10,'1','any','fast',NULL,1,0,30,NULL),
(89,'install',3,1,4,1,NULL,1,23,0,'2024-09-10 10:15:36','2024-09-17 14:35:29','2024-09-17 14:35:29','ewrfeww','ewrew.ewrew.ewrewr',10,'1','any','spread',NULL,1,0,30,NULL),
(90,'tiktok',3,1,4,1,'https://example.com',1,23,1,'2024-09-10 12:46:08','2024-09-10 12:47:07','2024-09-10 12:47:07',NULL,NULL,4,'1','BG','fast',NULL,1,0,30,NULL),
(91,'tiktok',3,1,4,1,'ergergregreg',1,23,1,'2024-09-10 12:47:17','2024-09-10 12:47:41','2024-09-10 12:47:41',NULL,NULL,4,'1','any','fast',NULL,1,0,30,NULL),
(92,'tiktok',2,1,4,1,'https://www.tiktok.com/@tixyca/video/7410828874356886789',0,11,1,'2024-09-10 13:15:21','2024-09-17 14:35:30','2024-09-17 14:35:30',NULL,NULL,12,'1','any','fast',NULL,0,0,30,NULL),
(93,'tiktok',2,1,4,1,'https://www.tiktok.com/@tixyca/video/7410828874356886789',0,11,1,'2024-09-10 13:25:13','2024-09-17 14:35:31','2024-09-17 14:35:31',NULL,NULL,12,'1','any','fast',NULL,0,0,30,NULL),
(94,'tiktok',2,1,4,1,'https://www.tiktok.com/@unatelevizija/video/7411501357171051781',0,5,1,'2024-09-12 12:46:07','2024-09-17 14:35:35','2024-09-17 14:35:35',NULL,NULL,7,'1','any','fast',NULL,0,0,30,NULL),
(95,'install',3,1,4,1,NULL,1,23,0,'2024-09-17 14:41:56','2024-11-13 12:34:18','2024-11-13 12:34:18','Ice Melt Race','games.coruja.iceMeltRace',13,'1','US','fast',NULL,1,0,30,NULL),
(96,'install',3,1,4,1,NULL,1,23,0,'2024-09-18 10:27:28','2024-09-18 10:28:35','2024-09-18 10:28:35','gfhgfhfg','fgh.gfhgfh.fgh',3,'1','any','fast',NULL,1,0,30,NULL),
(97,'install',3,1,4,1,NULL,1,23,0,'2024-09-18 10:29:06','2024-09-18 10:33:36','2024-09-18 10:33:36','regtfreg','rgeeg.ergreg.eerg',3,'1','any','fast',NULL,1,0,30,NULL),
(98,'install',3,1,4,1,NULL,1,23,0,'2024-09-18 10:33:29','2024-09-18 10:33:35','2024-09-18 10:33:35','ioioi','ioi.oio.io',2,'1','any','fast',NULL,1,1,30,NULL),
(99,'youtube',2,1,4,1,'https://www.youtube.com/watch?v=radFA3TeBbU',0,23,1,'2024-09-19 11:39:01','2024-09-19 12:19:46','2024-09-19 12:19:46',NULL,NULL,20,'1','any','fast',NULL,1,0,30,NULL),
(100,'install',3,1,4,1,NULL,1,23,0,'2024-09-19 11:47:36','2024-09-19 11:50:17','2024-09-19 11:50:17','jjjj','jjj.jjj.jjj',3,'1','any','fast',NULL,1,0,30,NULL),
(101,'install',3,1,4,1,NULL,1,23,0,'2024-09-19 11:50:30','2024-09-19 11:51:00','2024-09-19 11:51:00','eee','eee.eee.eee',3,'1','any','fast',NULL,1,0,30,NULL),
(102,'install',3,1,4,1,NULL,1,23,0,'2024-09-19 11:51:10','2024-09-19 11:51:21','2024-09-19 11:51:21','aaa','aaa.aaa.aaa',3,'1','any','fast',NULL,1,0,30,NULL),
(103,'youtube',2,1,4,1,'https://www.youtube.com/watch?v=49JBYSv3Nig',0,23,1,'2024-09-19 12:19:21','2024-09-19 12:19:45','2024-09-19 12:19:45',NULL,NULL,20,'1','any','fast',NULL,1,0,30,NULL),
(104,'youtube',2,1,4,1,'https://www.youtube.com/watch?v=49JBYSv3Nig',0,23,1,'2024-09-19 12:20:16','2024-09-19 12:23:35','2024-09-19 12:23:35',NULL,NULL,20,'1','any','fast',NULL,1,0,30,NULL),
(105,'install',3,1,4,1,NULL,1,23,0,'2024-09-20 08:07:50','2024-09-20 08:28:47','2024-09-20 08:28:47','rrr','rr.rrr.rrr',3,'1','any','fast',NULL,1,0,30,NULL),
(106,'install',3,1,4,1,NULL,1,23,0,'2024-09-20 08:28:56','2024-09-20 08:32:19','2024-09-20 08:32:19','ttt','ttt.ttt.ttt',3,'1','any','fast',NULL,1,0,30,NULL),
(107,'install',3,1,4,1,NULL,1,23,0,'2024-09-20 08:32:29','2024-09-20 11:27:44','2024-09-20 11:27:44','fff','fff.ff.ff',4,'1','any','fast',NULL,1,0,30,NULL),
(108,'youtube',2,1,4,1,'https://www.youtube.com/watch?v=49JBYSv3Nig',0,23,1,'2024-09-20 11:16:45','2024-09-20 11:27:52','2024-09-20 11:27:52',NULL,NULL,20,'1','any','fast',NULL,1,0,30,NULL),
(109,'youtube',3,1,4,1,'https://www.youtube.com/watch?v=49JBYSv3Nig',1,23,1,'2024-09-20 11:28:03','2024-09-26 13:15:26','2024-09-26 13:15:26',NULL,NULL,21,'1','any','fast',NULL,1,0,30,NULL),
(110,'install',3,1,4,1,NULL,1,23,0,'2024-09-23 08:36:14','2024-09-24 11:25:27','2024-09-24 11:25:27','eee','ee.eee.eee',10,'1','any','fast',NULL,1,0,30,NULL),
(111,'install',2,1,4,1,NULL,1,23,0,'2024-09-23 10:56:20','2024-09-23 10:58:13','2024-09-23 10:58:13','Subway Surfers','com.kiloo.subwaysurf',100,'1','any','fast',NULL,1,1,30,NULL),
(112,'install',2,1,4,1,NULL,1,23,0,'2024-09-23 11:03:45','2024-09-26 13:15:25','2024-09-26 13:15:25','Subway Surf','com.kiloo.subwaysurf',100,'1','any','fast',NULL,1,1,30,NULL),
(113,'install',3,1,4,1,NULL,1,23,0,'2024-09-24 11:17:14','2024-09-24 11:25:23','2024-09-24 11:25:23','ewrew','ewrew',4,'1','any','fast',NULL,1,0,30,NULL),
(114,'youtube',2,1,4,1,'https://youtu.be/UrKl9-OhBqE?si=5CXGgbVSBfh43FTz',1,23,1,'2024-09-26 13:17:44','2024-09-26 13:20:39','2024-09-26 13:20:39',NULL,NULL,50,'1','any','fast',NULL,1,0,30,NULL),
(115,'youtube',2,1,4,1,'https://youtu.be/UrKl9-OhBqE?si=5CXGgbVSBfh43FTz',1,23,1,'2024-09-26 13:27:45','2024-11-13 12:34:22','2024-11-13 12:34:22',NULL,NULL,50,'1','any','fast',NULL,1,0,30,NULL),
(116,'tiktok',2,1,4,1,'https://vm.tiktok.com/ZMhhn41gA/',0,23,1,'2024-10-03 07:11:11','2024-11-13 12:34:23','2024-11-13 12:34:23',NULL,NULL,7,'1','any','fast',NULL,1,0,30,NULL),
(117,'install',2,1,4,0,NULL,1,23,0,'2024-10-07 15:00:51','2024-11-13 12:34:27','2024-11-13 12:34:27','Market Madness Runner','com.BedrockFungi.MarketMadnessRunner',20,'1','any','fast',NULL,1,1,30,NULL),
(118,'install',2,1,4,0,NULL,1,23,0,'2024-10-11 15:52:06','2024-10-13 10:13:55','2024-10-13 10:13:55','Apple Aim','com.littlebgames.shoot_it',40,'1','any','fast',NULL,1,1,30,NULL),
(119,'install',3,1,4,1,NULL,1,23,0,'2024-10-13 07:59:57','2024-11-13 12:34:29','2024-11-13 12:34:29','Live Wallpapers, 4K Wallpapers','hd.uhd.live.wallpapers.topwallpapers',1,'1','any','fast',NULL,1,0,30,NULL),
(120,'install',2,1,4,0,NULL,1,23,0,'2024-10-13 10:16:34','2024-10-13 10:18:36','2024-10-13 10:18:36','Apple Aim','com.littlebgames.shoot_it',40,'1','any','fast',NULL,1,1,30,NULL),
(121,'install',2,1,4,0,NULL,1,23,0,'2024-10-13 10:18:58','2024-11-13 12:34:30','2024-11-13 12:34:30','Apple Aim','com.littlebgames.shoot_it',40,'1','any','fast',NULL,1,1,30,NULL),
(122,'install',2,1,4,0,NULL,1,23,0,'2024-10-13 13:40:02','2024-11-13 12:34:31','2024-11-13 12:34:31','Battle Idle','com.littlebit.battleidle',40,'1','any','fast',NULL,1,1,30,NULL),
(123,'install',3,1,4,0,NULL,1,23,0,'2024-10-13 13:41:49','2024-11-13 12:34:32','2024-11-13 12:34:32','Battle Idle','com.littlebit.battleidle',5,'1','any','fast',NULL,1,0,30,NULL),
(124,'install',3,1,4,1,NULL,1,23,0,'2024-10-14 09:38:01','2024-10-15 13:36:45','2024-10-15 13:36:45','htrhrt','trhtrh',3,'1','any','fast',NULL,1,0,30,NULL),
(125,'install',3,1,4,1,NULL,1,23,0,'2024-10-15 12:50:07','2024-10-15 13:36:47','2024-10-15 13:36:47','trhhr','trhtrhtr',8,'1','US','fast',NULL,1,0,30,NULL),
(126,'install',2,1,4,0,NULL,1,23,0,'2024-10-15 13:23:41','2024-11-13 12:34:34','2024-11-13 12:34:34','Illegal Money Factory Tycoon','com.littlebit.illegal.money.factory.idle.tycoon',10,'1','any','fast',NULL,1,0,30,NULL),
(127,'install',3,1,4,1,NULL,1,23,0,'2024-10-15 13:35:33','2024-10-15 14:30:55','2024-10-15 14:30:55','111','1111',3,'1','any','fast',NULL,1,0,30,NULL),
(128,'install',3,1,4,1,NULL,1,23,0,'2024-10-15 14:31:06','2024-10-21 15:15:45','2024-10-21 15:15:45','222','2322323',5,'1','any','fast',NULL,1,0,30,NULL),
(129,'install',3,1,4,1,NULL,1,23,0,'2024-10-15 15:51:00','2024-10-21 15:15:44','2024-10-21 15:15:44','1','1',1,'1','any','spread',NULL,1,0,30,NULL),
(130,'install',3,1,4,1,NULL,1,23,0,'2024-10-21 09:38:24','2024-10-21 09:41:51','2024-10-21 09:41:51','yfguyjgf','iuhu.yyy',1,'1','any','fast',NULL,1,0,30,NULL),
(131,'install',3,1,4,1,NULL,1,23,0,'2024-10-21 09:39:37','2024-10-21 09:41:46','2024-10-21 09:41:46','ewfwefwef','ewfewf.wefewfw',1,'1','any','fast',NULL,1,0,30,NULL),
(132,'install',3,1,4,1,NULL,1,23,0,'2024-10-21 09:41:19','2024-10-21 09:41:45','2024-10-21 09:41:45','ewfewf','ewfewfwe',1,'1','any','fast',NULL,1,0,30,NULL),
(133,'install',3,1,4,1,NULL,1,23,0,'2024-10-21 09:51:19','2024-10-21 15:15:42','2024-10-21 15:15:42','dsfdsf','dsfdsfsf',1,'1','any','fast',NULL,1,0,30,NULL),
(134,'install',3,1,4,1,NULL,1,23,0,'2024-10-21 11:16:41','2024-10-21 15:15:41','2024-10-21 15:15:41','fdgfdgdf','fdgfd.fdgfd',1,'1','any','fast',NULL,1,0,30,NULL),
(135,'install',2,1,4,0,NULL,1,23,0,'2024-10-21 13:15:30','2024-11-13 12:34:35','2024-11-13 12:34:35','Illegal Money Factory Tycoon','com.littlebit.illegal.money.factory.idle.tycoon',20,'1','any','fast',NULL,1,0,30,NULL),
(136,'install',2,1,4,0,NULL,1,23,0,'2024-10-21 13:26:50','2024-11-13 12:34:36','2024-11-13 12:34:36','Illegal Money Factory Tycoon','com.littlebit.illegal.money.factory.idle.tycoon',10,'1','any','fast',NULL,1,0,30,NULL),
(137,'install',2,1,4,0,NULL,1,23,0,'2024-10-21 14:53:58','2024-11-13 12:34:38','2024-11-13 12:34:38','Illegal Money Factory Tycoon','com.littlebit.illegal.money.factory.idle.tycoon',40,'1','any','fast',NULL,1,0,30,NULL),
(138,'install',3,1,4,1,NULL,1,23,0,'2024-10-21 15:17:22','2024-10-24 14:42:49','2024-10-24 14:42:49','ewfewf','efewf.ewfewf',45,'1','any','fast',NULL,1,0,30,NULL),
(139,'install',2,1,4,0,NULL,1,23,0,'2024-10-22 11:59:25','2024-11-13 12:34:39','2024-11-13 12:34:39','Illegal Money Factory Tycoon','com.littlebit.illegal.money.factory.idle.tycoon',20,'1','any','fast',NULL,1,0,30,NULL),
(140,'install',2,1,4,0,NULL,1,23,0,'2024-10-23 07:20:16','2024-10-23 14:53:32','2024-10-23 14:53:32','Illegal Money Factory Tycoon','com.littlebit.illegal.money.factory.idle.tycoon',10,'1','any','fast',NULL,1,0,30,NULL),
(141,'install',3,1,4,1,NULL,1,23,0,'2024-10-23 14:52:59','2024-10-23 14:53:29','2024-10-23 14:53:29','dsfsdf','dfdsfdsf',6,'1','any','spread',NULL,1,0,30,NULL),
(142,'install',3,1,4,1,NULL,1,23,0,'2024-10-23 14:57:51','2024-10-23 14:58:01','2024-10-23 14:58:01','grrg','fgfdgfdg',3,'1','any','fast',NULL,1,0,30,NULL),
(143,'install',3,1,4,1,NULL,1,23,0,'2024-10-23 14:58:25','2024-10-23 14:58:48','2024-10-23 14:58:48','jjkjhj','jhkjhkjhk',5,'1','any','spread',NULL,1,0,30,NULL),
(144,'install',3,1,4,1,NULL,1,23,0,'2024-10-23 15:12:53','2024-10-23 15:13:12','2024-10-23 15:13:12','fdsfsdf','dsfdsfds',6,'1','any','spread',NULL,1,0,30,NULL),
(145,'install',2,1,4,0,NULL,1,23,0,'2024-10-24 06:21:51','2024-11-13 12:34:40','2024-11-13 12:34:40','Illegal Money Factory Tycoon','com.littlebit.illegal.money.factory.idle.tycoon',60,'1','any','spread',NULL,1,0,30,NULL),
(146,'install',3,1,4,1,NULL,1,23,0,'2024-10-24 14:09:46','2024-10-24 14:23:42','2024-10-24 14:23:42','dfgdfg','dfgfdgfdg',60,'1','any','spread',NULL,1,0,30,NULL),
(147,'install',3,1,4,1,NULL,1,23,0,'2024-10-24 14:23:55','2024-10-24 14:24:24','2024-10-24 14:24:24','dsfsdf','dsfdfsdf',60,'1','any','fast',NULL,1,0,30,NULL),
(148,'install',3,1,4,1,NULL,1,23,0,'2024-10-24 14:24:39','2024-10-24 14:25:56','2024-10-24 14:25:56','dsfdsf','dsfdsfds',60,'1','any','spread',NULL,1,0,30,NULL),
(149,'install',3,1,4,1,NULL,1,23,0,'2024-10-24 14:29:56','2024-10-24 14:36:35','2024-10-24 14:36:35','23432432','3432432423',60,'1','any','spread',NULL,1,0,30,NULL),
(150,'install',2,1,4,0,NULL,1,23,0,'2024-10-24 15:53:55','2024-11-13 12:34:41','2024-11-13 12:34:41','Wine Factory Idle Tycoon Game','com.littlebit.wine.empire.idle.tycoon',30,'1','any','fast',NULL,1,0,30,NULL),
(151,'install',2,1,4,0,NULL,1,23,0,'2024-10-24 15:55:01','2024-11-13 12:34:42','2024-11-13 12:34:42','Startup Empire - Idle Tycoon','com.littlebit.itcorp',30,'1','any','spread',NULL,1,0,30,NULL),
(152,'install',2,1,4,0,NULL,1,23,0,'2024-10-24 15:56:55','2024-11-13 12:34:43','2024-11-13 12:34:43','Evolution Idle Tycoon Clicker','com.littlebitgames.idleevolution',30,'1','any','spread',NULL,1,0,30,NULL),
(153,'install',2,1,4,0,NULL,1,23,0,'2024-10-25 05:40:27','2024-11-13 12:34:44','2024-11-13 12:34:44','Illegal Money Factory Tycoon','com.littlebit.illegal.money.factory.idle.tycoon',20,'1','any','spread','factory tycoon',1,0,30,NULL),
(154,'install',2,1,4,0,NULL,1,23,0,'2024-10-25 05:41:36','2024-11-13 12:34:46','2024-11-13 12:34:46','Illegal Money Factory Tycoon','com.littlebit.illegal.money.factory.idle.tycoon',20,'1','any','spread',NULL,1,0,30,NULL),
(155,'install',2,1,4,0,NULL,1,23,0,'2024-10-25 05:44:28','2024-11-13 12:34:47','2024-11-13 12:34:47','Startup Empire - Idle Tycoon','com.littlebit.itcorp',20,'1','any','spread',NULL,1,0,30,NULL),
(156,'install',2,1,4,0,NULL,1,23,0,'2024-10-25 05:45:02','2024-11-13 12:34:48','2024-11-13 12:34:48','Startup Empire - Idle Tycoon','com.littlebit.itcorp',20,'1','any','spread',NULL,1,0,30,NULL),
(157,'install',2,1,4,0,NULL,1,23,0,'2024-10-25 05:46:34','2024-11-13 12:34:50','2024-11-13 12:34:50','Wine Factory Idle Tycoon Game','com.littlebit.wine.empire.idle.tycoon',20,'1','any','spread',NULL,1,0,30,NULL),
(158,'install',2,1,4,0,NULL,1,23,0,'2024-10-25 05:47:36','2024-11-13 12:34:51','2024-11-13 12:34:51','Wine Factory Idle Tycoon Game','com.littlebit.wine.empire.idle.tycoon',20,'1','any','spread',NULL,1,0,30,NULL),
(159,'install',2,1,4,0,NULL,1,23,0,'2024-10-26 06:24:02','2024-11-13 12:34:52','2024-11-13 12:34:52','Wine Factory Idle Tycoon Game','com.littlebit.wine.empire.idle.tycoon',20,'1','any','spread',NULL,1,0,30,NULL),
(160,'install',2,1,4,0,NULL,1,23,0,'2024-10-26 06:24:46','2024-11-13 12:34:54','2024-11-13 12:34:54','Wine Factory Idle Tycoon Game','com.littlebit.wine.empire.idle.tycoon',20,'1','any','spread',NULL,1,0,30,NULL),
(161,'install',2,1,4,0,NULL,1,23,0,'2024-10-26 06:26:18','2024-11-13 12:35:45','2024-11-13 12:35:45','Illegal Money Factory Tycoon','com.littlebit.illegal.money.factory.idle.tycoon',20,'1','any','spread',NULL,1,0,30,NULL),
(162,'install',2,1,4,0,NULL,1,23,0,'2024-10-26 06:26:53','2024-11-13 12:35:46','2024-11-13 12:35:46','Illegal Money Factory Tycoon','com.littlebit.illegal.money.factory.idle.tycoon',20,'1','any','spread',NULL,1,0,30,NULL),
(163,'install',2,1,4,0,NULL,1,23,0,'2024-10-26 06:27:52','2024-11-13 12:35:47','2024-11-13 12:35:47','Startup Empire - Idle Tycoon','com.littlebit.itcorp',20,'1','any','spread',NULL,1,0,30,NULL),
(164,'install',2,1,4,0,NULL,1,23,0,'2024-10-26 06:28:16','2024-11-13 12:35:48','2024-11-13 12:35:48','Startup Empire - Idle Tycoon','com.littlebit.itcorp',20,'1','any','spread',NULL,1,0,30,NULL),
(165,'install',3,1,4,0,NULL,1,23,0,'2024-10-26 09:29:32','2024-11-13 12:35:49','2024-11-13 12:35:49','Evolution Idle Tycoon Clicker','com.littlebitgames.idleevolution',80,'1','any','fast',NULL,1,1,30,NULL),
(166,'install',2,1,4,1,NULL,1,23,0,'2024-10-26 15:14:30','2024-11-13 12:35:51','2024-11-13 12:35:51','Evolution Idle Tycoon Clicker','com.littlebitgames.idleevolution',150,'1','any','fast',NULL,1,1,30,NULL),
(167,'install',2,1,4,1,NULL,1,23,0,'2024-10-26 15:19:22','2024-11-13 12:35:52','2024-11-13 12:35:52','Evolution Idle Tycoon Clicker','com.littlebitgames.idleevolution',200,'1','any','fast',NULL,1,1,30,NULL),
(168,'install',2,1,4,0,NULL,1,23,0,'2024-10-27 08:59:11','2024-11-13 12:35:53','2024-11-13 12:35:53','Startup Empire - Idle Tycoon','com.littlebit.itcorp',20,'1','any','spread',NULL,1,0,30,NULL),
(169,'install',2,1,4,0,NULL,1,23,0,'2024-10-27 08:59:51','2024-11-13 12:35:54','2024-11-13 12:35:54','Startup Empire - Idle Tycoon','com.littlebit.itcorp',20,'1','any','spread',NULL,1,0,30,NULL),
(170,'install',2,1,4,0,NULL,1,23,0,'2024-10-27 09:00:38','2024-11-13 12:35:55','2024-11-13 12:35:55','Illegal Money Factory Tycoon','com.littlebit.illegal.money.factory.idle.tycoon',20,'1','any','spread',NULL,1,0,30,NULL),
(171,'install',2,1,4,0,NULL,1,23,0,'2024-10-27 09:01:17','2024-11-13 12:35:56','2024-11-13 12:35:56','Illegal Money Factory Tycoon','com.littlebit.illegal.money.factory.idle.tycoon',20,'1','any','spread',NULL,1,0,30,NULL),
(172,'install',2,1,4,0,NULL,1,23,0,'2024-10-27 09:02:13','2024-11-13 12:35:57','2024-11-13 12:35:57','Wine Factory Idle Tycoon Game','com.littlebit.wine.empire.idle.tycoon',20,'1','any','spread',NULL,1,0,30,NULL),
(173,'install',2,1,4,0,NULL,1,23,0,'2024-10-27 09:02:40','2024-11-13 12:35:58','2024-11-13 12:35:58','Wine Factory Idle Tycoon Game','com.littlebit.wine.empire.idle.tycoon',20,'1','any','spread',NULL,1,0,30,NULL),
(174,'install',2,1,4,0,NULL,1,23,0,'2024-10-27 13:52:45','2024-11-13 12:36:00','2024-11-13 12:36:00','Apple Aim','com.littlebgames.shoot_it',350,'1','any','fast',NULL,1,1,30,NULL),
(175,'install',2,1,4,0,NULL,1,23,0,'2024-10-28 06:16:33','2024-11-13 12:36:02','2024-11-13 12:36:02','Wine Factory Idle Tycoon Game','com.littlebit.wine.empire.idle.tycoon',20,'1','any','spread',NULL,1,0,30,NULL),
(176,'install',2,1,4,0,NULL,1,23,0,'2024-10-28 06:16:56','2024-11-13 12:36:03','2024-11-13 12:36:03','Wine Factory Idle Tycoon Game','com.littlebit.wine.empire.idle.tycoon',20,'1','any','spread',NULL,1,0,30,NULL),
(177,'install',2,1,4,0,NULL,1,23,0,'2024-10-28 06:17:41','2024-11-13 12:36:04','2024-11-13 12:36:04','Illegal Money Factory Tycoon','com.littlebit.illegal.money.factory.idle.tycoon',20,'1','any','spread',NULL,1,0,30,NULL),
(178,'install',2,1,4,0,NULL,1,23,0,'2024-10-28 06:18:09','2024-11-13 12:36:05','2024-11-13 12:36:05','Illegal Money Factory Tycoon','com.littlebit.illegal.money.factory.idle.tycoon',20,'1','any','spread',NULL,1,0,30,NULL),
(179,'install',2,1,4,0,NULL,1,23,0,'2024-10-28 06:18:51','2024-11-13 12:36:06','2024-11-13 12:36:06','Startup Empire - Idle Tycoon','com.littlebit.itcorp',20,'1','any','spread',NULL,1,0,30,NULL),
(180,'install',2,1,4,0,NULL,1,23,0,'2024-10-28 06:19:15','2024-11-13 12:36:07','2024-11-13 12:36:07','Startup Empire - Idle Tycoon','com.littlebit.itcorp',20,'1','any','fast',NULL,1,0,30,NULL),
(181,'install',2,1,4,1,NULL,1,23,0,'2024-10-28 06:20:02','2024-11-13 12:36:08','2024-11-13 12:36:08','Apple Aim','com.littlebgames.shoot_it',400,'1','any','fast',NULL,1,1,30,NULL),
(182,'install',2,1,4,0,NULL,1,23,0,'2024-10-29 13:47:23','2024-11-13 12:36:09','2024-11-13 12:36:09','Apple Aim','com.littlebgames.shoot_it',300,'1','any','spread',NULL,1,1,30,NULL),
(183,'install',2,1,4,0,NULL,1,23,0,'2024-10-30 14:32:10','2024-11-13 12:36:10','2024-11-13 12:36:10','Apple Aim','com.littlebgames.shoot_it',545,'1','any','fast',NULL,1,1,30,NULL),
(184,'install',3,1,4,0,NULL,1,23,0,'2024-10-31 10:47:58','2024-10-31 10:49:21','2024-10-31 10:49:21','dfhgfdh','dfhfdhfdh',3,'1','any','fast',NULL,1,0,37,NULL),
(185,'install',3,1,4,1,NULL,1,23,0,'2024-10-31 12:23:36','2024-10-31 12:40:18','2024-10-31 12:40:18','sdgfdsg','dsgsdgsd',1,'1,5,14,20','any','fast',NULL,1,0,30,NULL),
(186,'install',3,1,4,1,NULL,1,23,0,'2024-10-31 12:48:07','2024-10-31 13:36:09','2024-10-31 13:36:09','ergreg','regregreg',1,'0','any','fast',NULL,1,0,30,NULL),
(187,'install',3,1,4,1,NULL,1,23,0,'2024-10-31 13:34:06','2024-10-31 13:36:07','2024-10-31 13:36:07','hhfghgf','fghgfhfg',1,'2,4,21','any','fast',NULL,1,0,30,NULL),
(188,'install',3,1,4,0,NULL,1,23,0,'2024-11-01 09:17:23','2024-11-01 09:17:39','2024-11-01 09:17:39',NULL,NULL,2,'3,4','any','fast',NULL,1,0,30,NULL),
(189,'install',3,1,4,0,NULL,1,23,0,'2024-11-01 09:18:01','2024-11-01 09:18:56','2024-11-01 09:18:56','dfgdsf','sdfsdf',2,'2,4','any','fast',NULL,1,0,30,NULL),
(190,'youtube',2,1,4,1,'https://www.youtube.com/live/CisZXMrGDb4?si=FP7jlPJ6utAWn7bx',0,32,0,'2024-11-01 13:14:38','2024-11-13 12:36:11','2024-11-13 12:36:11',NULL,NULL,100,'0','RU','fast',NULL,1,0,30,NULL),
(191,'0',2,1,4,1,NULL,0,32,0,'2024-11-01 13:15:57','2024-11-13 12:36:12','2024-11-13 12:36:12',NULL,NULL,100,'0','UA','fast',NULL,1,0,30,NULL),
(192,'youtube',2,1,4,1,'https://www.youtube.com/live/CisZXMrGDb4?si=FP7jlPJ6utAWn7bx',0,32,0,'2024-11-01 13:16:22','2024-11-13 12:36:30','2024-11-13 12:36:30',NULL,NULL,50,'0','KZ','fast',NULL,1,0,30,NULL),
(193,'youtube',2,1,4,1,'https://youtu.be/QK74IEvYUEU?si=czkeRS8cO3k4y63O',0,21,0,'2024-11-01 13:16:55','2024-11-13 12:36:31','2024-11-13 12:36:31',NULL,NULL,100,'0','RU','fast',NULL,1,0,30,NULL),
(194,'youtube',2,1,4,1,'https://youtu.be/QK74IEvYUEU?si=czkeRS8cO3k4y63O',0,21,0,'2024-11-01 13:17:13','2024-11-13 12:36:32','2024-11-13 12:36:32',NULL,NULL,100,'0','UA','fast',NULL,1,0,30,NULL),
(195,'youtube',2,1,4,1,'https://youtu.be/QK74IEvYUEU?si=czkeRS8cO3k4y63O',0,21,0,'2024-11-01 13:17:33','2024-11-13 12:36:33','2024-11-13 12:36:33',NULL,NULL,50,'0','KZ','fast',NULL,1,0,30,NULL),
(196,'youtube',2,1,4,1,'https://youtu.be/BRYlC8HA3GM?si=TWM93iGXE-MFwj75',0,17,0,'2024-11-01 13:18:15','2024-11-13 12:36:34','2024-11-13 12:36:34',NULL,NULL,100,'0','RU','fast',NULL,1,0,30,NULL),
(197,'youtube',2,1,4,1,'https://youtu.be/BRYlC8HA3GM?si=TWM93iGXE-MFwj75',0,17,0,'2024-11-01 13:18:35','2024-11-13 12:36:35','2024-11-13 12:36:35',NULL,NULL,100,'0','UA','fast',NULL,1,0,30,NULL),
(198,'youtube',2,1,4,1,'https://youtu.be/BRYlC8HA3GM?si=TWM93iGXE-MFwj75',0,17,0,'2024-11-01 13:18:52','2024-11-13 12:36:36','2024-11-13 12:36:36',NULL,NULL,50,'0','KZ','fast',NULL,1,0,30,NULL),
(199,'youtube',2,1,4,1,'https://www.youtube.com/live/CisZXMrGDb4?si=FP7jlPJ6utAWn7bx',0,32,0,'2024-11-02 05:26:31','2024-11-13 12:36:37','2024-11-13 12:36:37',NULL,NULL,233,'0','RU','fast',NULL,1,0,30,NULL),
(200,'youtube',2,1,4,1,'https://www.youtube.com/live/CisZXMrGDb4?si=FP7jlPJ6utAWn7bx',0,32,0,'2024-11-02 05:26:56','2024-11-13 12:36:38','2024-11-13 12:36:38',NULL,NULL,196,'0','UA','fast',NULL,1,0,30,NULL),
(201,'youtube',2,1,4,1,'https://www.youtube.com/live/CisZXMrGDb4?si=FP7jlPJ6utAWn7bx',0,32,0,'2024-11-02 05:27:23','2024-11-13 12:36:39','2024-11-13 12:36:39',NULL,NULL,71,'0','KZ','fast',NULL,1,0,30,NULL),
(202,'youtube',2,1,4,1,'https://youtu.be/QK74IEvYUEU?si=czkeRS8cO3k4y63O',0,21,0,'2024-11-02 05:27:51','2024-11-13 12:36:40','2024-11-13 12:36:40',NULL,NULL,233,'0','RU','fast',NULL,1,0,30,NULL),
(203,'youtube',2,1,4,1,'https://youtu.be/QK74IEvYUEU?si=czkeRS8cO3k4y63O',0,21,0,'2024-11-02 05:28:18','2024-11-13 12:36:41','2024-11-13 12:36:41',NULL,NULL,196,'0','UA','fast',NULL,1,0,30,NULL),
(204,'youtube',2,1,4,1,'https://youtu.be/QK74IEvYUEU?si=czkeRS8cO3k4y63O',0,21,0,'2024-11-02 05:28:34','2024-11-13 12:36:42','2024-11-13 12:36:42',NULL,NULL,71,'0','KZ','fast',NULL,1,0,30,NULL),
(205,'youtube',2,1,4,1,'https://youtu.be/m_2hyEwh4Ak?si=h5VTYQn9ft_BP1S2',0,40,0,'2024-11-02 05:34:39','2024-11-13 12:36:44','2024-11-13 12:36:44',NULL,NULL,233,'0','RU','fast',NULL,1,0,30,NULL),
(206,'youtube',2,1,4,1,'https://youtu.be/m_2hyEwh4Ak?si=h5VTYQn9ft_BP1S2',0,40,0,'2024-11-02 05:38:53','2024-11-13 12:36:45','2024-11-13 12:36:45',NULL,NULL,196,'0','UA','fast',NULL,1,0,30,NULL),
(207,'youtube',2,1,4,1,'https://youtu.be/m_2hyEwh4Ak?si=h5VTYQn9ft_BP1S2',0,40,0,'2024-11-02 05:39:09','2024-11-13 12:36:46','2024-11-13 12:36:46',NULL,NULL,71,'0','KZ','fast',NULL,1,0,30,NULL),
(208,'youtube',2,1,4,1,'https://youtu.be/q8iT34PGhyA?si=NH5OBUvP3IgLlXX9',0,29,0,'2024-11-02 05:39:41','2024-11-13 12:36:47','2024-11-13 12:36:47',NULL,NULL,233,'0','RU','fast',NULL,1,0,30,NULL),
(209,'youtube',2,1,4,1,'https://youtu.be/q8iT34PGhyA?si=NH5OBUvP3IgLlXX9',0,29,0,'2024-11-02 05:40:00','2024-11-13 12:36:48','2024-11-13 12:36:48',NULL,NULL,171,'0','UA','fast',NULL,1,0,30,NULL),
(210,'youtube',2,1,4,1,'https://youtu.be/q8iT34PGhyA?si=NH5OBUvP3IgLlXX9',0,29,0,'2024-11-02 05:40:22','2024-11-13 12:36:49','2024-11-13 12:36:49',NULL,NULL,71,'0','KZ','fast',NULL,1,0,30,NULL),
(211,'youtube',2,1,4,1,'https://youtu.be/VNN4gsTp0LM?si=DMXTDGWf8IYcPuxA',0,25,0,'2024-11-02 05:40:47','2024-11-13 12:36:50','2024-11-13 12:36:50',NULL,NULL,233,'0','RU','fast',NULL,1,0,30,NULL),
(212,'youtube',2,1,4,1,'https://youtu.be/VNN4gsTp0LM?si=DMXTDGWf8IYcPuxA',0,25,0,'2024-11-02 05:41:03','2024-11-13 12:36:51','2024-11-13 12:36:51',NULL,NULL,171,'0','UA','fast',NULL,1,0,30,NULL),
(213,'youtube',2,1,4,1,'https://youtu.be/VNN4gsTp0LM?si=DMXTDGWf8IYcPuxA',0,25,0,'2024-11-02 05:41:22','2024-11-13 12:36:52','2024-11-13 12:36:52',NULL,NULL,71,'0','KZ','fast',NULL,1,0,30,NULL),
(214,'install',2,1,4,0,NULL,1,23,0,'2024-11-02 12:05:23','2024-11-13 12:36:53','2024-11-13 12:36:53','Evolution Idle Tycoon Clicker','com.littlebitgames.idleevolution',100,'0','US','spread',NULL,1,0,40,NULL),
(215,'install',2,1,4,0,NULL,1,23,0,'2024-11-02 12:06:12','2024-11-13 12:36:54','2024-11-13 12:36:54','Evolution Idle Tycoon Clicker','com.littlebitgames.idleevolution',100,'0','US','spread',NULL,1,0,100,NULL),
(216,'install',2,1,4,0,NULL,1,23,0,'2024-11-02 12:07:40','2024-11-13 12:36:55','2024-11-13 12:36:55','Startup Empire - Idle Tycoon','com.littlebit.itcorp',100,'0','US','spread',NULL,1,0,120,NULL),
(217,'youtube',2,1,4,1,'https://www.youtube.com/watch?v=k9d4PKcZ8fA',14,50,1,'2024-11-04 16:10:12','2024-11-13 12:37:02','2024-11-13 12:37:02',NULL,NULL,233,'0','RU','fast',NULL,1,0,30,NULL),
(218,'youtube',2,1,3,1,'https://www.youtube.com/watch?v=k9d4PKcZ8fA',14,50,1,'2024-11-04 16:10:51','2024-11-13 12:37:03','2024-11-13 12:37:03',NULL,NULL,196,'0','UA','fast',NULL,1,0,30,NULL),
(219,'youtube',2,1,4,1,'https://www.youtube.com/watch?v=k9d4PKcZ8fA',14,51,1,'2024-11-04 16:11:14','2024-11-13 12:37:04','2024-11-13 12:37:04',NULL,NULL,71,'0','KZ','fast',NULL,1,0,30,NULL),
(220,'youtube',2,1,4,1,'https://www.youtube.com/watch?v=k9d4PKcZ8fA',14,45,1,'2024-11-04 16:12:00','2024-11-13 12:37:05','2024-11-13 12:37:05',NULL,NULL,51,'0','US','fast',NULL,1,0,30,NULL),
(221,'install',2,1,4,0,NULL,1,23,0,'2024-11-05 17:55:02','2024-11-19 09:25:28',NULL,'AI Chat 4 & Ask AI Chatbot GPT','chat.gpt.open.ai',50,'0','US','spread',NULL,1,0,30,'gpt 4'),
(222,'install',2,1,4,0,NULL,1,23,0,'2024-11-05 17:56:18','2024-11-05 17:56:18',NULL,'AI Chat 4 & Ask AI Chatbot GPT','chat.gpt.open.ai',10,'0','US','spread',NULL,1,0,30,NULL),
(223,'install',2,1,4,0,NULL,1,23,0,'2024-11-05 17:57:35','2024-11-19 09:25:47',NULL,'AI Chat 4 & Ask AI Chatbot GPT','chat.gpt.open.ai',50,'0','US','spread',NULL,1,0,60,'chatbot gpt'),
(224,'install',2,1,4,0,NULL,1,23,0,'2024-11-05 17:59:03','2024-11-19 09:25:50',NULL,'AI Chat 4 & Ask AI Chatbot GPT','chat.gpt.open.ai',100,'0','US','spread',NULL,1,0,60,'chatgpt4'),
(225,'install',2,1,4,0,NULL,1,23,0,'2024-11-05 18:00:04','2024-11-19 09:25:53',NULL,'AI Chat 4 & Ask AI Chatbot GPT','chat.gpt.open.ai',100,'0','US','spread',NULL,1,0,60,'chatgpt 4'),
(226,'install',2,1,4,0,NULL,1,23,0,'2024-11-05 18:01:58','2024-11-19 09:25:55',NULL,'AI Chat 4 & Ask AI Chatbot GPT','chat.gpt.open.ai',200,'0','US','spread',NULL,1,0,60,'chat gpt free'),
(227,'install',3,1,4,1,NULL,1,23,0,'2024-11-07 07:53:44','2024-11-13 12:37:09','2024-11-13 12:37:09','1','1',5,'0','any','spread',NULL,1,0,30,NULL),
(228,'install',2,1,4,0,NULL,1,23,0,'2024-11-07 07:58:09','2024-11-13 12:37:11','2024-11-13 12:37:11','Startup Empire - Idle Tycoon','com.littlebit.itcorp',100,'0','US','spread',NULL,1,0,60,NULL),
(229,'install',2,1,4,0,NULL,1,23,0,'2024-11-07 07:59:08','2024-11-13 12:37:12','2024-11-13 12:37:12','Evolution Idle Tycoon Clicker','com.littlebitgames.idleevolution',100,'0','US','spread',NULL,1,0,60,NULL),
(230,'install',2,1,4,0,NULL,1,23,0,'2024-11-07 08:00:13','2024-11-13 12:37:13','2024-11-13 12:37:13','Evolution Idle Tycoon Clicker','com.littlebitgames.idleevolution',100,'0','US','spread',NULL,1,0,60,NULL),
(231,'install',3,1,4,1,NULL,1,23,0,'2024-11-07 08:40:09','2024-11-07 09:38:05','2024-11-07 09:38:05','rgerg','ergregre',5,'0','any','spread',NULL,1,0,30,NULL),
(232,'import_chrome_cookies',3,1,4,1,NULL,1,23,0,'2024-11-07 09:36:56','2024-11-07 09:38:03','2024-11-07 09:38:03',NULL,NULL,4,'0','GQ','fast',NULL,1,0,30,NULL),
(233,'install',2,1,4,0,NULL,1,23,0,'2024-11-07 11:46:39','2024-11-19 09:25:58',NULL,'AI Chat 4 & Ask AI Chatbot GPT','chat.gpt.open.ai',50,'0','US','spread',NULL,1,0,60,'gpt 4'),
(234,'install',2,1,4,0,NULL,1,23,0,'2024-11-07 11:47:38','2024-11-19 09:26:00',NULL,'AI Chat 4 & Ask AI Chatbot GPT','chat.gpt.open.ai',50,'0','US','spread',NULL,1,0,60,'chatbot gpt'),
(235,'install',2,1,4,0,NULL,1,23,0,'2024-11-07 11:48:35','2024-11-19 09:26:02',NULL,'AI Chat 4 & Ask AI Chatbot GPT','chat.gpt.open.ai',100,'0','US','spread',NULL,1,0,60,'chatgpt 4'),
(236,'install',2,1,4,0,NULL,1,23,0,'2024-11-07 11:49:34','2024-11-19 09:26:04',NULL,'AI Chat 4 & Ask AI Chatbot GPT','chat.gpt.open.ai',100,'0','US','spread',NULL,1,0,60,'chatgpt4'),
(237,'install',2,1,4,0,NULL,1,23,0,'2024-11-07 11:50:27','2024-11-19 09:26:06',NULL,'AI Chat 4 & Ask AI Chatbot GPT','chat.gpt.open.ai',200,'0','US','spread',NULL,1,0,60,'chat gpt free'),
(238,'install',2,1,4,0,NULL,1,23,0,'2024-11-08 05:07:24','2024-11-19 09:26:08',NULL,'ЛС - Твой спорт. Футбол.','com.liga.tvoy.football.sprts.ls',500,'0','RU','spread',NULL,1,0,60,'лига ставок'),
(239,'install',2,1,4,0,NULL,1,23,0,'2024-11-09 09:38:27','2024-11-13 12:37:17','2024-11-13 12:37:17','Evolution Idle Tycoon Clicker','com.littlebitgames.idleevolution',100,'0','US','spread',NULL,1,0,60,NULL),
(240,'install',2,1,4,0,NULL,1,23,0,'2024-11-09 09:39:10','2024-11-13 12:37:18','2024-11-13 12:37:18','Evolution Idle Tycoon Clicker','com.littlebitgames.idleevolution',100,'0','any','spread',NULL,1,0,60,NULL),
(241,'install',2,1,4,0,NULL,1,23,0,'2024-11-09 09:40:06','2024-11-13 12:37:20','2024-11-13 12:37:20','Startup Empire - Idle Tycoon','com.littlebit.itcorp',100,'0','US','spread',NULL,1,0,60,NULL),
(242,'install',2,1,4,0,NULL,1,23,0,'2024-11-10 03:39:58','2024-11-19 09:26:10',NULL,'AI Chat 4 & Ask AI Chatbot GPT','chat.gpt.open.ai',100,'0','US','spread',NULL,1,0,60,'chatgpt4'),
(243,'install',2,1,4,0,NULL,1,23,0,'2024-11-10 03:40:33','2024-11-19 09:26:12',NULL,'AI Chat 4 & Ask AI Chatbot GPT','chat.gpt.open.ai',100,'0','any','spread',NULL,1,0,60,'chatgpt 4'),
(244,'install',2,1,4,0,NULL,1,23,0,'2024-11-10 03:41:16','2024-11-19 09:26:14',NULL,'AI Chat 4 & Ask AI Chatbot GPT','chat.gpt.open.ai',50,'0','US','spread',NULL,1,0,60,'gpt 4'),
(245,'install',2,1,4,0,NULL,1,23,0,'2024-11-10 03:42:20','2024-11-19 09:26:15',NULL,'AI Chat 4 & Ask AI Chatbot GPT','chat.gpt.open.ai',50,'0','US','spread',NULL,1,0,60,'chatbot gpt'),
(246,'install',2,1,4,0,NULL,1,23,0,'2024-11-10 03:43:06','2024-11-13 12:37:29','2024-11-13 12:37:29','AI Chat 4 & Ask AI Chatbot GPT','chat.gpt.open.ai',200,'0','US','spread',NULL,1,0,60,NULL),
(247,'install',2,1,4,0,NULL,1,23,0,'2024-11-10 05:55:30','2024-11-13 12:37:27','2024-11-13 12:37:27','Evolution Idle Tycoon Clicker','com.littlebitgames.idleevolution',100,'0','US','spread',NULL,1,0,100,NULL),
(248,'install',3,1,4,0,NULL,1,23,0,'2024-11-10 05:57:12','2024-11-13 12:37:31','2024-11-13 12:37:31','Evolution Idle Tycoon Clicker','com.littlebitgames.idleevolution',100,'0','US','spread',NULL,1,0,100,NULL),
(249,'install',2,1,4,0,NULL,1,23,0,'2024-11-10 05:58:32','2024-11-13 12:37:35','2024-11-13 12:37:35','Startup Empire - Idle Tycoon','com.littlebit.itcorp',100,'0','US','spread',NULL,1,0,100,NULL),
(250,'install',2,1,4,0,NULL,1,23,0,'2024-11-10 11:50:23','2024-11-13 12:37:38','2024-11-13 12:37:38','Apple Aim','com.littlebgames.shoot_it',1500,'0','any','fast',NULL,1,1,30,NULL),
(251,'install',3,1,4,0,NULL,1,23,0,'2024-11-11 12:24:56','2024-11-13 12:37:41','2024-11-13 12:37:41','Apple Aim','com.littlebgames.shoot_it',1,'0','GB','fast',NULL,1,0,30,NULL),
(252,'install',3,1,4,1,NULL,1,23,0,'2024-11-11 12:32:20','2024-11-13 12:37:48','2024-11-13 12:37:48','Apple Aim','com.littlebgames.shoot_it',1,'0','GB','fast',NULL,1,1,30,NULL),
(253,'install',3,1,4,1,NULL,1,23,0,'2024-11-12 14:27:25','2024-11-12 14:29:56','2024-11-12 14:29:56','fdsf','sdfdsfds',4,'0','any','fast',NULL,1,0,30,NULL),
(254,'install',2,1,4,0,NULL,1,23,0,'2024-11-13 11:36:50','2024-11-13 12:37:46','2024-11-13 12:37:46','Evolution Idle Tycoon Clicker','com.littlebitgames.idleevolution',384,'1','US','spread',NULL,1,0,60,NULL),
(255,'install',2,1,4,0,NULL,1,23,0,'2024-11-13 11:41:37','2024-11-13 12:37:43','2024-11-13 12:37:43','Evolution Idle Tycoon Clicker','com.littlebitgames.idleevolution',384,'1','US','spread',NULL,1,0,60,NULL),
(256,'install',3,1,4,0,NULL,1,23,0,'2024-11-13 11:42:54','2024-11-13 12:37:55','2024-11-13 12:37:55','Startup Empire - Idle Tycoon','com.littlebit.itcorp',100,'1','US','spread',NULL,1,0,60,NULL),
(257,'install',2,1,4,0,NULL,1,23,0,'2024-11-13 12:48:15','2024-11-19 09:26:17',NULL,'Evolution Idle Tycoon Clicker','com.littlebitgames.idleevolution',100,'1','US','spread',NULL,1,0,60,'evolution'),
(258,'install',2,1,4,0,NULL,1,23,0,'2024-11-13 12:49:04','2024-11-19 09:26:20',NULL,'Evolution Idle Tycoon Clicker','com.littlebitgames.idleevolution',100,'1','US','spread',NULL,1,0,60,'clicker'),
(259,'install',2,1,4,1,NULL,1,23,0,'2024-11-13 13:05:33','2024-11-19 09:26:22',NULL,'Apple Aim','com.littlebgames.shoot_it',400,'0','US','fast',NULL,1,1,30,'Apple Aim'),
(260,'install',2,1,4,0,NULL,1,23,0,'2024-11-15 17:39:38','2024-11-19 09:26:25',NULL,'Pinko','com.MarkL.Plinko',100,'0','US','fast',NULL,1,1,30,'Pinko'),
(261,'install',2,1,4,0,NULL,1,23,0,'2024-11-15 17:40:10','2024-11-19 09:26:27',NULL,'Pinko','com.MarkL.Plinko',100,'0','RU','fast',NULL,1,1,30,'Pinko'),
(262,'install',2,1,4,0,NULL,1,23,0,'2024-11-16 11:30:23','2024-11-19 09:26:29',NULL,'Pinko','com.MarkL.Plinko',150,'0','US','spread',NULL,1,1,30,'Pinko'),
(263,'install',2,1,4,0,NULL,1,23,0,'2024-11-16 11:30:59','2024-11-19 09:26:31',NULL,'Pinko','com.MarkL.Plinko',150,'0','RU','spread',NULL,1,1,30,'Pinko'),
(264,'install',2,1,4,0,NULL,1,23,0,'2024-11-17 14:14:40','2024-11-19 09:26:34',NULL,'Pinko','com.MarkL.Plinko',200,'0','US','spread',NULL,1,1,30,'Pinko'),
(265,'install',2,1,4,0,NULL,1,23,0,'2024-11-17 14:15:19','2024-11-19 09:26:36',NULL,'Pinko','com.MarkL.Plinko',200,'0','RU','spread',NULL,1,1,30,'Pinko'),
(266,'install',2,1,4,0,NULL,1,23,0,'2024-11-18 10:34:55','2024-11-19 09:26:39',NULL,'Pinko','com.MarkL.Plinko',250,'0','US','spread',NULL,1,1,30,'Pinko'),
(267,'install',2,1,4,0,NULL,1,23,0,'2024-11-18 10:35:17','2024-11-19 09:26:42',NULL,'Pinko','com.MarkL.Plinko',250,'0','RU','spread',NULL,1,1,30,'Pinko'),
(268,'install',3,1,4,0,NULL,1,23,0,'2024-11-18 18:10:20','2024-11-19 09:26:46',NULL,'AI Chat 4 & Ask AI Chatbot GPT','chat.gpt.open.ai',100,'0','US','spread',NULL,1,0,30,'chatgpt4'),
(269,'install',3,1,4,0,NULL,1,23,0,'2024-11-18 18:13:21','2024-11-19 09:26:49',NULL,'AI Chat 4 & Ask AI Chatbot GPT','chat.gpt.open.ai',100,'0','US','spread',NULL,1,0,30,'chatgpt 4'),
(270,'install',3,1,4,0,NULL,1,23,0,'2024-11-18 18:14:29','2024-11-19 09:26:51',NULL,'AI Chat 4 & Ask AI Chatbot GPT','chat.gpt.open.ai',50,'0','US','spread',NULL,1,0,30,'gpt 4'),
(271,'install',3,1,4,0,NULL,1,23,0,'2024-11-18 18:15:05','2024-11-19 09:26:53',NULL,'AI Chat 4 & Ask AI Chatbot GPT','chat.gpt.open.ai',50,'0','US','spread',NULL,1,0,30,'chatbot gpt'),
(272,'install',3,1,4,0,NULL,1,23,0,'2024-11-18 18:15:54','2024-11-19 09:26:56',NULL,'AI Chat 4 & Ask AI Chatbot GPT','chat.gpt.open.ai',200,'0','US','spread',NULL,1,0,30,'chat gpt free'),
(273,'install',3,1,4,0,NULL,1,23,0,'2024-11-19 13:24:31','2024-11-19 13:24:31',NULL,'app','12',1,'0','US','spread',NULL,1,0,30,'1'),
(274,'install',2,1,4,0,NULL,1,23,0,'2024-11-19 13:41:03','2024-11-19 13:41:03',NULL,'Evolution Idle Tycoon Clicker','com.littlebitgames.idleevolution',100,'1','US','spread',NULL,1,0,60,'evolution'),
(275,'install',2,1,4,0,NULL,1,23,0,'2024-11-19 14:12:34','2024-11-19 14:12:34',NULL,'Pinko','com.MarkL.Plinko',300,'0','US','spread',NULL,1,1,30,'Pinko'),
(276,'install',2,1,4,0,NULL,1,23,0,'2024-11-19 14:15:17','2024-11-19 14:15:17',NULL,'Pinko','com.MarkL.Plinko',300,'0','RU','spread',NULL,1,1,30,'Pinko'),
(277,'install',2,1,4,0,NULL,1,23,0,'2024-11-19 14:19:59','2024-11-19 14:19:59',NULL,'Evolution Idle Tycoon Clicker','com.littlebitgames.idleevolution',500,'0','US','spread',NULL,1,0,60,'evolution'),
(278,'install',2,1,4,0,NULL,1,23,0,'2024-11-19 14:20:42','2024-11-19 14:20:42',NULL,'Evolution Idle Tycoon Clicker','com.littlebitgames.idleevolution',500,'0','US','spread',NULL,1,0,60,'clicker'),
(279,'install',2,1,4,0,NULL,1,23,0,'2024-11-19 14:21:58','2024-11-19 14:21:58',NULL,'Startup Empire - Idle Tycoon','com.littlebit.itcorp',500,'0','US','spread',NULL,1,0,100,'empire'),
(280,'install',2,1,4,0,NULL,1,23,0,'2024-11-20 12:21:03','2024-11-20 12:21:03',NULL,'Pinko','com.MarkL.Plinko',350,'0','US','spread',NULL,1,1,30,'Pinko'),
(281,'install',2,1,4,0,NULL,1,23,0,'2024-11-20 12:21:35','2024-11-20 12:21:35',NULL,'Pinko','com.MarkL.Plinko',350,'0','RU','spread',NULL,1,1,30,'Pinko'),
(282,'install',3,1,4,0,NULL,1,23,0,'2024-11-21 10:18:17','2024-11-21 10:18:17',NULL,'Pinko','com.MarkL.Plinko',400,'0','US','spread',NULL,1,1,30,'Pinko'),
(283,'install',3,1,4,0,NULL,1,23,0,'2024-11-21 10:18:42','2024-11-21 10:18:42',NULL,'Pinko','com.MarkL.Plinko',400,'0','RU','spread',NULL,1,1,30,'Pinko'),
(284,'install',3,1,4,1,NULL,1,23,0,'2024-11-21 12:44:59','2024-11-21 12:44:59',NULL,'Smart Analyst','com.littlebgames.be_the_analyst',550,'0','any','fast',NULL,1,1,30,'Smart Analyst'),
(285,'install',3,1,4,1,NULL,1,23,0,'2024-11-21 12:45:44','2024-11-21 12:45:44',NULL,'Rome Evo','com.littlebit.rome.evo',550,'0','any','fast',NULL,1,1,30,'Rome Evo'),
(286,'install',2,1,4,0,NULL,1,23,0,'2024-11-22 18:58:02','2024-11-22 18:58:02',NULL,'Pinko','com.MarkL.Plinko',450,'0','US','spread',NULL,1,1,30,'Pinko'),
(287,'install',2,1,4,0,NULL,1,23,0,'2024-11-22 18:58:33','2024-11-22 18:58:33',NULL,'Pinko','com.MarkL.Plinko',450,'0','RU','spread',NULL,1,1,30,'Pinko'),
(288,'install',2,1,4,0,NULL,1,23,0,'2024-11-23 13:16:10','2024-11-23 13:16:10',NULL,'Pinko','com.MarkL.Plinko',550,'0','US','spread',NULL,1,1,30,'Pinko'),
(289,'install',2,1,4,0,NULL,1,23,0,'2024-11-23 13:16:39','2024-11-23 13:16:39',NULL,'Pinko','com.MarkL.Plinko',550,'0','RU','spread',NULL,1,1,30,'Pinko'),
(290,'install',2,1,4,0,NULL,1,23,0,'2024-11-24 16:59:02','2024-11-24 16:59:02',NULL,'Startup Empire - Idle Tycoon','com.littlebit.itcorp',1500,'0','US','spread',NULL,1,0,100,'empire'),
(291,'install',2,1,4,0,NULL,1,23,0,'2024-11-24 17:00:24','2024-11-24 17:00:24',NULL,'Evolution Idle Tycoon Clicker','com.littlebitgames.idleevolution',1500,'0','US','spread',NULL,1,0,100,'clicker'),
(292,'install',2,1,4,0,NULL,1,23,0,'2024-11-24 17:01:14','2024-11-24 17:01:14',NULL,'Evolution Idle Tycoon Clicker','com.littlebitgames.idleevolution',1500,'0','US','spread',NULL,1,0,100,'evolution'),
(293,'install',2,1,4,0,NULL,1,23,0,'2024-11-24 17:31:43','2024-11-24 17:31:43',NULL,'Pinko','com.MarkL.Plinko',550,'0','US','spread',NULL,1,1,30,'Pinko'),
(294,'install',2,1,4,0,NULL,1,23,0,'2024-11-24 17:32:14','2024-11-24 17:32:14',NULL,'Pinko','com.MarkL.Plinko',550,'0','RU','spread',NULL,1,1,30,'Pinko'),
(295,'install',2,1,4,0,NULL,1,23,0,'2024-11-25 11:35:25','2024-11-25 11:35:25',NULL,'KTO: Esporte Apostas','com.faraon.novel.healherheart',2,'0','BR','fast',NULL,1,0,30,'KTO'),
(296,'install',2,1,4,1,NULL,1,23,0,'2024-11-25 12:00:31','2024-11-25 12:00:31',NULL,'KTO: Esporte Apostas','com.faraon.novel.healherheart',50,'0','BR','spread',NULL,1,0,30,'kto'),
(297,'install',2,1,4,1,NULL,1,23,0,'2024-11-26 07:15:42','2024-11-26 07:15:42',NULL,'Smart Analyst','com.littlebgames.be_the_analyst',520,'0','any','spread',NULL,1,1,30,'Smart Analyst'),
(298,'install',2,1,4,0,NULL,1,23,0,'2024-11-26 14:00:23','2024-11-26 14:00:23',NULL,'Pinko','com.MarkL.Plinko',250,'0','US','spread',NULL,1,1,30,'Pinko'),
(299,'install',2,1,4,0,NULL,1,23,0,'2024-11-26 14:01:01','2024-11-26 14:01:01',NULL,'Pinko','com.MarkL.Plinko',250,'0','RU','spread',NULL,1,1,30,'Pinko'),
(300,'install',2,1,4,0,NULL,1,23,0,'2024-11-26 14:02:48','2024-11-26 14:02:48',NULL,'KTO: Esporte Apostas','com.faraon.novel.healherheart',30,'0','BR','spread',NULL,1,0,30,'KTO'),
(301,'install',2,1,4,0,NULL,1,23,0,'2024-11-26 14:06:43','2024-11-26 14:06:43',NULL,'Plinko Blast','com.game.sweet.land.scape',35,'0','DE','spread',NULL,1,1,30,'Plinko Blast'),
(302,'install',2,1,4,0,NULL,1,23,0,'2024-11-26 14:07:07','2024-11-26 14:07:07',NULL,'Plinko Blast','com.game.sweet.land.scape',35,'0','PL','spread',NULL,1,1,30,'Plinko Blast'),
(303,'install',2,1,4,0,NULL,1,23,0,'2024-11-26 14:07:27','2024-11-26 14:07:27',NULL,'Plinko Blast','com.game.sweet.land.scape',35,'0','IT','spread',NULL,1,1,30,'Plinko Blast'),
(304,'install',2,1,4,0,NULL,1,23,0,'2024-11-27 14:02:02','2024-11-27 14:02:02',NULL,'Pinko','com.MarkL.Plinko',250,'0','US','spread',NULL,1,1,30,'Pinko'),
(305,'install',2,1,4,1,NULL,1,23,0,'2024-11-27 14:02:22','2024-11-27 14:02:22',NULL,'Pinko','com.MarkL.Plinko',250,'0','RU','spread',NULL,1,1,30,'Pinko'),
(306,'install',2,1,4,0,NULL,1,23,0,'2024-11-27 14:03:48','2024-11-27 14:03:48',NULL,'Plinko Blast','com.game.sweet.land.scape',50,'0','DE','spread',NULL,1,1,30,'Plinko Blast'),
(307,'install',2,1,4,0,NULL,1,23,0,'2024-11-27 14:04:25','2024-11-27 14:04:25',NULL,'Plinko Blast','com.game.sweet.land.scape',50,'0','PL','spread',NULL,1,1,30,'Plinko Blast'),
(308,'install',2,1,4,0,NULL,1,23,0,'2024-11-27 14:04:58','2024-11-27 14:04:58',NULL,'Plinko Blast','com.game.sweet.land.scape',50,'0','IT','spread',NULL,1,1,30,'Plinko Blast'),
(309,'install',2,1,4,0,NULL,1,23,0,'2024-11-27 14:06:31','2024-11-27 14:06:31',NULL,'KTO: Esporte Apostas','com.faraon.novel.healherheart',40,'0','BR','spread',NULL,1,0,30,'KTO'),
(310,'install',2,1,4,0,NULL,1,23,0,'2024-11-28 10:35:19','2024-11-28 10:35:19',NULL,'Plinko Blast','com.game.sweet.land.scape',75,'0','DE','spread',NULL,1,1,30,'Plinko Blast'),
(311,'install',2,1,4,0,NULL,1,23,0,'2024-11-28 10:35:46','2024-11-28 10:35:46',NULL,'Plinko Blast','com.game.sweet.land.scape',75,'0','PL','spread',NULL,1,1,30,'Plinko Blast'),
(312,'install',2,1,4,0,NULL,1,23,0,'2024-11-28 10:36:12','2024-11-28 10:36:12',NULL,'Plinko Blast','com.game.sweet.land.scape',75,'0','IT','spread',NULL,1,1,30,'Plinko Blast'),
(313,'install',2,1,4,0,NULL,1,23,0,'2024-11-28 10:37:03','2024-11-28 10:37:03',NULL,'Pinko','com.MarkL.Plinko',250,'0','US','spread',NULL,1,1,30,'Pinko'),
(314,'install',2,1,4,0,NULL,1,23,0,'2024-11-28 10:37:27','2024-11-28 10:37:27',NULL,'Pinko','com.MarkL.Plinko',250,'0','RU','spread',NULL,1,1,30,'Pinko'),
(315,'install',2,1,4,0,NULL,1,23,0,'2024-11-28 10:39:30','2024-11-28 10:39:30',NULL,'KTO: Esporte Apostas','com.faraon.novel.healherheart',50,'0','BR','spread',NULL,1,0,30,'KTO'),
(316,'install',2,1,4,0,NULL,1,23,0,'2024-11-28 17:30:11','2024-11-28 17:30:11',NULL,'Plinko Blast','com.game.sweet.land.scape',15,'0','DE','fast',NULL,1,1,30,'Plinko Blast'),
(317,'install',2,1,4,0,NULL,1,23,0,'2024-11-28 17:30:32','2024-11-28 17:30:32',NULL,'Plinko Blast','com.game.sweet.land.scape',15,'0','PL','fast',NULL,1,1,30,'Plinko Blast'),
(318,'install',2,1,4,0,NULL,1,23,0,'2024-11-28 17:31:07','2024-11-28 17:31:07',NULL,'Plinko Blast','com.game.sweet.land.scape',15,'0','IT','fast',NULL,1,1,30,'Plinko Blast'),
(319,'install',2,1,4,0,NULL,1,23,0,'2024-11-29 10:41:54','2024-11-29 10:41:54',NULL,'KTO: Esporte Apostas','com.faraon.novel.healherheart',310,'0','BR','spread',NULL,1,0,30,'KTO'),
(320,'install',2,1,4,0,NULL,1,23,0,'2024-11-29 10:49:55','2024-11-29 10:49:55',NULL,'Pinko','com.MarkL.Plinko',250,'0','US','spread',NULL,1,1,30,'Pinko'),
(321,'install',2,1,4,0,NULL,1,23,0,'2024-11-29 10:50:18','2024-11-29 10:50:18',NULL,'Pinko','com.MarkL.Plinko',250,'0','RU','spread',NULL,1,1,30,'Pinko'),
(322,'install',2,1,4,0,NULL,1,23,0,'2024-11-29 10:51:05','2024-11-29 10:51:05',NULL,'Plinko Blast','com.game.sweet.land.scape',120,'0','DE','spread',NULL,1,1,30,'Plinko Blast'),
(323,'install',2,1,4,0,NULL,1,23,0,'2024-11-29 10:51:33','2024-11-29 10:51:33',NULL,'Plinko Blast','com.game.sweet.land.scape',120,'0','PL','spread',NULL,1,1,30,'Plinko Blast'),
(324,'install',2,1,4,0,NULL,1,23,0,'2024-11-29 10:52:04','2024-11-29 10:52:04',NULL,'Plinko Blast','com.game.sweet.land.scape',120,'0','IT','spread',NULL,1,1,30,'Plinko Blast'),
(325,'install',2,1,4,0,NULL,1,23,0,'2024-11-29 20:53:52','2024-11-29 20:53:52',NULL,'Plinko Blast','com.game.sweet.land.scape',20,'0','DE','fast',NULL,1,1,30,'Plinko Blast'),
(326,'install',2,1,4,0,NULL,1,23,0,'2024-11-29 20:54:16','2024-11-29 20:54:16',NULL,'Plinko Blast','com.game.sweet.land.scape',20,'0','PL','fast',NULL,1,1,30,'Plinko Blast'),
(327,'install',2,1,4,0,NULL,1,23,0,'2024-11-29 20:54:54','2024-11-29 20:54:54',NULL,'Plinko Blast','com.game.sweet.land.scape',20,'0','IT','fast',NULL,1,1,30,'Plinko Blast'),
(328,'install',2,1,4,0,NULL,1,23,0,'2024-11-30 07:15:52','2024-11-30 07:15:52',NULL,'Plinko','com.sweet.candy.land.plinko.gameapp',35,'0','DE','spread',NULL,1,1,30,'Plinko'),
(329,'install',2,1,4,0,NULL,1,23,0,'2024-11-30 07:16:19','2024-11-30 07:16:19',NULL,'Plinko','com.sweet.candy.land.plinko.gameapp',35,'0','PL','spread',NULL,1,1,30,'Plinko'),
(330,'install',2,1,4,0,NULL,1,23,0,'2024-11-30 07:16:40','2024-11-30 07:16:40',NULL,'Plinko','com.sweet.candy.land.plinko.gameapp',35,'0','IT','spread',NULL,1,1,30,'Plinko'),
(331,'install',2,1,4,0,NULL,1,23,0,'2024-11-30 10:55:58','2024-11-30 10:55:58',NULL,'Pinko','com.MarkL.Plinko',250,'0','US','spread',NULL,1,1,30,'Pinko'),
(332,'install',2,1,4,0,NULL,1,23,0,'2024-11-30 10:56:20','2024-11-30 10:56:20',NULL,'Pinko','com.MarkL.Plinko',250,'0','RU','spread',NULL,1,1,30,'Pinko'),
(333,'install',2,1,4,0,NULL,1,23,0,'2024-11-30 10:57:19','2024-11-30 10:57:19',NULL,'KTO: Esporte Apostas','com.faraon.novel.healherheart',530,'0','BR','spread',NULL,1,0,30,'KTO'),
(334,'install',2,1,4,0,NULL,1,23,0,'2024-11-30 10:58:18','2024-11-30 10:58:18',NULL,'Plinko Blast','com.game.sweet.land.scape',150,'0','DE','spread',NULL,1,1,30,'Plinko Blast'),
(335,'install',2,1,4,0,NULL,1,23,0,'2024-11-30 10:58:44','2024-11-30 10:58:44',NULL,'Plinko Blast','com.game.sweet.land.scape',150,'0','PL','spread',NULL,1,1,30,'Plinko Blast'),
(336,'install',2,1,4,0,NULL,1,23,0,'2024-11-30 10:59:08','2024-11-30 10:59:08',NULL,'Plinko Blast','com.game.sweet.land.scape',150,'0','IT','spread',NULL,1,1,30,'Plinko Blast'),
(337,'install',2,1,4,0,NULL,1,23,0,'2024-11-30 11:04:21','2024-11-30 11:04:21',NULL,'Plinko','com.sweet.candy.land.plinko.gameapp',10,'0','DE','fast',NULL,1,1,30,'Plinko'),
(338,'install',2,1,4,0,NULL,1,23,0,'2024-11-30 11:04:44','2024-11-30 11:04:44',NULL,'Plinko','com.sweet.candy.land.plinko.gameapp',10,'0','PL','fast',NULL,1,1,30,'Plinko'),
(339,'install',2,1,4,0,NULL,1,23,0,'2024-11-30 11:05:04','2024-11-30 11:05:04',NULL,'Plinko','com.sweet.candy.land.plinko.gameapp',10,'0','IT','fast',NULL,1,1,30,'Plinko'),
(340,'install',2,1,4,0,NULL,1,23,0,'2024-11-30 19:40:01','2024-11-30 19:40:01',NULL,'Plinko Blast','com.game.sweet.land.scape',20,'0','DE','fast',NULL,1,1,30,'Plinko Blast'),
(341,'install',2,1,4,0,NULL,1,23,0,'2024-11-30 19:40:28','2024-11-30 19:40:28',NULL,'Plinko Blast','com.game.sweet.land.scape',20,'0','PL','fast',NULL,1,1,30,'Plinko Blast'),
(342,'install',2,1,4,0,NULL,1,23,0,'2024-11-30 19:40:49','2024-11-30 19:40:49',NULL,'Plinko Blast','com.game.sweet.land.scape',20,'0','IT','fast',NULL,1,1,30,'Plinko Blast'),
(343,'install',2,1,4,0,NULL,1,23,0,'2024-12-01 12:03:20','2024-12-01 12:03:20',NULL,'Plinko','com.sweet.candy.land.plinko.gameapp',50,'0','DE','spread',NULL,1,0,120,'Plinko'),
(344,'install',2,1,4,0,NULL,1,23,0,'2024-12-01 12:05:32','2024-12-01 12:05:32',NULL,'Plinko','com.sweet.candy.land.plinko.gameapp',20,'0','DE','fast',NULL,1,0,120,'Plinko'),
(345,'install',2,1,4,0,NULL,1,23,0,'2024-12-01 12:06:09','2024-12-01 12:06:09',NULL,'Plinko','com.sweet.candy.land.plinko.gameapp',50,'0','PL','spread',NULL,1,0,120,'Plinko'),
(346,'install',2,1,4,0,NULL,1,23,0,'2024-12-01 12:06:54','2024-12-01 12:06:54',NULL,'Plinko','com.sweet.candy.land.plinko.gameapp',20,'0','PL','fast',NULL,1,0,120,'Plinko'),
(347,'install',2,1,4,0,NULL,1,23,0,'2024-12-01 12:07:27','2024-12-01 12:07:27',NULL,'Plinko','com.sweet.candy.land.plinko.gameapp',50,'0','IT','spread',NULL,1,0,120,'Plinko'),
(348,'install',2,1,4,0,NULL,1,23,0,'2024-12-01 12:08:57','2024-12-01 12:08:57',NULL,'Plinko','com.sweet.candy.land.plinko.gameapp',20,'0','IT','fast',NULL,1,0,120,'Plinko'),
(349,'install',2,1,4,0,NULL,1,23,0,'2024-12-01 14:53:53','2024-12-01 14:53:53',NULL,'Pinko','com.MarkL.Plinko',250,'0','US','spread',NULL,1,1,30,'Pinko'),
(350,'install',2,1,4,0,NULL,1,23,0,'2024-12-01 14:54:23','2024-12-01 14:54:23',NULL,'Pinko','com.MarkL.Plinko',250,'0','RU','spread',NULL,1,1,30,'Pinko'),
(351,'install',2,1,4,0,NULL,1,23,0,'2024-12-01 14:55:29','2024-12-01 14:55:29',NULL,'Plinko Blast','com.game.sweet.land.scape',170,'0','DE','spread',NULL,1,1,30,'Plinko Blast'),
(352,'install',2,1,4,0,NULL,1,23,0,'2024-12-01 14:55:55','2024-12-01 14:55:55',NULL,'Plinko Blast','com.game.sweet.land.scape',170,'0','PL','spread',NULL,1,1,30,'Plinko Blast'),
(353,'install',2,1,4,0,NULL,1,23,0,'2024-12-01 14:56:21','2024-12-01 14:56:21',NULL,'Plinko Blast','com.game.sweet.land.scape',170,'0','IT','spread',NULL,1,1,30,'Plinko Blast'),
(354,'install',2,1,4,0,NULL,1,23,0,'2024-12-02 06:45:02','2024-12-02 06:45:02',NULL,'Plinko','com.sweet.candy.land.plinko.gameapp',75,'0','DE','spread',NULL,1,1,30,'Plinko'),
(355,'install',2,1,4,0,NULL,1,23,0,'2024-12-02 06:45:27','2024-12-02 06:45:27',NULL,'Plinko','com.sweet.candy.land.plinko.gameapp',75,'0','PL','spread',NULL,1,1,30,'Plinko'),
(356,'install',2,1,4,0,NULL,1,23,0,'2024-12-02 06:45:55','2024-12-02 06:45:55',NULL,'Plinko','com.sweet.candy.land.plinko.gameapp',75,'0','IT','spread',NULL,1,1,30,'Plinko'),
(357,'install',2,1,4,0,NULL,1,23,0,'2024-12-02 06:46:16','2024-12-02 06:46:16',NULL,'Plinko','com.sweet.candy.land.plinko.gameapp',50,'0','DE','fast',NULL,1,1,30,'Plinko'),
(358,'install',2,1,4,0,NULL,1,23,0,'2024-12-02 06:46:35','2024-12-02 06:46:35',NULL,'Plinko','com.sweet.candy.land.plinko.gameapp',50,'0','PL','fast',NULL,1,1,30,'Plinko'),
(359,'install',2,1,4,0,NULL,1,23,0,'2024-12-02 06:46:53','2024-12-02 06:46:53',NULL,'Plinko','com.sweet.candy.land.plinko.gameapp',50,'0','IT','fast',NULL,1,1,30,'Plinko'),
(360,'install',2,1,4,0,NULL,1,23,0,'2024-12-02 15:40:25','2024-12-02 15:40:25',NULL,'Plinko Blast','com.game.sweet.land.scape',220,'0','DE','spread',NULL,1,1,30,'Plinko Blast'),
(361,'install',2,1,4,0,NULL,1,23,0,'2024-12-02 15:40:58','2024-12-02 15:40:58',NULL,'Plinko Blast','com.game.sweet.land.scape',60,'0','DE','fast',NULL,1,1,30,'Plinko Blast'),
(362,'install',2,1,4,0,NULL,1,23,0,'2024-12-02 15:41:20','2024-12-02 15:41:20',NULL,'Plinko Blast','com.game.sweet.land.scape',220,'0','PL','spread',NULL,1,1,30,'Plinko Blast'),
(363,'install',2,1,4,0,NULL,1,23,0,'2024-12-02 15:41:39','2024-12-02 15:41:39',NULL,'Plinko Blast','com.game.sweet.land.scape',60,'0','PL','fast',NULL,1,1,30,'Plinko Blast'),
(364,'install',2,1,4,0,NULL,1,23,0,'2024-12-02 15:42:05','2024-12-02 15:42:05',NULL,'Plinko Blast','com.game.sweet.land.scape',220,'0','IT','spread',NULL,1,1,30,'Plinko Blast'),
(365,'install',2,1,4,0,NULL,1,23,0,'2024-12-02 15:42:22','2024-12-02 15:42:22',NULL,'Plinko Blast','com.game.sweet.land.scape',60,'0','IT','fast',NULL,1,1,30,'Plinko Blast'),
(366,'install',2,1,4,0,NULL,1,23,0,'2024-12-02 15:43:17','2024-12-02 15:43:17',NULL,'Pinko','com.MarkL.Plinko',250,'0','US','spread',NULL,1,1,30,'Pinko'),
(367,'install',3,1,4,0,NULL,1,23,0,'2024-12-02 15:43:37','2024-12-02 15:43:37',NULL,'Pinko','com.MarkL.Plinko',250,'0','RU','spread',NULL,1,1,30,'Pinko'),
(368,'install',2,1,4,0,NULL,1,23,0,'2024-12-03 07:15:55','2024-12-03 07:15:55',NULL,'Plinko','com.sweet.candy.land.plinko.gameapp',110,'0','IT','spread',NULL,1,0,30,'plinko'),
(369,'install',2,1,4,0,NULL,1,23,0,'2024-12-03 07:16:15','2024-12-03 07:16:15',NULL,'Plinko','com.sweet.candy.land.plinko.gameapp',110,'0','PL','spread',NULL,1,1,30,'Plinko'),
(370,'install',2,1,4,0,NULL,1,23,0,'2024-12-03 07:16:33','2024-12-03 07:16:33',NULL,'Plinko','com.sweet.candy.land.plinko.gameapp',110,'0','DE','spread',NULL,1,1,30,'Plinko'),
(371,'install',2,1,4,0,NULL,1,23,0,'2024-12-03 12:16:42','2024-12-03 12:16:42',NULL,'Plinko','com.sweet.candy.land.plinko.gameapp',110,'0','IT','spread',NULL,1,1,30,'Plinko'),
(372,'install',2,1,4,0,NULL,1,23,0,'2024-12-03 12:17:04','2024-12-03 12:17:04',NULL,'Plinko','com.sweet.candy.land.plinko.gameapp',70,'0','IT','fast',NULL,1,1,30,'Plinko'),
(373,'install',2,1,4,0,NULL,1,23,0,'2024-12-03 14:12:35','2024-12-03 14:12:35',NULL,'Pinko','com.MarkL.Plinko',250,'0','US','spread',NULL,1,1,30,'Pinko'),
(374,'install',3,1,4,0,NULL,1,23,0,'2024-12-03 14:12:57','2024-12-03 14:12:57',NULL,'Pinko','com.MarkL.Plinko',250,'0','US','spread',NULL,1,1,30,'Pinko'),
(375,'install',2,1,4,0,NULL,1,23,0,'2024-12-03 14:13:40','2024-12-03 14:13:40',NULL,'Plinko Blast','com.game.sweet.land.scape',280,'0','DE','spread',NULL,1,1,30,'Plinko Blast'),
(376,'install',2,1,4,0,NULL,1,23,0,'2024-12-03 14:14:13','2024-12-03 14:14:13',NULL,'Plinko Blast','com.game.sweet.land.scape',280,'0','PL','spread',NULL,1,1,30,'Plinko Blast'),
(377,'install',2,1,4,0,NULL,1,23,0,'2024-12-03 14:14:49','2024-12-03 14:14:49',NULL,'Plinko Blast','com.game.sweet.land.scape',280,'0','IT','spread',NULL,1,1,30,'Plinko Blast'),
(378,'install',2,1,4,0,NULL,1,23,0,'2024-12-04 06:26:40','2024-12-04 06:26:40',NULL,'Plinko Blast','com.game.sweet.land.scape',400,'0','DE','spread',NULL,1,1,30,'Plinko Blast'),
(379,'install',2,1,4,0,NULL,1,23,0,'2024-12-04 06:27:02','2024-12-04 06:27:02',NULL,'Plinko Blast','com.game.sweet.land.scape',400,'0','PL','spread',NULL,1,1,30,'Plinko Blast'),
(380,'install',3,1,4,0,NULL,1,23,0,'2024-12-04 06:28:14','2024-12-04 06:28:14',NULL,'Plinko Blast','com.game.sweet.land.scape',400,'0','IT','spread',NULL,1,1,30,'Plinko Blast'),
(381,'install',2,1,4,0,NULL,1,23,0,'2024-12-04 06:28:48','2024-12-04 06:28:48',NULL,'Plinko','com.sweet.candy.land.plinko.gameapp',200,'0','DE','spread',NULL,1,1,30,'Plinko'),
(382,'install',2,1,4,0,NULL,1,23,0,'2024-12-04 06:29:10','2024-12-04 06:29:10',NULL,'Plinko','com.sweet.candy.land.plinko.gameapp',200,'0','PL','spread',NULL,1,1,30,'Plinko'),
(383,'install',2,1,4,0,NULL,1,23,0,'2024-12-04 06:29:29','2024-12-04 06:29:29',NULL,'Plinko','com.sweet.candy.land.plinko.gameapp',200,'0','IT','spread',NULL,1,1,30,'Plinko'),
(384,'install',3,1,4,0,NULL,1,23,0,'2024-12-04 11:26:19','2024-12-04 11:26:19',NULL,'Startup Empire - Idle Tycoon','com.littlebit.itcorp',5000,'0','US','spread',NULL,1,0,120,'empire'),
(385,'install',2,1,4,0,NULL,1,23,0,'2024-12-04 11:27:43','2024-12-04 11:27:43',NULL,'Evolution Idle Tycoon Clicker','com.littlebitgames.idleevolution',5000,'0','US','spread',NULL,1,0,120,'clicker'),
(386,'install',2,1,4,0,NULL,1,23,0,'2024-12-04 11:28:35','2024-12-04 11:28:35',NULL,'Evolution Idle Tycoon Clicker','com.littlebitgames.idleevolution',5000,'0','US','spread',NULL,1,0,120,'evolution'),
(387,'install',2,1,4,0,NULL,1,23,0,'2024-12-05 07:59:07','2024-12-05 07:59:07',NULL,'Plinko Go','com.plinco.plink.games',35,'0','DE','spread',NULL,1,1,30,'Plinko Go'),
(388,'install',2,1,4,0,NULL,1,23,0,'2024-12-05 07:59:50','2024-12-05 07:59:50',NULL,'Plinko Go','com.plinco.plink.games',35,'0','PL','spread',NULL,1,1,30,'Plinko Go'),
(389,'install',2,1,4,0,NULL,1,23,0,'2024-12-05 08:00:08','2024-12-05 08:00:08',NULL,'Plinko Go','com.plinco.plink.games',35,'0','IT','spread',NULL,1,1,30,'Plinko Go'),
(390,'install',3,1,4,1,NULL,1,23,0,'2024-12-05 13:44:23','2024-12-05 13:46:41','2024-12-05 13:46:41','fgsdfsd','dsfdsfds',3,'0','any','spread',NULL,1,0,30,'fgsdfsd'),
(391,'install',3,1,4,1,NULL,1,23,0,'2024-12-05 14:04:35','2024-12-05 14:05:25','2024-12-05 14:05:25','ewfewf','wefewfwe',4,'0','any','spread',NULL,1,0,30,'ewfewf'),
(392,'install',3,1,4,1,NULL,1,23,0,'2024-12-05 14:06:01','2024-12-05 14:06:29','2024-12-05 14:06:29','ewfewewf','ewfewfew',4,'0','any','spread',NULL,1,0,30,'ewfewewf'),
(393,'install',3,1,4,1,NULL,1,23,0,'2024-12-05 14:14:38','2024-12-05 14:17:02','2024-12-05 14:17:02','wefewfwe','ewfewfw',4,'1,3,5','any','spread',NULL,1,0,30,'wefewfwe'),
(394,'install',3,1,4,1,NULL,1,23,0,'2024-12-05 14:17:18','2024-12-05 14:17:57','2024-12-05 14:17:57','qwewqe','wqewqewq',4,'1,3,5','any','spread',NULL,1,0,30,'qwewqe'),
(395,'install',2,1,4,0,NULL,1,23,0,'2024-12-05 19:44:39','2024-12-05 19:44:39',NULL,'Pinko','com.MarkL.Plinko',250,'0','US','spread',NULL,1,1,30,'Pinko'),
(396,'install',2,1,4,0,NULL,1,23,0,'2024-12-05 19:45:11','2024-12-05 19:45:11',NULL,'Pinko','com.MarkL.Plinko',250,'0','RU','spread',NULL,1,1,30,'Pinko'),
(397,'install',2,1,4,0,NULL,1,23,0,'2024-12-05 19:46:25','2024-12-05 19:46:25',NULL,'Plinko Blast','com.game.sweet.land.scape',500,'0','DE','spread',NULL,1,1,30,'Plinko Blast'),
(398,'install',2,1,4,0,NULL,1,23,0,'2024-12-05 19:46:50','2024-12-05 19:46:50',NULL,'Plinko Blast','com.game.sweet.land.scape',500,'0','IT','spread',NULL,1,1,30,'Plinko Blast'),
(399,'install',2,1,4,0,NULL,1,23,0,'2024-12-05 19:47:13','2024-12-05 19:47:13',NULL,'Plinko Blast','com.game.sweet.land.scape',500,'0','PL','spread',NULL,1,1,30,'Plinko Blast'),
(400,'install',2,1,4,0,NULL,1,23,0,'2024-12-05 19:48:08','2024-12-05 19:48:08',NULL,'Plinko','com.sweet.candy.land.plinko.gameapp',200,'0','DE','spread',NULL,1,1,30,'Plinko'),
(401,'install',2,1,4,0,NULL,1,23,0,'2024-12-05 19:48:31','2024-12-05 19:48:31',NULL,'Plinko','com.sweet.candy.land.plinko.gameapp',200,'0','IT','spread',NULL,1,1,30,'Plinko'),
(402,'install',2,1,4,0,NULL,1,23,0,'2024-12-05 19:49:15','2024-12-05 19:49:15',NULL,'Plinko','com.sweet.candy.land.plinko.gameapp',200,'0','PL','spread',NULL,1,1,30,'Plinko'),
(403,'install',2,1,4,0,NULL,1,23,0,'2024-12-05 19:50:23','2024-12-05 19:50:23',NULL,'Plinko Go','com.plinco.plink.games',50,'0','DE','spread',NULL,1,1,30,'Plinko Go'),
(404,'install',2,1,4,0,NULL,1,23,0,'2024-12-05 19:50:48','2024-12-05 19:50:48',NULL,'Plinko Go','com.plinco.plink.games',50,'0','IT','spread',NULL,1,1,30,'Plinko Go'),
(405,'install',2,1,4,0,NULL,1,23,0,'2024-12-05 19:51:26','2024-12-05 19:51:26',NULL,'Plinko Go','com.plinco.plink.games',50,'0','PL','spread',NULL,1,1,30,'Plinko Go'),
(406,'install',2,1,4,0,NULL,1,23,0,'2024-12-06 15:16:59','2024-12-06 15:16:59',NULL,'Pinko','com.MarkL.Plinko',250,'0','US','spread',NULL,1,1,30,'Pinko'),
(407,'install',2,1,4,0,NULL,1,23,0,'2024-12-06 15:17:29','2024-12-06 15:17:29',NULL,'Pinko','com.MarkL.Plinko',250,'0','RU','spread',NULL,1,1,30,'Pinko'),
(408,'install',2,1,4,0,NULL,1,23,0,'2024-12-06 15:18:39','2024-12-06 15:18:39',NULL,'Plinko Blast','com.game.sweet.land.scape',600,'0','DE','spread',NULL,1,1,30,'Plinko Blast'),
(409,'install',2,1,4,0,NULL,1,23,0,'2024-12-06 15:19:00','2024-12-06 15:19:00',NULL,'Plinko Blast','com.game.sweet.land.scape',600,'0','IT','spread',NULL,1,1,30,'Plinko Blast'),
(410,'install',2,1,4,1,NULL,1,23,0,'2024-12-06 15:19:26','2024-12-06 15:19:26',NULL,'Plinko Blast','com.game.sweet.land.scape',600,'0','PL','spread',NULL,1,1,30,'Plinko Blast'),
(411,'install',2,1,4,1,NULL,1,23,0,'2024-12-06 15:20:24','2024-12-06 15:20:24',NULL,'Plinko Go','com.plinco.plink.games',75,'0','DE','spread',NULL,1,1,30,'Plinko Go'),
(412,'install',2,1,4,1,NULL,1,23,0,'2024-12-06 15:20:52','2024-12-06 15:20:52',NULL,'Plinko Go','com.plinco.plink.games',75,'0','IT','spread',NULL,1,1,30,'Plinko Go'),
(413,'install',2,1,4,1,NULL,1,23,0,'2024-12-06 15:21:18','2024-12-06 15:21:18',NULL,'Plinko Go','com.plinco.plink.games',75,'0','PL','spread',NULL,1,1,30,'Plinko Go'),
(414,'install',2,1,4,1,NULL,1,23,0,'2024-12-07 09:35:51','2024-12-07 09:35:51',NULL,'Plinko Go','com.plinco.plink.games',75,'0','DE','spread',NULL,1,1,30,'Plinko Go'),
(415,'install',2,1,4,1,NULL,1,23,0,'2024-12-07 09:36:14','2024-12-07 09:36:14',NULL,'Plinko Go','com.plinco.plink.games',75,'0','IT','spread',NULL,1,1,30,'Plinko Go'),
(416,'install',2,1,4,1,NULL,1,23,0,'2024-12-07 09:36:31','2024-12-07 09:36:31',NULL,'Plinko Go','com.plinco.plink.games',75,'0','PL','spread',NULL,1,1,30,'Plinko Go'),
(417,'install',2,1,4,1,NULL,1,23,0,'2024-12-07 09:38:42','2024-12-07 09:38:42',NULL,'Evolution Idle Tycoon Clicker','com.littlebitgames.idleevolution',1000,'0','US','spread',NULL,1,0,120,'evolution'),
(418,'install',2,1,4,1,NULL,1,23,0,'2024-12-07 09:39:46','2024-12-07 09:39:46',NULL,'Startup Empire - Idle Tycoon','com.littlebit.itcorp',1000,'0','US','spread',NULL,1,0,120,'empire'),
(419,'install',2,1,4,1,NULL,1,23,0,'2024-12-07 09:40:32','2024-12-07 09:40:32',NULL,'Pinko','com.MarkL.Plinko',200,'0','US','spread',NULL,1,1,30,'Pinko'),
(420,'install',2,1,4,1,NULL,1,23,0,'2024-12-07 09:40:52','2024-12-07 09:40:52',NULL,'Pinko','com.MarkL.Plinko',200,'0','RU','spread',NULL,1,1,30,'Pinko'),
(421,'install',2,1,4,1,NULL,1,23,0,'2024-12-08 07:17:50','2024-12-08 07:17:50',NULL,'Plinko Go','com.plinco.plink.games',130,'0','DE','spread',NULL,1,1,30,'Plinko Go'),
(422,'install',2,1,4,1,NULL,1,23,0,'2024-12-08 07:18:06','2024-12-08 07:18:06',NULL,'Plinko Go','com.plinco.plink.games',130,'0','PL','spread',NULL,1,1,30,'Plinko Go'),
(423,'install',2,1,4,1,NULL,1,23,0,'2024-12-08 07:18:28','2024-12-08 07:18:28',NULL,'Plinko Go','com.plinco.plink.games',130,'0','IT','spread',NULL,1,1,30,'Plinko Go'),
(424,'install',2,1,4,1,NULL,1,23,0,'2024-12-08 07:19:51','2024-12-08 07:19:51',NULL,'Plinko Blast','com.game.sweet.land.scape',600,'0','DE','spread',NULL,1,1,30,'Plinko Blast'),
(425,'install',2,1,4,1,NULL,1,23,0,'2024-12-08 07:20:12','2024-12-08 07:20:12',NULL,'Plinko Blast','com.game.sweet.land.scape',600,'0','IT','spread',NULL,1,1,30,'Plinko Blast'),
(426,'install',2,1,4,1,NULL,1,23,0,'2024-12-08 07:20:40','2024-12-08 07:20:40',NULL,'Plinko Blast','com.game.sweet.land.scape',600,'0','PL','spread',NULL,1,1,30,'Plinko Blast'),
(427,'install',2,1,4,1,NULL,1,23,0,'2024-12-08 07:21:06','2024-12-08 07:21:06',NULL,'Pinko','com.MarkL.Plinko',250,'0','US','spread',NULL,1,1,30,'Pinko'),
(428,'install',2,1,4,1,NULL,1,23,0,'2024-12-08 07:21:23','2024-12-08 07:21:23',NULL,'Pinko','com.MarkL.Plinko',250,'0','RU','spread',NULL,1,1,30,'Pinko'),
(429,'install',2,1,4,1,NULL,1,23,0,'2024-12-09 09:26:37','2024-12-09 09:26:37',NULL,'Pinko','com.MarkL.Plinko',250,'0','US','spread',NULL,1,1,30,'Pinko'),
(430,'install',2,1,4,1,NULL,1,23,0,'2024-12-09 09:27:00','2024-12-09 09:27:00',NULL,'Pinko','com.MarkL.Plinko',250,'0','RU','spread',NULL,1,1,30,'Pinko'),
(431,'install',2,1,4,1,NULL,1,23,0,'2024-12-09 09:27:55','2024-12-09 09:27:55',NULL,'Plinko Go','com.plinco.plink.games',170,'0','DE','spread',NULL,1,1,30,'Plinko Go'),
(432,'install',2,1,4,1,NULL,1,23,0,'2024-12-09 09:29:24','2024-12-09 09:29:24',NULL,'Plinko Go','com.plinco.plink.games',170,'0','IT','spread',NULL,1,1,30,'Plinko Go'),
(433,'install',2,1,4,1,NULL,1,23,0,'2024-12-09 09:30:00','2024-12-09 09:30:00',NULL,'Plinko Go','com.plinco.plink.games',170,'0','PL','spread',NULL,1,1,30,'Plinko Go'),
(434,'install',2,1,4,1,NULL,1,23,0,'2024-12-09 09:33:28','2024-12-09 09:33:28',NULL,'Plinko Blast','com.game.sweet.land.scape',600,'0','DE','spread',NULL,1,1,30,'Plinko Blast'),
(435,'install',2,1,4,1,NULL,1,23,0,'2024-12-09 09:34:14','2024-12-09 09:34:14',NULL,'Plinko Blast','com.game.sweet.land.scape',600,'0','PL','spread',NULL,1,1,30,'Plinko Blast'),
(436,'install',2,1,4,1,NULL,1,23,0,'2024-12-09 09:34:37','2024-12-09 09:34:37',NULL,'Plinko Blast','com.game.sweet.land.scape',600,'0','IT','spread',NULL,1,1,30,'Plinko Blast'),
(437,'install',2,1,4,1,NULL,1,23,0,'2024-12-10 11:55:11','2024-12-10 11:55:11',NULL,'Plinko Blast','com.game.sweet.land.scape',600,'0','DE','spread',NULL,1,1,30,'Plinko Blast'),
(438,'install',2,1,4,1,NULL,1,23,0,'2024-12-10 11:55:30','2024-12-10 11:55:30',NULL,'Plinko Blast','com.game.sweet.land.scape',600,'0','IT','spread',NULL,1,1,30,'Plinko Blast'),
(439,'install',2,1,4,0,NULL,1,23,0,'2024-12-10 11:55:51','2024-12-10 11:55:51',NULL,'Plinko Blast','com.game.sweet.land.scape',600,'0','PL','spread',NULL,1,1,30,'Plinko Blast'),
(440,'install',2,1,4,0,NULL,1,23,0,'2024-12-10 11:56:31','2024-12-10 11:56:31',NULL,'Plinko Go','com.plinco.plink.games',200,'0','DE','spread',NULL,1,1,30,'Plinko Go'),
(441,'install',2,1,4,0,NULL,1,23,0,'2024-12-10 11:56:56','2024-12-10 11:56:56',NULL,'Plinko Go','com.plinco.plink.games',200,'0','IT','spread',NULL,1,1,30,'Plinko Go'),
(442,'install',2,1,4,0,NULL,1,23,0,'2024-12-10 11:57:15','2024-12-10 11:57:15',NULL,'Plinko Go','com.plinco.plink.games',200,'0','PL','spread',NULL,1,1,30,'Plinko Go'),
(443,'install',2,1,4,0,NULL,1,23,0,'2024-12-11 13:20:34','2024-12-11 13:20:34',NULL,'Plinko Go','com.plinco.plink.games',250,'0','DE','spread',NULL,1,1,30,'Plinko Go'),
(444,'install',2,1,4,0,NULL,1,23,0,'2024-12-11 13:20:53','2024-12-11 13:20:53',NULL,'Plinko Go','com.plinco.plink.games',250,'0','IT','spread',NULL,1,1,30,'Plinko Go'),
(445,'install',2,1,4,0,NULL,1,23,0,'2024-12-11 13:21:12','2024-12-11 13:21:12',NULL,'Plinko Go','com.plinco.plink.games',250,'0','PL','spread',NULL,1,1,30,'Plinko Go'),
(446,'install',2,1,4,0,NULL,1,23,0,'2024-12-11 13:25:30','2024-12-11 13:25:30',NULL,'Plunko','com.pl.plunkho.plinco.game',35,'0','DE','spread',NULL,1,1,30,'Plunko'),
(447,'install',2,1,4,0,NULL,1,23,0,'2024-12-11 13:25:51','2024-12-11 13:25:51',NULL,'Plunko','com.pl.plunkho.plinco.game',35,'0','IT','spread',NULL,1,1,30,'Plunko'),
(448,'install',2,1,4,0,NULL,1,23,0,'2024-12-11 13:26:09','2024-12-11 13:26:09',NULL,'Plunko','com.pl.plunkho.plinco.game',35,'0','PL','spread',NULL,1,1,30,'Plunko'),
(449,'install',2,1,4,0,NULL,1,23,0,'2024-12-11 13:27:11','2024-12-11 13:27:11',NULL,'Play Plinko','com.quest.plinkio.plunko.game',35,'0','DE','spread',NULL,1,1,30,'Play Plinko'),
(450,'install',2,1,4,0,NULL,1,23,0,'2024-12-11 13:27:31','2024-12-11 13:27:31',NULL,'Play Plinko','com.quest.plinkio.plunko.game',35,'0','PL','spread',NULL,1,1,30,'Play Plinko'),
(451,'install',2,1,4,0,NULL,1,23,0,'2024-12-11 13:27:50','2024-12-11 13:27:50',NULL,'Play Plinko','com.quest.plinkio.plunko.game',35,'0','IT','spread',NULL,1,1,30,'Play Plinko'),
(452,'install',2,1,4,0,NULL,1,23,0,'2024-12-11 15:56:31','2024-12-11 15:56:31',NULL,'Plinko Blast','com.game.sweet.land.scape',900,'0','DE','spread',NULL,1,1,30,'Plinko Blast'),
(453,'install',3,1,4,1,NULL,1,23,0,'2024-12-11 19:46:02','2024-12-11 19:46:02',NULL,'123','13',1,'0','any','fast',NULL,1,0,30,'123'),
(454,'install',2,1,4,0,NULL,1,23,0,'2024-12-12 06:21:49','2024-12-12 06:21:49',NULL,'Play Plinko','com.quest.plinkio.plunko.game',50,'0','DE','spread',NULL,1,1,30,'Play Plinko'),
(455,'install',2,1,4,0,NULL,1,23,0,'2024-12-12 06:22:11','2024-12-12 06:22:11',NULL,'Play Plinko','com.quest.plinkio.plunko.game',50,'0','IT','spread',NULL,1,1,30,'Play Plinko'),
(456,'install',2,1,4,0,NULL,1,23,0,'2024-12-12 06:22:31','2024-12-12 06:22:31',NULL,'Play Plinko','com.quest.plinkio.plunko.game',50,'0','PL','spread',NULL,1,1,30,'Play Plinko'),
(457,'install',2,1,4,0,NULL,1,23,0,'2024-12-12 06:23:15','2024-12-12 06:23:15',NULL,'Plunko','com.pl.plunkho.plinco.game',50,'0','DE','spread',NULL,1,1,30,'Plunko'),
(458,'install',2,1,4,0,NULL,1,23,0,'2024-12-12 06:23:33','2024-12-12 06:23:33',NULL,'Plunko','com.pl.plunkho.plinco.game',50,'0','IT','spread',NULL,1,1,30,'Plunko'),
(459,'install',2,1,4,0,NULL,1,23,0,'2024-12-12 06:23:51','2024-12-12 06:23:51',NULL,'Plunko','com.pl.plunkho.plinco.game',50,'0','PL','spread',NULL,1,1,30,'Plunko'),
(460,'install',2,1,4,0,NULL,1,23,0,'2024-12-12 06:26:27','2024-12-12 06:26:27',NULL,'Plin','com.plinco.plink.games',220,'0','DE','spread',NULL,1,1,30,'Plin'),
(461,'install',2,1,4,0,NULL,1,23,0,'2024-12-12 06:26:44','2024-12-12 06:26:44',NULL,'Plin','com.plinco.plink.games',220,'0','IT','spread',NULL,1,1,30,'Plin'),
(462,'install',2,1,4,0,NULL,1,23,0,'2024-12-12 06:27:03','2024-12-12 06:27:03',NULL,'Plin','com.plinco.plink.games',220,'0','PL','spread',NULL,1,1,30,'Plin'),
(463,'install',2,1,4,0,NULL,1,23,0,'2024-12-13 04:03:31','2024-12-13 04:03:31',NULL,'Plin','com.plinco.plink.games',350,'0','DE','spread',NULL,1,1,30,'Plin'),
(464,'install',2,1,4,0,NULL,1,23,0,'2024-12-13 04:03:59','2024-12-13 04:03:59',NULL,'Plin','com.plinco.plink.games',350,'0','PL','spread',NULL,1,1,30,'Plin'),
(465,'install',2,1,4,0,NULL,1,23,0,'2024-12-13 04:04:18','2024-12-13 04:04:18',NULL,'Plin','com.plinco.plink.games',350,'0','IT','spread',NULL,1,1,30,'Plin'),
(466,'install',2,1,4,0,NULL,1,23,0,'2024-12-13 04:04:52','2024-12-13 04:04:52',NULL,'Play Plinko','com.quest.plinkio.plunko.game',75,'0','DE','spread',NULL,1,1,30,'Play Plinko'),
(467,'install',2,1,4,0,NULL,1,23,0,'2024-12-13 04:05:15','2024-12-13 04:05:15',NULL,'Play Plinko','com.quest.plinkio.plunko.game',75,'0','PL','spread',NULL,1,1,30,'Play Plinko'),
(468,'install',2,1,4,0,NULL,1,23,0,'2024-12-13 04:05:32','2024-12-13 04:05:32',NULL,'Play Plinko','com.quest.plinkio.plunko.game',75,'0','IT','spread',NULL,1,1,30,'Play Plinko'),
(469,'install',2,1,4,0,NULL,1,23,0,'2024-12-13 04:06:05','2024-12-13 04:06:05',NULL,'Plunko','com.pl.plunkho.plinco.game',75,'0','DE','spread',NULL,1,1,30,'Plunko'),
(470,'install',2,1,4,0,NULL,1,23,0,'2024-12-13 04:06:23','2024-12-13 04:06:23',NULL,'Plunko','com.pl.plunkho.plinco.game',75,'0','PL','spread',NULL,1,1,30,'Plunko'),
(471,'install',2,1,4,0,NULL,1,23,0,'2024-12-13 04:06:47','2024-12-13 04:06:47',NULL,'Plunko','com.pl.plunkho.plinco.game',75,'0','IT','spread',NULL,1,1,30,'Plunko'),
(472,'install',2,1,4,0,NULL,1,23,0,'2024-12-13 09:50:16','2024-12-13 09:50:16',NULL,'Plin','com.plinco.plink.games',350,'0','DE','spread',NULL,1,1,30,'Plin'),
(473,'install',2,1,4,0,NULL,1,23,0,'2024-12-13 09:50:36','2024-12-13 09:50:36',NULL,'Plin','com.plinco.plink.games',350,'0','PL','spread',NULL,1,1,30,'Plin'),
(474,'install',2,1,4,0,NULL,1,23,0,'2024-12-13 09:50:55','2024-12-13 09:50:55',NULL,'Plin','com.plinco.plink.games',350,'0','IT','spread',NULL,1,1,30,'Plin'),
(475,'install',2,1,4,0,NULL,1,23,0,'2024-12-14 07:20:40','2024-12-14 07:20:40',NULL,'Evolution Idle Tycoon Clicker','com.littlebitgames.idleevolution',150,'1','US','spread',NULL,1,0,120,'clicker'),
(476,'install',2,1,4,1,NULL,1,23,0,'2024-12-14 18:41:53','2024-12-14 18:41:53',NULL,'Evolution Idle Tycoon Clicker','com.littlebitgames.idleevolution',150,'1','US','spread',NULL,1,0,30,'evolution'),
(477,'install',3,1,4,1,NULL,1,23,0,'2024-12-14 19:51:55','2024-12-14 19:51:55',NULL,'Evolution Idle Tycoon Clicker','com.littlebitgames.idleevolution',1000,'0','US','spread',NULL,1,0,30,'evolution'),
(478,'install',3,1,4,0,NULL,1,23,0,'2024-12-15 05:58:46','2024-12-15 05:59:03','2024-12-15 05:59:03','Startup Empire - Idle Tycoon','com.littlebit.itcorp',500,'0','US','fast',NULL,1,0,150,'clicker'),
(479,'install',3,1,4,1,NULL,1,23,0,'2024-12-15 06:00:04','2024-12-15 06:00:04',NULL,'Evolution Idle Tycoon Clicker','com.littlebitgames.idleevolution',500,'0','US','fast',NULL,1,0,150,'clicker'),
(480,'install',3,1,4,1,NULL,1,23,0,'2024-12-15 06:00:06','2024-12-15 06:00:06',NULL,'Evolution Idle Tycoon Clicker','com.littlebitgames.idleevolution',500,'0','US','fast',NULL,1,0,150,'clicker'),
(481,'install',3,1,4,1,NULL,1,23,0,'2024-12-15 06:29:28','2024-12-15 06:30:29','2024-12-15 06:30:29','Evolution Idle Tycoon Clicker','com.littlebitgames.idleevolution',100,'0','US','spread',NULL,1,1,30,'Evolution Idle Tycoon Clicker');
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_tokens`
--

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sessions` (
  `id` varchar(255) NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text,
  `payload` longtext NOT NULL,
  `last_activity` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `telescope_entries`
--

DROP TABLE IF EXISTS `telescope_entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `telescope_entries` (
  `sequence` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` char(36) NOT NULL,
  `batch_id` char(36) NOT NULL,
  `family_hash` varchar(255) DEFAULT NULL,
  `should_display_on_index` tinyint(1) NOT NULL DEFAULT '1',
  `type` varchar(20) NOT NULL,
  `content` longtext NOT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`sequence`),
  UNIQUE KEY `telescope_entries_uuid_unique` (`uuid`),
  KEY `telescope_entries_batch_id_index` (`batch_id`),
  KEY `telescope_entries_family_hash_index` (`family_hash`),
  KEY `telescope_entries_created_at_index` (`created_at`),
  KEY `telescope_entries_type_should_display_on_index_index` (`type`,`should_display_on_index`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `telescope_entries`
--

LOCK TABLES `telescope_entries` WRITE;
/*!40000 ALTER TABLE `telescope_entries` DISABLE KEYS */;
INSERT INTO `telescope_entries` VALUES
(1,'9d84fd5c-03bb-46fa-a55b-482b049e9d9d','9d84fd5c-5540-4f8d-af18-feb5e3a9177e',NULL,1,'query','{\"connection\":\"mysql\",\"bindings\":[],\"sql\":\"select table_name as `name`, (data_length + index_length) as `size`, table_comment as `comment`, engine as `engine`, table_collation as `collation` from information_schema.tables where table_schema = \'xloving_panel\' and table_type in (\'BASE TABLE\', \'SYSTEM VERSIONED\') order by table_name\",\"time\":\"13.40\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/artisan\",\"line\":35,\"hash\":\"c4e9551760139d2eca52301e12b6b09f\",\"hostname\":\"e4985f5898dd\"}','2024-11-18 15:51:59'),
(2,'9d84fd5c-0650-4e68-b0cf-18412aed2320','9d84fd5c-5540-4f8d-af18-feb5e3a9177e',NULL,1,'query','{\"connection\":\"mysql\",\"bindings\":[],\"sql\":\"select table_name as `name`, (data_length + index_length) as `size`, table_comment as `comment`, engine as `engine`, table_collation as `collation` from information_schema.tables where table_schema = \'xloving_panel\' and table_type in (\'BASE TABLE\', \'SYSTEM VERSIONED\') order by table_name\",\"time\":\"2.07\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/artisan\",\"line\":35,\"hash\":\"c4e9551760139d2eca52301e12b6b09f\",\"hostname\":\"e4985f5898dd\"}','2024-11-18 15:51:59'),
(3,'9d84fd5c-085f-45d7-a4db-ae129add86fc','9d84fd5c-5540-4f8d-af18-feb5e3a9177e',NULL,1,'query','{\"connection\":\"mysql\",\"bindings\":[],\"sql\":\"select `migration` from `migrations` order by `batch` asc, `migration` asc\",\"time\":\"0.87\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/artisan\",\"line\":35,\"hash\":\"ed08a59c7f0b8851f0fd2291ca94d5c7\",\"hostname\":\"e4985f5898dd\"}','2024-11-18 15:51:59'),
(4,'9d84fd5c-08ff-432b-9638-cc42f927a47a','9d84fd5c-5540-4f8d-af18-feb5e3a9177e',NULL,1,'query','{\"connection\":\"mysql\",\"bindings\":[],\"sql\":\"select `migration` from `migrations` order by `batch` asc, `migration` asc\",\"time\":\"0.64\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/artisan\",\"line\":35,\"hash\":\"ed08a59c7f0b8851f0fd2291ca94d5c7\",\"hostname\":\"e4985f5898dd\"}','2024-11-18 15:51:59'),
(5,'9d84fd5c-099f-4c91-ad4c-ed4b5590abc4','9d84fd5c-5540-4f8d-af18-feb5e3a9177e',NULL,1,'query','{\"connection\":\"mysql\",\"bindings\":[],\"sql\":\"select max(`batch`) as aggregate from `migrations`\",\"time\":\"0.58\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/artisan\",\"line\":35,\"hash\":\"06e60d7b3d1a0c2de504de4e6f27735e\",\"hostname\":\"e4985f5898dd\"}','2024-11-18 15:51:59'),
(6,'9d84fd5c-1418-4a7e-b9e1-805697a421c1','9d84fd5c-5540-4f8d-af18-feb5e3a9177e',NULL,1,'query','{\"connection\":\"mysql\",\"bindings\":[],\"sql\":\"create table `telescope_entries` (`sequence` bigint unsigned not null auto_increment primary key, `uuid` char(36) not null, `batch_id` char(36) not null, `family_hash` varchar(255) null, `should_display_on_index` tinyint(1) not null default \'1\', `type` varchar(20) not null, `content` longtext not null, `created_at` datetime null) default character set utf8mb4 collate \'utf8mb4_0900_ai_ci\'\",\"time\":\"18.12\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2024_11_18_154802_create_telescope_entries_table.php\",\"line\":24,\"hash\":\"7be9c2546dcf42daadb5789893134bb2\",\"hostname\":\"e4985f5898dd\"}','2024-11-18 15:51:59'),
(7,'9d84fd5c-19b3-4f8a-b65b-984afdb2a9f1','9d84fd5c-5540-4f8d-af18-feb5e3a9177e',NULL,1,'query','{\"connection\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `telescope_entries` add unique `telescope_entries_uuid_unique`(`uuid`)\",\"time\":\"13.88\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2024_11_18_154802_create_telescope_entries_table.php\",\"line\":24,\"hash\":\"9fb859ae1faff74c6b9e0b70dfd8eea9\",\"hostname\":\"e4985f5898dd\"}','2024-11-18 15:51:59'),
(8,'9d84fd5c-209d-471e-8ab2-0d1617e5b32c','9d84fd5c-5540-4f8d-af18-feb5e3a9177e',NULL,1,'query','{\"connection\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `telescope_entries` add index `telescope_entries_batch_id_index`(`batch_id`)\",\"time\":\"17.16\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2024_11_18_154802_create_telescope_entries_table.php\",\"line\":24,\"hash\":\"2b075509a9242d6e3f622536c5ccca07\",\"hostname\":\"e4985f5898dd\"}','2024-11-18 15:51:59'),
(9,'9d84fd5c-2615-487e-9d53-b6078170b05e','9d84fd5c-5540-4f8d-af18-feb5e3a9177e',NULL,1,'query','{\"connection\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `telescope_entries` add index `telescope_entries_family_hash_index`(`family_hash`)\",\"time\":\"13.48\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2024_11_18_154802_create_telescope_entries_table.php\",\"line\":24,\"hash\":\"3d25a2a244bd2028dfa0326d3dbf7f4c\",\"hostname\":\"e4985f5898dd\"}','2024-11-18 15:51:59'),
(10,'9d84fd5c-2c52-4537-90c4-1a5c8f3a56d9','9d84fd5c-5540-4f8d-af18-feb5e3a9177e',NULL,1,'query','{\"connection\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `telescope_entries` add index `telescope_entries_created_at_index`(`created_at`)\",\"time\":\"15.45\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2024_11_18_154802_create_telescope_entries_table.php\",\"line\":24,\"hash\":\"7352e7f84460fb7ffc450e7ea4de9dc7\",\"hostname\":\"e4985f5898dd\"}','2024-11-18 15:51:59'),
(11,'9d84fd5c-3243-45a6-82c0-1480d016cdc2','9d84fd5c-5540-4f8d-af18-feb5e3a9177e',NULL,1,'query','{\"connection\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `telescope_entries` add index `telescope_entries_type_should_display_on_index_index`(`type`, `should_display_on_index`)\",\"time\":\"14.69\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2024_11_18_154802_create_telescope_entries_table.php\",\"line\":24,\"hash\":\"7317a4cad2dfa1a5167548a6acd0b6a5\",\"hostname\":\"e4985f5898dd\"}','2024-11-18 15:51:59'),
(12,'9d84fd5c-38ed-4bd9-abcc-b0e50c2078b4','9d84fd5c-5540-4f8d-af18-feb5e3a9177e',NULL,1,'query','{\"connection\":\"mysql\",\"bindings\":[],\"sql\":\"create table `telescope_entries_tags` (`entry_uuid` char(36) not null, `tag` varchar(255) not null, primary key (`entry_uuid`, `tag`)) default character set utf8mb4 collate \'utf8mb4_0900_ai_ci\'\",\"time\":\"15.94\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2024_11_18_154802_create_telescope_entries_table.php\",\"line\":41,\"hash\":\"0137dc2b927e292e1e12ecb8c3266a74\",\"hostname\":\"e4985f5898dd\"}','2024-11-18 15:51:59'),
(13,'9d84fd5c-3d22-4db3-9bb8-f62bf5e75ded','9d84fd5c-5540-4f8d-af18-feb5e3a9177e',NULL,1,'query','{\"connection\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `telescope_entries_tags` add index `telescope_entries_tags_tag_index`(`tag`)\",\"time\":\"10.22\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2024_11_18_154802_create_telescope_entries_table.php\",\"line\":41,\"hash\":\"0bdb35d17e876d6225a7774a2c17647d\",\"hostname\":\"e4985f5898dd\"}','2024-11-18 15:51:59'),
(14,'9d84fd5c-4c32-4534-a533-e2460166569f','9d84fd5c-5540-4f8d-af18-feb5e3a9177e',NULL,1,'query','{\"connection\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `telescope_entries_tags` add constraint `telescope_entries_tags_entry_uuid_foreign` foreign key (`entry_uuid`) references `telescope_entries` (`uuid`) on delete cascade\",\"time\":\"38.02\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2024_11_18_154802_create_telescope_entries_table.php\",\"line\":41,\"hash\":\"662a818f80a3a9ba2570081fd7a6af2f\",\"hostname\":\"e4985f5898dd\"}','2024-11-18 15:51:59'),
(15,'9d84fd5c-5236-47ac-b9f1-a79d71ed311d','9d84fd5c-5540-4f8d-af18-feb5e3a9177e',NULL,1,'query','{\"connection\":\"mysql\",\"bindings\":[],\"sql\":\"create table `telescope_monitoring` (`tag` varchar(255) not null, primary key (`tag`)) default character set utf8mb4 collate \'utf8mb4_0900_ai_ci\'\",\"time\":\"14.76\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2024_11_18_154802_create_telescope_entries_table.php\",\"line\":54,\"hash\":\"ea2c8bfd9f5fbb463e57bf0a39681d05\",\"hostname\":\"e4985f5898dd\"}','2024-11-18 15:51:59'),
(16,'9d84fd5c-543c-4455-98ce-ef422c092506','9d84fd5c-5540-4f8d-af18-feb5e3a9177e',NULL,1,'query','{\"connection\":\"mysql\",\"bindings\":[],\"sql\":\"insert into `migrations` (`migration`, `batch`) values (\'2024_11_18_154802_create_telescope_entries_table\', 8)\",\"time\":\"2.46\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/artisan\",\"line\":35,\"hash\":\"f2b8e8e4266db16aec6db940c643eb68\",\"hostname\":\"e4985f5898dd\"}','2024-11-18 15:51:59'),
(17,'9d84fd5c-54b1-45aa-b687-49f02ab31aa7','9d84fd5c-5540-4f8d-af18-feb5e3a9177e',NULL,1,'command','{\"command\":\"migrate\",\"exit_code\":0,\"arguments\":{\"command\":\"migrate\"},\"options\":{\"database\":null,\"force\":false,\"path\":[],\"realpath\":false,\"schema-path\":null,\"pretend\":false,\"seed\":false,\"seeder\":null,\"step\":false,\"graceful\":false,\"isolated\":false,\"help\":false,\"quiet\":false,\"verbose\":false,\"version\":false,\"ansi\":null,\"no-interaction\":false,\"env\":null},\"hostname\":\"e4985f5898dd\"}','2024-11-18 15:51:59'),
(18,'9d84fda6-a7fe-4ba7-befc-2fce7beed3a3','9d84fda6-ac1e-4699-b00f-f50e612714e1',NULL,1,'view','{\"name\":\"welcome\",\"path\":\"\\/resources\\/views\\/welcome.blade.php\",\"data\":[],\"hostname\":\"e4985f5898dd\"}','2024-11-18 15:52:48'),
(19,'9d84fda6-ab2a-41db-9d22-debe15bc3e97','9d84fda6-ac1e-4699-b00f-f50e612714e1',NULL,1,'request','{\"ip_address\":\"172.21.0.6\",\"uri\":\"\\/\",\"method\":\"GET\",\"controller_action\":\"Closure\",\"middleware\":[\"web\"],\"headers\":{\"sec-gpc\":\"1\",\"dnt\":\"1\",\"accept-language\":\"en-US,ru;q=0.7,en;q=0.3\",\"accept\":\"text\\/html,application\\/xhtml+xml,application\\/xml;q=0.9,*\\/*;q=0.8\",\"user-agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64; rv:132.0) Gecko\\/20100101 Firefox\\/132.0\",\"upgrade-insecure-requests\":\"1\",\"sec-fetch-dest\":\"document\",\"cdn-loop\":\"cloudflare; loops=1\",\"cf-connecting-ip\":\"78.140.201.150\",\"sec-fetch-mode\":\"navigate\",\"sec-fetch-site\":\"none\",\"cf-visitor\":\"{\\\"scheme\\\":\\\"https\\\"}\",\"sec-fetch-user\":\"?1\",\"priority\":\"u=0, i\",\"accept-encoding\":\"gzip, br\",\"cf-ipcountry\":\"RU\",\"cookie\":\"XSRF-TOKEN=eyJpdiI6IlNwTVpVVVJhZXl5TW00OGZmcm51NVE9PSIsInZhbHVlIjoiZ3dkVzltZDFZUHhjbTdzUndMMzA2RjVMbnUwMUh5eVYweXR6QVpVQjVyT2dHWlJUZE54WWR1cVNNeEl6alF5b0dFbkRFQVptTWJKQ2dzKzlvQ3RUNUwyaEY0ekNEODkvak5ZbHhzVFZrckV3cENBZURQMkJ4NXF6akJsRjJya2giLCJtYWMiOiI1MjMzODZmYjRjNjk4NTljYzFlMTk1OTdhNzZlZWNiMWY5Y2FlMzYzYTZmMmY0YzA0MzA5ZDMxMzdjMzRlOGQzIiwidGFnIjoiIn0%3D; xloving_panel_session=eyJpdiI6Ikh6aVRUdVY2RlQ1UFdPTlVUajlkNXc9PSIsInZhbHVlIjoiaW1rcSsybzJId0c0SG1GdU42UkJLczJzQW9JTjVzdjVLKzdZRlRuMm1yZ2djZlhnNENISU1icUN2VWNVanFkZzN4OU42dHpqOUZBZDc3azJTdGE1cXVSTEFzL2gzSnRBR1BrbUJoSVdWb05UM2ppL2pMbGNadlIyVlBHZGpuY2IiLCJtYWMiOiI3NTk5NzIwMmUxNzIxYzAzYzJlMDQwODNjMTcwYTU2ZjljOGUwNTYwMTQ1ZjA5ZmQ2OTgwNzNiNjVhODdhZTAxIiwidGFnIjoiIn0%3D\",\"cf-ray\":\"8e49213328393bcb-WAW\",\"x-original-uri\":\"\\/\",\"x-forwarded-port\":\"80\",\"x-forwarded-ssl\":\"on\",\"x-forwarded-proto\":\"https\",\"x-forwarded-host\":\"panel.fuckrkn.club\",\"x-forwarded-for\":\"78.140.201.150, 162.158.103.36\",\"x-real-ip\":\"162.158.103.36\",\"connection\":\"close\",\"host\":\"panel.fuckrkn.club\"},\"payload\":[],\"session\":{\"_token\":\"oFzC2exbhJfWsq49Rc7CCXQydhmfIPT4zKSWjiXY\",\"_previous\":{\"url\":\"http:\\/\\/panel.fuckrkn.club\"},\"_flash\":{\"old\":[],\"new\":[]}},\"response_status\":200,\"response\":{\"view\":\"\\/var\\/www\\/html\\/resources\\/views\\/welcome.blade.php\",\"data\":[]},\"duration\":131,\"memory\":22,\"hostname\":\"e4985f5898dd\"}','2024-11-18 15:52:48'),
(20,'9d84fdb5-0f8b-4c05-9a5d-0dfd1e79fed7','9d84fdb5-1421-4057-a120-0fe95962fd95',NULL,1,'view','{\"name\":\"auth.login\",\"path\":\"\\/resources\\/views\\/auth\\/login.blade.php\",\"data\":[],\"hostname\":\"e4985f5898dd\"}','2024-11-18 15:52:57'),
(21,'9d84fdb5-1240-432e-8923-11c7097887cf','9d84fdb5-1421-4057-a120-0fe95962fd95',NULL,1,'view','{\"name\":\"layouts.auth\",\"path\":\"\\/resources\\/views\\/layouts\\/auth.blade.php\",\"data\":[],\"hostname\":\"e4985f5898dd\"}','2024-11-18 15:52:57'),
(22,'9d84fdb5-132e-4840-869a-3270bf851ce7','9d84fdb5-1421-4057-a120-0fe95962fd95',NULL,1,'request','{\"ip_address\":\"172.21.0.6\",\"uri\":\"\\/login\",\"method\":\"GET\",\"controller_action\":\"App\\\\Http\\\\Controllers\\\\Auth\\\\LoginController@showLoginForm\",\"middleware\":[\"web\",\"guest\"],\"headers\":{\"referer\":\"https:\\/\\/panel.fuckrkn.club\\/\",\"sec-gpc\":\"1\",\"dnt\":\"1\",\"accept-language\":\"en-US,ru;q=0.7,en;q=0.3\",\"accept\":\"text\\/html,application\\/xhtml+xml,application\\/xml;q=0.9,*\\/*;q=0.8\",\"user-agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64; rv:132.0) Gecko\\/20100101 Firefox\\/132.0\",\"upgrade-insecure-requests\":\"1\",\"sec-fetch-dest\":\"document\",\"cdn-loop\":\"cloudflare; loops=1\",\"cf-connecting-ip\":\"78.140.201.150\",\"sec-fetch-mode\":\"navigate\",\"sec-fetch-site\":\"same-origin\",\"cf-visitor\":\"{\\\"scheme\\\":\\\"https\\\"}\",\"sec-fetch-user\":\"?1\",\"priority\":\"u=0, i\",\"accept-encoding\":\"gzip, br\",\"cf-ipcountry\":\"RU\",\"cookie\":\"XSRF-TOKEN=eyJpdiI6IkdUQVlBb21aVzh5K0laSUh0RmVCOGc9PSIsInZhbHVlIjoiTExoQXlkaExYcUpDSWtCZCt2YlZzZW5QNzJldzliZFkrbFg5VDJMZjMrL29QWWFoeFJrRkxITmxkZEFIcTQrVGg4YlFQN2lTcWYwQ0hzOHJQQ2dCSUFBOTIzbE5qWHR6ckpLWHdpREpxQzdZZmZXUGhacStWSHBHOS9jV0tsZTAiLCJtYWMiOiIwMmRhNWVjMWI3MzFkNDI2OGEzYTQ3NTNmNWZmODI4NTdiZGU0NmViZDc3NmYwN2Y2NGRkMjA3ZmFiYzhjNWUyIiwidGFnIjoiIn0%3D; xloving_panel_session=eyJpdiI6Ink1Z1BrZkJ5RGlBTFo3U0haWm9MVFE9PSIsInZhbHVlIjoia3EyM0hiR0lTekpzWkpHYndCVnVMejV3akRtaGFycFFVQmhJR3ZnMnVqcWttOS9oaFp4MTFMY2YzVFBVSnI0S3hpK3FBVVdSc1RQZEluSzRLVjdLemlTbjMvZ0s5UGxMR3dGTzVwemR4QjNIU0tBYjRoVHNxL0FFUTRwVGdSeDgiLCJtYWMiOiJhNWMyY2JlMjNlYjhhMGZhZTE3YzhkM2M2NTNhMzRhZDA3MDZkNDZmZjE2ZjM5YTRjNzdhNTBiZGUyMjJkYmY4IiwidGFnIjoiIn0%3D\",\"cf-ray\":\"8e49216e1ac23bcb-WAW\",\"x-original-uri\":\"\\/login\",\"x-forwarded-port\":\"80\",\"x-forwarded-ssl\":\"on\",\"x-forwarded-proto\":\"https\",\"x-forwarded-host\":\"panel.fuckrkn.club\",\"x-forwarded-for\":\"78.140.201.150, 162.158.103.36\",\"x-real-ip\":\"162.158.103.36\",\"connection\":\"close\",\"host\":\"panel.fuckrkn.club\"},\"payload\":[],\"session\":{\"_token\":\"oFzC2exbhJfWsq49Rc7CCXQydhmfIPT4zKSWjiXY\",\"_previous\":{\"url\":\"http:\\/\\/panel.fuckrkn.club\\/login\"},\"_flash\":{\"old\":[],\"new\":[]}},\"response_status\":200,\"response\":{\"view\":\"\\/var\\/www\\/html\\/resources\\/views\\/auth\\/login.blade.php\",\"data\":[]},\"duration\":145,\"memory\":22,\"hostname\":\"e4985f5898dd\"}','2024-11-18 15:52:57'),
(23,'9d84fdc5-6b83-4d0c-8755-3fdf7b58f60d','9d84fdc5-d92b-46b1-bbc1-6d10d7eca912',NULL,1,'cache','{\"type\":\"missed\",\"key\":\"test1@test1.com|172.21.0.6\",\"hostname\":\"e4985f5898dd\"}','2024-11-18 15:53:08'),
(24,'9d84fdc5-7501-4a79-b350-b2d48306f9df','9d84fdc5-d92b-46b1-bbc1-6d10d7eca912',NULL,1,'query','{\"connection\":\"mysql\",\"bindings\":[],\"sql\":\"select * from `users` where `email` = \'test1@test1.com\' limit 1\",\"time\":\"3.60\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/app\\/Http\\/Middleware\\/RedirectIfAuthenticated.php\",\"line\":28,\"hash\":\"747ef04de752900539e8a3a1aee036ac\",\"hostname\":\"e4985f5898dd\"}','2024-11-18 15:53:08'),
(25,'9d84fdc5-7565-498a-a87f-bc57291843f6','9d84fdc5-d92b-46b1-bbc1-6d10d7eca912',NULL,1,'model','{\"action\":\"retrieved\",\"model\":\"App\\\\Models\\\\User\",\"count\":1,\"hostname\":\"e4985f5898dd\"}','2024-11-18 15:53:08'),
(26,'9d84fdc5-d832-431b-93e3-5a50b6d28e1c','9d84fdc5-d92b-46b1-bbc1-6d10d7eca912',NULL,1,'request','{\"ip_address\":\"172.21.0.6\",\"uri\":\"\\/login\",\"method\":\"POST\",\"controller_action\":\"App\\\\Http\\\\Controllers\\\\Auth\\\\LoginController@login\",\"middleware\":[\"web\",\"guest\"],\"headers\":{\"referer\":\"https:\\/\\/panel.fuckrkn.club\\/login\",\"sec-gpc\":\"1\",\"dnt\":\"1\",\"origin\":\"https:\\/\\/panel.fuckrkn.club\",\"content-type\":\"application\\/x-www-form-urlencoded\",\"accept-language\":\"en-US,ru;q=0.7,en;q=0.3\",\"accept\":\"text\\/html,application\\/xhtml+xml,application\\/xml;q=0.9,*\\/*;q=0.8\",\"user-agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64; rv:132.0) Gecko\\/20100101 Firefox\\/132.0\",\"upgrade-insecure-requests\":\"1\",\"sec-fetch-dest\":\"document\",\"cdn-loop\":\"cloudflare; loops=1\",\"cf-connecting-ip\":\"78.140.201.150\",\"sec-fetch-mode\":\"navigate\",\"sec-fetch-site\":\"same-origin\",\"cf-visitor\":\"{\\\"scheme\\\":\\\"https\\\"}\",\"sec-fetch-user\":\"?1\",\"priority\":\"u=0, i\",\"accept-encoding\":\"gzip, br\",\"cf-ipcountry\":\"RU\",\"cookie\":\"XSRF-TOKEN=eyJpdiI6InZhSzV4Y3NaZy9xQmFidi9veGRScHc9PSIsInZhbHVlIjoiRmdJL1N0WDF6azVDQmdtWExqcllWRjQ5dk9hbitLbzl4NnVybGgxVWdGeTdCT0JySUpPOG9QUVpSOUVaUkJiektPRnk1ZGxMY0JnOFNORW1rc1BKV0pLbWNKOWc3RXFpemxHOXB5VzdMUEFrV2NrVTZLVHpFV2YwbUNWamFwZEYiLCJtYWMiOiJhZGRmY2ZiMGYxM2NlOGRjYTFkMDI1OWVlNGM5MmUwZTQwYTI0ZTJmYWM5MTRlOWVkNGFlNGIwODBjNDU4NDU5IiwidGFnIjoiIn0%3D; xloving_panel_session=eyJpdiI6ImI5YUdPOFhOK3RtM3FyV1RBOGMrUGc9PSIsInZhbHVlIjoiVlJVZTQrL2NCbkZMRG40ek8wK2cvb3J6M1lhYThNM1FvVUs2eHAvc0ZCcm5rSkxDVHp4YmhHOVZIZnVXVVVWL044WnhHN0t2WDNYRm9sdSs1SGZwMXNIb2ZqM0lsaSsxOWk3TDdFL0dEb2ZkN2phVXhabXZUN2dNSDJJOWg1eTEiLCJtYWMiOiI2MzczMTdjM2I2Mjc5YzQ2MjA1NWNkMDhiZDIxODk3ZTk5N2RmMzYxZTI4OGM5Y2RmODBkYzBiNWQ2YTk2MWMxIiwidGFnIjoiIn0%3D\",\"cf-ray\":\"8e4921b0fa3b3bcb-WAW\",\"content-length\":\"91\",\"x-original-uri\":\"\\/login\",\"x-forwarded-port\":\"80\",\"x-forwarded-ssl\":\"on\",\"x-forwarded-proto\":\"https\",\"x-forwarded-host\":\"panel.fuckrkn.club\",\"x-forwarded-for\":\"78.140.201.150, 162.158.103.35\",\"x-real-ip\":\"162.158.103.35\",\"connection\":\"close\",\"host\":\"panel.fuckrkn.club\"},\"payload\":{\"_token\":\"oFzC2exbhJfWsq49Rc7CCXQydhmfIPT4zKSWjiXY\",\"email\":\"test1@test1.com\",\"password\":\"********\"},\"session\":{\"_token\":\"5Nv1rfoy5TCJOZKulAgTB1ZJJBOIk4YAULutMi5T\",\"_previous\":{\"url\":\"http:\\/\\/panel.fuckrkn.club\\/login\"},\"_flash\":{\"old\":[\"success\"],\"new\":[]},\"login_web_59ba36addc2b2f9401580f014c7f58ea4e30989d\":1,\"auth\":{\"password_confirmed_at\":1731945188},\"success\":\"You are logged in!\"},\"response_status\":302,\"response\":\"Redirected to http:\\/\\/panel.fuckrkn.club\\/home\",\"duration\":432,\"memory\":24,\"hostname\":\"e4985f5898dd\",\"user\":{\"id\":1,\"name\":\"test1\",\"email\":\"test1@test1.com\"}}','2024-11-18 15:53:08'),
(27,'9d84fdc6-5858-4def-88ec-cc0922e71212','9d84fdc6-6255-4ab7-a4b4-df7a14840a40',NULL,1,'query','{\"connection\":\"mysql\",\"bindings\":[],\"sql\":\"select * from `users` where `id` = 1 limit 1\",\"time\":\"3.49\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/public\\/index.php\",\"line\":54,\"hash\":\"082e27d9c4fc4a40315cae2c646c0509\",\"hostname\":\"e4985f5898dd\"}','2024-11-18 15:53:08'),
(28,'9d84fdc6-59e8-4363-97a1-56ac1e955806','9d84fdc6-6255-4ab7-a4b4-df7a14840a40',NULL,1,'model','{\"action\":\"retrieved\",\"model\":\"App\\\\Models\\\\User\",\"count\":1,\"hostname\":\"e4985f5898dd\"}','2024-11-18 15:53:08'),
(29,'9d84fdc6-5b67-4798-9102-534868887dec','9d84fdc6-6255-4ab7-a4b4-df7a14840a40',NULL,1,'query','{\"connection\":\"mysql\",\"bindings\":[],\"sql\":\"select count(*) as aggregate from `users`\",\"time\":\"0.78\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/app\\/Http\\/Controllers\\/HomeController.php\",\"line\":27,\"hash\":\"6c5274cfac96d79f6367317dfb756038\",\"hostname\":\"e4985f5898dd\",\"user\":{\"id\":1,\"name\":\"test1\",\"email\":\"test1@test1.com\"}}','2024-11-18 15:53:08'),
(30,'9d84fdc6-5d83-4d4e-893b-ac2d09a78944','9d84fdc6-6255-4ab7-a4b4-df7a14840a40',NULL,1,'view','{\"name\":\"home\",\"path\":\"\\/resources\\/views\\/home.blade.php\",\"data\":[\"widget\"],\"hostname\":\"e4985f5898dd\",\"user\":{\"id\":1,\"name\":\"test1\",\"email\":\"test1@test1.com\"}}','2024-11-18 15:53:08'),
(31,'9d84fdc6-5e4d-49b0-806e-6d7d8300dad1','9d84fdc6-6255-4ab7-a4b4-df7a14840a40',NULL,1,'view','{\"name\":\"layouts.admin\",\"path\":\"\\/resources\\/views\\/layouts\\/admin.blade.php\",\"data\":[\"widget\"],\"hostname\":\"e4985f5898dd\",\"user\":{\"id\":1,\"name\":\"test1\",\"email\":\"test1@test1.com\"}}','2024-11-18 15:53:08'),
(32,'9d84fdc6-6115-4d01-b926-2f7813d61492','9d84fdc6-6255-4ab7-a4b4-df7a14840a40',NULL,1,'request','{\"ip_address\":\"172.21.0.6\",\"uri\":\"\\/home\",\"method\":\"GET\",\"controller_action\":\"App\\\\Http\\\\Controllers\\\\HomeController@index\",\"middleware\":[\"web\",\"auth\"],\"headers\":{\"sec-gpc\":\"1\",\"dnt\":\"1\",\"accept-language\":\"en-US,ru;q=0.7,en;q=0.3\",\"accept\":\"text\\/html,application\\/xhtml+xml,application\\/xml;q=0.9,*\\/*;q=0.8\",\"user-agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64; rv:132.0) Gecko\\/20100101 Firefox\\/132.0\",\"upgrade-insecure-requests\":\"1\",\"sec-fetch-dest\":\"document\",\"cdn-loop\":\"cloudflare; loops=1\",\"cf-connecting-ip\":\"78.140.201.150\",\"sec-fetch-mode\":\"navigate\",\"sec-fetch-site\":\"cross-site\",\"cf-visitor\":\"{\\\"scheme\\\":\\\"https\\\"}\",\"sec-fetch-user\":\"?1\",\"priority\":\"u=0, i\",\"accept-encoding\":\"gzip, br\",\"cf-ipcountry\":\"RU\",\"cookie\":\"XSRF-TOKEN=eyJpdiI6InliLytXSUR1RDlCR0xacGlvZkMyV2c9PSIsInZhbHVlIjoidE9yWVNKSWlSM2hiME02UzRxQ2VXT1h2V1AxcWNRMGt5emxtR1QramNYd0dqK1V1RE1VczBNWWhJTFl0a2pRQ2hCQWdJVU5YcE8yZ1dPZG1rMjlHR1pvdkN2VUEvZXFKdnM0QzdmQjgyZFQzWHBydkNMK2VsQ0pFTzE1Nk9CTngiLCJtYWMiOiI2MDcxYzFmYTg2YjMwZTc1ZDEzMTRmZmNiMjUwZWE0M2QyOWI3ZjgxZGYzMjRjY2I1ODNjN2VkYTBlZDQ3NDkzIiwidGFnIjoiIn0%3D; xloving_panel_session=eyJpdiI6Ikd3TWRhd3N2UWU3V251TFFaaXdUa0E9PSIsInZhbHVlIjoiYnp5VlA1c0EzQ3JpSVkwcStUTWdkTFRjajlRWStyMnY3UVY2a3I3elFWVzFXWHpjZnhKbUxyU0lnN1VxL2pVbEhHYTNwcTVqbUpBR2MzUzhnMWZYSmxyOGdLNjVVK2JKWmsrZlJPZUhpTWp5VDRPcmtXZ0IzQWNwQjRHTHVmYSsiLCJtYWMiOiJjNjllM2E1ZmQ2NjBmNDJjNDlhYzY5MjYwZTE1NGMxYWMzMTA1Y2NhOWQ1MDRiYjM5ZDFlNGI4ODFiYzkyODMwIiwidGFnIjoiIn0%3D\",\"cf-ray\":\"8e4921b4c80a3bcb-WAW\",\"x-original-uri\":\"\\/home\",\"x-forwarded-port\":\"80\",\"x-forwarded-ssl\":\"on\",\"x-forwarded-proto\":\"https\",\"x-forwarded-host\":\"panel.fuckrkn.club\",\"x-forwarded-for\":\"78.140.201.150, 162.158.103.36\",\"x-real-ip\":\"162.158.103.36\",\"connection\":\"close\",\"host\":\"panel.fuckrkn.club\"},\"payload\":[],\"session\":{\"_token\":\"5Nv1rfoy5TCJOZKulAgTB1ZJJBOIk4YAULutMi5T\",\"_previous\":{\"url\":\"http:\\/\\/panel.fuckrkn.club\\/home\"},\"_flash\":{\"old\":[],\"new\":[]},\"login_web_59ba36addc2b2f9401580f014c7f58ea4e30989d\":1,\"auth\":{\"password_confirmed_at\":1731945188}},\"response_status\":200,\"response\":{\"view\":\"\\/var\\/www\\/html\\/resources\\/views\\/home.blade.php\",\"data\":{\"widget\":{\"users\":1}}},\"duration\":169,\"memory\":24,\"hostname\":\"e4985f5898dd\",\"user\":{\"id\":1,\"name\":\"test1\",\"email\":\"test1@test1.com\"}}','2024-11-18 15:53:08'),
(33,'9d84fe1d-cba0-4f25-9fc2-f4f54aaaa4e7','9d84fe1d-d41e-4847-b6f2-5717f32c9171',NULL,1,'query','{\"connection\":\"mysql\",\"bindings\":[],\"sql\":\"select * from `users` where `id` = 1 limit 1\",\"time\":\"2.98\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/public\\/index.php\",\"line\":54,\"hash\":\"082e27d9c4fc4a40315cae2c646c0509\",\"hostname\":\"e4985f5898dd\"}','2024-11-18 15:54:06'),
(34,'9d84fe1d-cd06-4c5c-a35a-2d80ab29f216','9d84fe1d-d41e-4847-b6f2-5717f32c9171',NULL,1,'model','{\"action\":\"retrieved\",\"model\":\"App\\\\Models\\\\User\",\"count\":1,\"hostname\":\"e4985f5898dd\"}','2024-11-18 15:54:06'),
(35,'9d84fe1d-cf8f-4ad9-b839-345ad6ed544e','9d84fe1d-d41e-4847-b6f2-5717f32c9171',NULL,1,'view','{\"name\":\"tasks\",\"path\":\"\\/resources\\/views\\/tasks.blade.php\",\"data\":[],\"hostname\":\"e4985f5898dd\",\"user\":{\"id\":1,\"name\":\"test1\",\"email\":\"test1@test1.com\"}}','2024-11-18 15:54:06'),
(36,'9d84fe1d-d062-4703-a98c-27298a1d9406','9d84fe1d-d41e-4847-b6f2-5717f32c9171',NULL,1,'view','{\"name\":\"layouts.admin\",\"path\":\"\\/resources\\/views\\/layouts\\/admin.blade.php\",\"data\":[],\"hostname\":\"e4985f5898dd\",\"user\":{\"id\":1,\"name\":\"test1\",\"email\":\"test1@test1.com\"}}','2024-11-18 15:54:06'),
(37,'9d84fe1d-d2ff-47f1-adc1-a4773fed9ba9','9d84fe1d-d41e-4847-b6f2-5717f32c9171',NULL,1,'request','{\"ip_address\":\"172.21.0.6\",\"uri\":\"\\/tasks\",\"method\":\"GET\",\"controller_action\":\"App\\\\Http\\\\Controllers\\\\TaskController@index\",\"middleware\":[\"web\",\"auth\"],\"headers\":{\"referer\":\"https:\\/\\/panel.fuckrkn.club\\/home\",\"sec-gpc\":\"1\",\"dnt\":\"1\",\"accept-language\":\"en-US,ru;q=0.7,en;q=0.3\",\"accept\":\"text\\/html,application\\/xhtml+xml,application\\/xml;q=0.9,*\\/*;q=0.8\",\"user-agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64; rv:132.0) Gecko\\/20100101 Firefox\\/132.0\",\"upgrade-insecure-requests\":\"1\",\"sec-fetch-dest\":\"document\",\"cdn-loop\":\"cloudflare; loops=1\",\"cf-connecting-ip\":\"78.140.201.150\",\"sec-fetch-mode\":\"navigate\",\"sec-fetch-site\":\"same-origin\",\"cf-visitor\":\"{\\\"scheme\\\":\\\"https\\\"}\",\"sec-fetch-user\":\"?1\",\"priority\":\"u=0, i\",\"accept-encoding\":\"gzip, br\",\"cf-ipcountry\":\"RU\",\"cookie\":\"XSRF-TOKEN=eyJpdiI6IlZsUWgrTnc4SXV2YkhPcjBtTjBlRFE9PSIsInZhbHVlIjoia1VnMzlSRWFGbUxHZUE0NUExNDNOekJBVEdpQVFRNENoUE01b2FPcjI2dDhUbjJCcTdSVkFtdkdwNHlXTXN0TVUzaEtKa2lCUUplOFFudnFxcHRkV3FMMEM1dnNTN0JkVld2MGUvSzJIUTlsVFg1aXEzVEhtbWNyWTYyRko4bDEiLCJtYWMiOiJlOWRiM2M3YzRiYjQ5ZGE3YmFiNTFiN2M5ZDgzZDM5ZjQ0MWZkMTY2OGJhNGIxNWE3MGUzOTI5NjgzNDYxZDM0IiwidGFnIjoiIn0%3D; xloving_panel_session=eyJpdiI6IlZORVlGK3pFRXhudk56cW1GTkJUR2c9PSIsInZhbHVlIjoiLzNIYk4rN215alZSUVpPbDN2NnVpcnFCTHFBRCtwcTQ3VjZXZXU1SzJZa1NSS04xWEpsTHVDSkNma1RsRHdZdlpBWUtsRG41ZldwOEJJclF2N2E0Zk01VXh3Wkw1MWdXcmhFeVZrb0VubnM4VlVWam85QnVyT1ZuenpXNnlKTVUiLCJtYWMiOiI4MjliYjAyZGZjMGVkY2RjN2ExOTVkZjUwNmIzOGU1NmRiY2I3ZmY0ODRjYzAxMGQ0Yzk4ODUxMDRlNzk5YTZiIiwidGFnIjoiIn0%3D\",\"cf-ray\":\"8e49231ac9cb3bcb-WAW\",\"x-original-uri\":\"\\/tasks\",\"x-forwarded-port\":\"80\",\"x-forwarded-ssl\":\"on\",\"x-forwarded-proto\":\"https\",\"x-forwarded-host\":\"panel.fuckrkn.club\",\"x-forwarded-for\":\"78.140.201.150, 162.158.103.36\",\"x-real-ip\":\"162.158.103.36\",\"connection\":\"close\",\"host\":\"panel.fuckrkn.club\"},\"payload\":[],\"session\":{\"_token\":\"5Nv1rfoy5TCJOZKulAgTB1ZJJBOIk4YAULutMi5T\",\"_previous\":{\"url\":\"http:\\/\\/panel.fuckrkn.club\\/tasks\"},\"_flash\":{\"old\":[],\"new\":[]},\"login_web_59ba36addc2b2f9401580f014c7f58ea4e30989d\":1,\"auth\":{\"password_confirmed_at\":1731945188}},\"response_status\":200,\"response\":{\"view\":\"\\/var\\/www\\/html\\/resources\\/views\\/tasks.blade.php\",\"data\":[]},\"duration\":195,\"memory\":24,\"hostname\":\"e4985f5898dd\",\"user\":{\"id\":1,\"name\":\"test1\",\"email\":\"test1@test1.com\"}}','2024-11-18 15:54:06'),
(38,'9d84fe1e-939e-4d20-9190-a81894658d7b','9d84fe1e-f2c3-4e95-9d9f-c1d8bb22a162',NULL,1,'query','{\"connection\":\"mysql\",\"bindings\":[],\"sql\":\"select * from `users` where `id` = 1 limit 1\",\"time\":\"2.74\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/public\\/index.php\",\"line\":54,\"hash\":\"082e27d9c4fc4a40315cae2c646c0509\",\"hostname\":\"e4985f5898dd\"}','2024-11-18 15:54:06'),
(39,'9d84fe1e-953a-410c-85ad-617ac2baff68','9d84fe1e-f2c3-4e95-9d9f-c1d8bb22a162',NULL,1,'model','{\"action\":\"retrieved\",\"model\":\"App\\\\Models\\\\User\",\"count\":1,\"hostname\":\"e4985f5898dd\"}','2024-11-18 15:54:06'),
(40,'9d84fe1e-f012-4bc1-93b8-4cc017fd39ad','9d84fe1e-f2c3-4e95-9d9f-c1d8bb22a162',NULL,1,'client_request','{\"method\":\"POST\",\"uri\":\"https:\\/\\/x.fuckrkn.club\\/api\\/tasks\\/serverside\\/\",\"headers\":{\"content-length\":\"1607\",\"user-agent\":\"GuzzleHttp\\/7\",\"content-type\":\"application\\/json\",\"host\":\"x.fuckrkn.club\"},\"payload\":{\"draw\":\"1\",\"columns\":[{\"data\":\"0\",\"name\":\"id\",\"searchable\":\"true\",\"orderable\":\"true\",\"search\":{\"value\":null,\"regex\":\"false\"}},{\"data\":\"1\",\"name\":\"unit_id\",\"searchable\":\"true\",\"orderable\":\"true\",\"search\":{\"value\":null,\"regex\":\"false\"}},{\"data\":\"2\",\"name\":\"status\",\"searchable\":\"true\",\"orderable\":\"true\",\"search\":{\"value\":null,\"regex\":\"false\"}},{\"data\":\"3\",\"name\":\"type\",\"searchable\":\"true\",\"orderable\":\"true\",\"search\":{\"value\":null,\"regex\":\"false\"}},{\"data\":\"4\",\"name\":\"attempts\",\"searchable\":\"true\",\"orderable\":\"true\",\"search\":{\"value\":null,\"regex\":\"false\"}},{\"data\":\"5\",\"name\":\"delay_min\",\"searchable\":\"true\",\"orderable\":\"true\",\"search\":{\"value\":null,\"regex\":\"false\"}},{\"data\":\"6\",\"name\":\"delay_max\",\"searchable\":\"true\",\"orderable\":\"true\",\"search\":{\"value\":null,\"regex\":\"false\"}},{\"data\":\"7\",\"name\":\"app_name\",\"searchable\":\"true\",\"orderable\":\"true\",\"search\":{\"value\":null,\"regex\":\"false\"}},{\"data\":\"8\",\"name\":\"app_bundle\",\"searchable\":\"true\",\"orderable\":\"true\",\"search\":{\"value\":null,\"regex\":\"false\"}},{\"data\":\"9\",\"name\":\"delete\",\"searchable\":\"true\",\"orderable\":\"true\",\"search\":{\"value\":null,\"regex\":\"false\"}},{\"data\":\"10\",\"name\":\"minutes\",\"searchable\":\"true\",\"orderable\":\"true\",\"search\":{\"value\":null,\"regex\":\"false\"}},{\"data\":\"11\",\"name\":\"seconds\",\"searchable\":\"true\",\"orderable\":\"true\",\"search\":{\"value\":null,\"regex\":\"false\"}},{\"data\":\"12\",\"name\":\"like\",\"searchable\":\"true\",\"orderable\":\"true\",\"search\":{\"value\":null,\"regex\":\"false\"}}],\"order\":[{\"column\":\"0\",\"dir\":\"asc\",\"name\":\"id\"}],\"start\":\"0\",\"length\":\"25\",\"search\":{\"value\":null,\"regex\":\"false\"},\"_token\":\"5Nv1rfoy5TCJOZKulAgTB1ZJJBOIk4YAULutMi5T\"},\"response_status\":200,\"response_headers\":{\"date\":\"Mon, 18 Nov 2024 15:54:06 GMT\",\"content-type\":\"application\\/json\",\"transfer-encoding\":\"chunked\",\"connection\":\"keep-alive\",\"x-powered-by\":\"PHP\\/8.3.9\",\"cache-control\":\"no-cache, private\",\"access-control-allow-origin\":\"*\",\"cf-cache-status\":\"DYNAMIC\",\"report-to\":\"{\\\"endpoints\\\":[{\\\"url\\\":\\\"https:\\\\\\/\\\\\\/a.nel.cloudflare.com\\\\\\/report\\\\\\/v4?s=tLLcOI44rZe5xkjKOaW3ToZ8NDDYXOv%2FXPJZ9DoDMx56NJNx1%2FE%2FosAPCL7dW0tGQE2stcq0Axz6ysjszfIUHCqOpKefNu5C0wOJldNr1Rn4xMfZAS1t2e%2BjRMAfvVYdug%3D%3D\\\"}],\\\"group\\\":\\\"cf-nel\\\",\\\"max_age\\\":604800}\",\"nel\":\"{\\\"success_fraction\\\":0,\\\"report_to\\\":\\\"cf-nel\\\",\\\"max_age\\\":604800}\",\"server\":\"cloudflare\",\"cf-ray\":\"8e49231fb953b75a-AMS\",\"alt-svc\":\"h3=\\\":443\\\"; ma=86400\",\"server-timing\":\"cfL4;desc=\\\"?proto=TCP&rtt=1236&sent=4&recv=7&lost=0&retrans=0&sent_bytes=2842&recv_bytes=2368&delivery_rate=3013527&cwnd=250&unsent_bytes=0&cid=14434fb8de1234d0&ts=205&x=0\\\"\"},\"response\":{\"draw\":\"1\",\"recordsTotal\":4200,\"recordsFiltered\":4200,\"currentPage\":1,\"data\":[[9968,51,\"running\",\"install\",2,1,4,\"AI Chat 4 & Ask AI Chatbot GPT\",\"chat.gpt.open.ai\",0,1,23,0],[9969,57,\"failed\",\"install\",2,1,4,\"AI Chat 4 & Ask AI Chatbot GPT\",\"chat.gpt.open.ai\",0,1,23,0],[9970,52,\"failed\",\"install\",2,1,4,\"AI Chat 4 & Ask AI Chatbot GPT\",\"chat.gpt.open.ai\",0,1,23,0],[9971,55,\"failed\",\"install\",2,1,4,\"AI Chat 4 & Ask AI Chatbot GPT\",\"chat.gpt.open.ai\",0,1,23,0],[9972,51,\"done\",\"install\",2,1,4,\"AI Chat 4 & Ask AI Chatbot GPT\",\"chat.gpt.open.ai\",0,1,23,0],[9973,51,\"done\",\"install\",2,1,4,\"AI Chat 4 & Ask AI Chatbot GPT\",\"chat.gpt.open.ai\",0,1,23,0],[9974,52,\"failed\",\"install\",2,1,4,\"AI Chat 4 & Ask AI Chatbot GPT\",\"chat.gpt.open.ai\",0,1,23,0],[9975,51,\"done\",\"install\",2,1,4,\"AI Chat 4 & Ask AI Chatbot GPT\",\"chat.gpt.open.ai\",0,1,23,0],[9976,51,\"done\",\"install\",2,1,4,\"AI Chat 4 & Ask AI Chatbot GPT\",\"chat.gpt.open.ai\",0,1,23,0],[9977,56,\"failed\",\"install\",2,1,4,\"AI Chat 4 & Ask AI Chatbot GPT\",\"chat.gpt.open.ai\",0,1,23,0],[9978,60,\"failed\",\"install\",2,1,4,\"AI Chat 4 & Ask AI Chatbot GPT\",\"chat.gpt.open.ai\",0,1,23,0],[9979,51,\"failed\",\"install\",2,1,4,\"AI Chat 4 & Ask AI Chatbot GPT\",\"chat.gpt.open.ai\",0,1,23,0],[9980,60,\"failed\",\"install\",2,1,4,\"AI Chat 4 & Ask AI Chatbot GPT\",\"chat.gpt.open.ai\",0,1,23,0],[9981,51,\"done\",\"install\",2,1,4,\"AI Chat 4 & Ask AI Chatbot GPT\",\"chat.gpt.open.ai\",0,1,23,0],[9982,51,\"running\",\"install\",2,1,4,\"AI Chat 4 & Ask AI Chatbot GPT\",\"chat.gpt.open.ai\",0,1,23,0],[9983,58,\"failed\",\"install\",2,1,4,\"AI Chat 4 & Ask AI Chatbot GPT\",\"chat.gpt.open.ai\",0,1,23,0],[9984,54,\"failed\",\"install\",2,1,4,\"AI Chat 4 & Ask AI Chatbot GPT\",\"chat.gpt.open.ai\",0,1,23,0],[9985,54,\"failed\",\"install\",2,1,4,\"AI Chat 4 & Ask AI Chatbot GPT\",\"chat.gpt.open.ai\",0,1,23,0],[9986,59,\"running\",\"install\",2,1,4,\"AI Chat 4 & Ask AI Chatbot GPT\",\"chat.gpt.open.ai\",0,1,23,0],[9987,52,\"failed\",\"install\",2,1,4,\"AI Chat 4 & Ask AI Chatbot GPT\",\"chat.gpt.open.ai\",0,1,23,0],[9988,58,\"failed\",\"install\",2,1,4,\"AI Chat 4 & Ask AI Chatbot GPT\",\"chat.gpt.open.ai\",0,1,23,0],[9989,52,\"failed\",\"install\",2,1,4,\"AI Chat 4 & Ask AI Chatbot GPT\",\"chat.gpt.open.ai\",0,1,23,0],[9990,56,\"failed\",\"install\",2,1,4,\"AI Chat 4 & Ask AI Chatbot GPT\",\"chat.gpt.open.ai\",0,1,23,0],[9991,55,\"failed\",\"install\",2,1,4,\"AI Chat 4 & Ask AI Chatbot GPT\",\"chat.gpt.open.ai\",0,1,23,0],[9992,51,\"done\",\"install\",2,1,4,\"AI Chat 4 & Ask AI Chatbot GPT\",\"chat.gpt.open.ai\",0,1,23,0]]},\"duration\":217,\"hostname\":\"e4985f5898dd\",\"user\":{\"id\":1,\"name\":\"test1\",\"email\":\"test1@test1.com\"}}','2024-11-18 15:54:06'),
(41,'9d84fe1e-f1cd-44e8-b148-505dd77e5400','9d84fe1e-f2c3-4e95-9d9f-c1d8bb22a162',NULL,1,'request','{\"ip_address\":\"172.21.0.6\",\"uri\":\"\\/tasks\\/serverside\",\"method\":\"POST\",\"controller_action\":\"App\\\\Http\\\\Controllers\\\\TaskController@serverside\",\"middleware\":[\"web\",\"auth\"],\"headers\":{\"origin\":\"https:\\/\\/panel.fuckrkn.club\",\"x-requested-with\":\"XMLHttpRequest\",\"content-type\":\"application\\/x-www-form-urlencoded; charset=UTF-8\",\"accept-language\":\"en-US,ru;q=0.7,en;q=0.3\",\"accept\":\"application\\/json, text\\/javascript, *\\/*; q=0.01\",\"user-agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64; rv:132.0) Gecko\\/20100101 Firefox\\/132.0\",\"dnt\":\"1\",\"sec-gpc\":\"1\",\"cdn-loop\":\"cloudflare; loops=1\",\"cf-connecting-ip\":\"78.140.201.150\",\"referer\":\"https:\\/\\/panel.fuckrkn.club\\/tasks\",\"sec-fetch-dest\":\"empty\",\"cf-visitor\":\"{\\\"scheme\\\":\\\"https\\\"}\",\"sec-fetch-mode\":\"cors\",\"sec-fetch-site\":\"same-origin\",\"accept-encoding\":\"gzip, br\",\"cf-ipcountry\":\"RU\",\"cookie\":\"XSRF-TOKEN=eyJpdiI6IjBmdE03a0pXYVVJTXFyVC85bkRyNXc9PSIsInZhbHVlIjoiY1MwQjVyQkdXRGQxb3p4c0xIeDdQcEZxdDZ1d283clB2NEcrTnMrUkJlWU5xbHFkbCsydWx3NWtXbyt1QlpHeXAxZ3hjeGpqbXdpdmV6OThLaCtjYnV0UUFBaDI5V0NBNHc1dkNVdXNlWEN3MHpjQWswNW9IVnBDaTVtL3h0UjIiLCJtYWMiOiI0MWQxYjNhYjkxNzNlNzk4ZTJiYTIyMjQ5MWJjNzMzZmU2MTQxMDIxN2RlNjI4MmQ1NTc4MDIyM2RlNzdmN2E5IiwidGFnIjoiIn0%3D; xloving_panel_session=eyJpdiI6IkxPek9hajlMWVJsK3h4WDNqVSt0Z1E9PSIsInZhbHVlIjoiQklWekg0UlpqVFZUMHNJNU55TmF1QitHWUorZHBDS0ZCemNsbnhTQU1ZTkEzV1ErTk1CNWtsWVBibERMT1FPaDBqbnRYRjRPL3JnbGhMcmtBa2VzeUI0UG1hSGxsNHRraWlVNFdwQWc1UDVvVXBYaHdDT2tFZHJ0RHE2WkpXNFQiLCJtYWMiOiJhMDlmYjM5ODVjNDg0ZDBhZWI1YjkwZDA0ZTE1ZjRiOWQyZWY2MjM1ODQzNGU3YmQ5ZTU4ZGY1ODk4NjcwMjg5IiwidGFnIjoiIn0%3D\",\"cf-ray\":\"8e49231e4fff3bcb-WAW\",\"content-length\":\"2993\",\"x-original-uri\":\"\\/tasks\\/serverside\",\"x-forwarded-port\":\"80\",\"x-forwarded-ssl\":\"on\",\"x-forwarded-proto\":\"https\",\"x-forwarded-host\":\"panel.fuckrkn.club\",\"x-forwarded-for\":\"78.140.201.150, 162.158.103.35\",\"x-real-ip\":\"162.158.103.35\",\"connection\":\"close\",\"host\":\"panel.fuckrkn.club\"},\"payload\":{\"draw\":\"1\",\"columns\":[{\"data\":\"0\",\"name\":\"id\",\"searchable\":\"true\",\"orderable\":\"true\",\"search\":{\"value\":null,\"regex\":\"false\"}},{\"data\":\"1\",\"name\":\"unit_id\",\"searchable\":\"true\",\"orderable\":\"true\",\"search\":{\"value\":null,\"regex\":\"false\"}},{\"data\":\"2\",\"name\":\"status\",\"searchable\":\"true\",\"orderable\":\"true\",\"search\":{\"value\":null,\"regex\":\"false\"}},{\"data\":\"3\",\"name\":\"type\",\"searchable\":\"true\",\"orderable\":\"true\",\"search\":{\"value\":null,\"regex\":\"false\"}},{\"data\":\"4\",\"name\":\"attempts\",\"searchable\":\"true\",\"orderable\":\"true\",\"search\":{\"value\":null,\"regex\":\"false\"}},{\"data\":\"5\",\"name\":\"delay_min\",\"searchable\":\"true\",\"orderable\":\"true\",\"search\":{\"value\":null,\"regex\":\"false\"}},{\"data\":\"6\",\"name\":\"delay_max\",\"searchable\":\"true\",\"orderable\":\"true\",\"search\":{\"value\":null,\"regex\":\"false\"}},{\"data\":\"7\",\"name\":\"app_name\",\"searchable\":\"true\",\"orderable\":\"true\",\"search\":{\"value\":null,\"regex\":\"false\"}},{\"data\":\"8\",\"name\":\"app_bundle\",\"searchable\":\"true\",\"orderable\":\"true\",\"search\":{\"value\":null,\"regex\":\"false\"}},{\"data\":\"9\",\"name\":\"delete\",\"searchable\":\"true\",\"orderable\":\"true\",\"search\":{\"value\":null,\"regex\":\"false\"}},{\"data\":\"10\",\"name\":\"minutes\",\"searchable\":\"true\",\"orderable\":\"true\",\"search\":{\"value\":null,\"regex\":\"false\"}},{\"data\":\"11\",\"name\":\"seconds\",\"searchable\":\"true\",\"orderable\":\"true\",\"search\":{\"value\":null,\"regex\":\"false\"}},{\"data\":\"12\",\"name\":\"like\",\"searchable\":\"true\",\"orderable\":\"true\",\"search\":{\"value\":null,\"regex\":\"false\"}}],\"order\":[{\"column\":\"0\",\"dir\":\"asc\",\"name\":\"id\"}],\"start\":\"0\",\"length\":\"25\",\"search\":{\"value\":null,\"regex\":\"false\"},\"_token\":\"5Nv1rfoy5TCJOZKulAgTB1ZJJBOIk4YAULutMi5T\"},\"session\":{\"_token\":\"5Nv1rfoy5TCJOZKulAgTB1ZJJBOIk4YAULutMi5T\",\"_previous\":{\"url\":\"http:\\/\\/panel.fuckrkn.club\\/tasks\"},\"_flash\":{\"old\":[],\"new\":[]},\"login_web_59ba36addc2b2f9401580f014c7f58ea4e30989d\":1,\"auth\":{\"password_confirmed_at\":1731945188}},\"response_status\":200,\"response\":{\"draw\":\"1\",\"recordsTotal\":4200,\"recordsFiltered\":4200,\"currentPage\":1,\"data\":[[9968,51,\"running\",\"install\",2,1,4,\"AI Chat 4 & Ask AI Chatbot GPT\",\"chat.gpt.open.ai\",0,1,23,0],[9969,57,\"failed\",\"install\",2,1,4,\"AI Chat 4 & Ask AI Chatbot GPT\",\"chat.gpt.open.ai\",0,1,23,0],[9970,52,\"failed\",\"install\",2,1,4,\"AI Chat 4 & Ask AI Chatbot GPT\",\"chat.gpt.open.ai\",0,1,23,0],[9971,55,\"failed\",\"install\",2,1,4,\"AI Chat 4 & Ask AI Chatbot GPT\",\"chat.gpt.open.ai\",0,1,23,0],[9972,51,\"done\",\"install\",2,1,4,\"AI Chat 4 & Ask AI Chatbot GPT\",\"chat.gpt.open.ai\",0,1,23,0],[9973,51,\"done\",\"install\",2,1,4,\"AI Chat 4 & Ask AI Chatbot GPT\",\"chat.gpt.open.ai\",0,1,23,0],[9974,52,\"failed\",\"install\",2,1,4,\"AI Chat 4 & Ask AI Chatbot GPT\",\"chat.gpt.open.ai\",0,1,23,0],[9975,51,\"done\",\"install\",2,1,4,\"AI Chat 4 & Ask AI Chatbot GPT\",\"chat.gpt.open.ai\",0,1,23,0],[9976,51,\"done\",\"install\",2,1,4,\"AI Chat 4 & Ask AI Chatbot GPT\",\"chat.gpt.open.ai\",0,1,23,0],[9977,56,\"failed\",\"install\",2,1,4,\"AI Chat 4 & Ask AI Chatbot GPT\",\"chat.gpt.open.ai\",0,1,23,0],[9978,60,\"failed\",\"install\",2,1,4,\"AI Chat 4 & Ask AI Chatbot GPT\",\"chat.gpt.open.ai\",0,1,23,0],[9979,51,\"failed\",\"install\",2,1,4,\"AI Chat 4 & Ask AI Chatbot GPT\",\"chat.gpt.open.ai\",0,1,23,0],[9980,60,\"failed\",\"install\",2,1,4,\"AI Chat 4 & Ask AI Chatbot GPT\",\"chat.gpt.open.ai\",0,1,23,0],[9981,51,\"done\",\"install\",2,1,4,\"AI Chat 4 & Ask AI Chatbot GPT\",\"chat.gpt.open.ai\",0,1,23,0],[9982,51,\"running\",\"install\",2,1,4,\"AI Chat 4 & Ask AI Chatbot GPT\",\"chat.gpt.open.ai\",0,1,23,0],[9983,58,\"failed\",\"install\",2,1,4,\"AI Chat 4 & Ask AI Chatbot GPT\",\"chat.gpt.open.ai\",0,1,23,0],[9984,54,\"failed\",\"install\",2,1,4,\"AI Chat 4 & Ask AI Chatbot GPT\",\"chat.gpt.open.ai\",0,1,23,0],[9985,54,\"failed\",\"install\",2,1,4,\"AI Chat 4 & Ask AI Chatbot GPT\",\"chat.gpt.open.ai\",0,1,23,0],[9986,59,\"running\",\"install\",2,1,4,\"AI Chat 4 & Ask AI Chatbot GPT\",\"chat.gpt.open.ai\",0,1,23,0],[9987,52,\"failed\",\"install\",2,1,4,\"AI Chat 4 & Ask AI Chatbot GPT\",\"chat.gpt.open.ai\",0,1,23,0],[9988,58,\"failed\",\"install\",2,1,4,\"AI Chat 4 & Ask AI Chatbot GPT\",\"chat.gpt.open.ai\",0,1,23,0],[9989,52,\"failed\",\"install\",2,1,4,\"AI Chat 4 & Ask AI Chatbot GPT\",\"chat.gpt.open.ai\",0,1,23,0],[9990,56,\"failed\",\"install\",2,1,4,\"AI Chat 4 & Ask AI Chatbot GPT\",\"chat.gpt.open.ai\",0,1,23,0],[9991,55,\"failed\",\"install\",2,1,4,\"AI Chat 4 & Ask AI Chatbot GPT\",\"chat.gpt.open.ai\",0,1,23,0],[9992,51,\"done\",\"install\",2,1,4,\"AI Chat 4 & Ask AI Chatbot GPT\",\"chat.gpt.open.ai\",0,1,23,0]]},\"duration\":374,\"memory\":24,\"hostname\":\"e4985f5898dd\",\"user\":{\"id\":1,\"name\":\"test1\",\"email\":\"test1@test1.com\"}}','2024-11-18 15:54:06'),
(42,'9d84fe5e-f879-46f4-bb61-3a2ef79d1af9','9d84fe5f-00e7-414b-809c-913e8a395005',NULL,1,'query','{\"connection\":\"mysql\",\"bindings\":[],\"sql\":\"select * from `users` where `id` = 1 limit 1\",\"time\":\"3.09\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/public\\/index.php\",\"line\":54,\"hash\":\"082e27d9c4fc4a40315cae2c646c0509\",\"hostname\":\"e4985f5898dd\"}','2024-11-18 15:54:48'),
(43,'9d84fe5e-f9df-4c6e-93c2-6563bfcd16ab','9d84fe5f-00e7-414b-809c-913e8a395005',NULL,1,'model','{\"action\":\"retrieved\",\"model\":\"App\\\\Models\\\\User\",\"count\":1,\"hostname\":\"e4985f5898dd\"}','2024-11-18 15:54:48'),
(44,'9d84fe5e-fda4-4f41-adcb-552d8c43935a','9d84fe5f-00e7-414b-809c-913e8a395005',NULL,1,'query','{\"connection\":\"mysql\",\"bindings\":[],\"sql\":\"update `users` set `remember_token` = \'UghU92ybS2LDPxRMsRKql7TE3J0wkhFGBt1eadSopf8B5Pq8xpDbjhtl0dln\' where `id` = 1\",\"time\":\"7.65\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/public\\/index.php\",\"line\":54,\"hash\":\"1eab729439e0f145c5114c62e258cb81\",\"hostname\":\"e4985f5898dd\",\"user\":{\"id\":1,\"name\":\"test1\",\"email\":\"test1@test1.com\"}}','2024-11-18 15:54:48'),
(45,'9d84fe5e-fdf2-42ef-80b4-19d98825d52e','9d84fe5f-00e7-414b-809c-913e8a395005',NULL,1,'model','{\"action\":\"updated\",\"model\":\"App\\\\Models\\\\User:1\",\"changes\":{\"remember_token\":\"UghU92ybS2LDPxRMsRKql7TE3J0wkhFGBt1eadSopf8B5Pq8xpDbjhtl0dln\"},\"hostname\":\"e4985f5898dd\",\"user\":{\"id\":1,\"name\":\"test1\",\"email\":\"test1@test1.com\"}}','2024-11-18 15:54:48'),
(46,'9d84fe5e-fffd-4c79-a76d-a5d0053e76dd','9d84fe5f-00e7-414b-809c-913e8a395005',NULL,1,'request','{\"ip_address\":\"172.21.0.6\",\"uri\":\"\\/logout\",\"method\":\"POST\",\"controller_action\":\"App\\\\Http\\\\Controllers\\\\Auth\\\\LoginController@logout\",\"middleware\":[\"web\"],\"headers\":{\"referer\":\"https:\\/\\/panel.fuckrkn.club\\/tasks\",\"sec-gpc\":\"1\",\"dnt\":\"1\",\"origin\":\"https:\\/\\/panel.fuckrkn.club\",\"content-type\":\"application\\/x-www-form-urlencoded\",\"accept-language\":\"en-US,ru;q=0.7,en;q=0.3\",\"accept\":\"text\\/html,application\\/xhtml+xml,application\\/xml;q=0.9,*\\/*;q=0.8\",\"user-agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64; rv:132.0) Gecko\\/20100101 Firefox\\/132.0\",\"upgrade-insecure-requests\":\"1\",\"sec-fetch-dest\":\"document\",\"cdn-loop\":\"cloudflare; loops=1\",\"cf-connecting-ip\":\"78.140.201.150\",\"sec-fetch-mode\":\"navigate\",\"sec-fetch-site\":\"same-origin\",\"cf-visitor\":\"{\\\"scheme\\\":\\\"https\\\"}\",\"sec-fetch-user\":\"?1\",\"priority\":\"u=0, i\",\"accept-encoding\":\"gzip, br\",\"cf-ipcountry\":\"RU\",\"cookie\":\"XSRF-TOKEN=eyJpdiI6Ik03bmNIMklCN09xZ1ExVkcrTUVsYlE9PSIsInZhbHVlIjoiUGg1bEorMFdxTkhoQytWT1BHY2JpU2EraXE3UE5uSnJLUFNJNGpxcWhhUnU4TmdpbVRWWHRzaGdma2VuaXpyTmNXRzEwZFRCcEFzc2J0UW5oL1JKMTVzbzNHT1FKWGt0VCsrem1aS1o1MzdhbVZhR2l0R0N2L3pkbzREK3dFSTQiLCJtYWMiOiI4YTUzZWI5ZGUwYmQ5MmQyYTU0MTQ4ZTg5MTQ5NzA4YzM4MDQxMWI0NjY3NzUxNzIxZDQ0YTVmNGU1YzhkNDBhIiwidGFnIjoiIn0%3D; xloving_panel_session=eyJpdiI6IkRuWFp1cUQ3dERoZmhFTHBoM0ZldWc9PSIsInZhbHVlIjoiK1pYT3NCdnZwVEtDdEhuQ04rNHV4TlIvV3NRRUV1VkJ0eEEzd2VSNVBzS1hCV1hKVmMwZitsV2dXQUJzblZ2c1Z5UVZxNFRzbjl3bDh4ZGdHMTI4ZVBiMi9lamVkdklzU2g0Ri9xMnMvOW1BUXg3N2RWZUt4UzR0M0ZlOCtPZjgiLCJtYWMiOiI2YzA3NWIyYjJkYWJkYmE4YTUzOWY2MTk5NjhkZmJiMzZmMWRiNTA2Zjg5YTFmYTYyM2Q0YWUxNTI2ODk0ZTA4IiwidGFnIjoiIn0%3D\",\"cf-ray\":\"8e492425ed783bcb-WAW\",\"content-length\":\"47\",\"x-original-uri\":\"\\/logout\",\"x-forwarded-port\":\"80\",\"x-forwarded-ssl\":\"on\",\"x-forwarded-proto\":\"https\",\"x-forwarded-host\":\"panel.fuckrkn.club\",\"x-forwarded-for\":\"78.140.201.150, 162.158.103.35\",\"x-real-ip\":\"162.158.103.35\",\"connection\":\"close\",\"host\":\"panel.fuckrkn.club\"},\"payload\":{\"_token\":\"5Nv1rfoy5TCJOZKulAgTB1ZJJBOIk4YAULutMi5T\"},\"session\":{\"_token\":\"1AxEjuiyjk47NerEt3zuyKpiMmrTv6gRNq8OYfLT\",\"_flash\":{\"old\":[],\"new\":[]}},\"response_status\":302,\"response\":\"Redirected to http:\\/\\/panel.fuckrkn.club\",\"duration\":164,\"memory\":22,\"hostname\":\"e4985f5898dd\"}','2024-11-18 15:54:48'),
(47,'9d84fe5f-80a1-44f4-bfe5-6b54f8113c1b','9d84fe5f-842c-49a2-88bb-becc5c043a0f',NULL,1,'view','{\"name\":\"welcome\",\"path\":\"\\/resources\\/views\\/welcome.blade.php\",\"data\":[],\"hostname\":\"e4985f5898dd\"}','2024-11-18 15:54:49'),
(48,'9d84fe5f-8339-461a-ac4e-e1134c9edb2e','9d84fe5f-842c-49a2-88bb-becc5c043a0f',NULL,1,'request','{\"ip_address\":\"172.21.0.6\",\"uri\":\"\\/\",\"method\":\"GET\",\"controller_action\":\"Closure\",\"middleware\":[\"web\"],\"headers\":{\"sec-gpc\":\"1\",\"dnt\":\"1\",\"accept-language\":\"en-US,ru;q=0.7,en;q=0.3\",\"accept\":\"text\\/html,application\\/xhtml+xml,application\\/xml;q=0.9,*\\/*;q=0.8\",\"user-agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64; rv:132.0) Gecko\\/20100101 Firefox\\/132.0\",\"upgrade-insecure-requests\":\"1\",\"sec-fetch-dest\":\"document\",\"cdn-loop\":\"cloudflare; loops=1\",\"cf-connecting-ip\":\"78.140.201.150\",\"sec-fetch-mode\":\"navigate\",\"sec-fetch-site\":\"cross-site\",\"cf-visitor\":\"{\\\"scheme\\\":\\\"https\\\"}\",\"sec-fetch-user\":\"?1\",\"priority\":\"u=0, i\",\"accept-encoding\":\"gzip, br\",\"cf-ipcountry\":\"RU\",\"cookie\":\"XSRF-TOKEN=eyJpdiI6IkFNVmhWc20vUG5IWFRaWXBlT0N1QUE9PSIsInZhbHVlIjoib2JEVCtNN3VTK3p3SWJ1UVZiUS81NXpOK0gxY2U1cEoxTVdWaHM1STM2WmQ2QlZPMS9EMDhzaXpwMGtEK3g1U1pnVVNtdTdrVmxLN291SDA5MkxMSzVIdmNBU1oxODh3WUM0L0tlMzJseVRxYzhob3ZQakxJdDkwdEk5YXE0WEciLCJtYWMiOiI4MTU1YzYyYjRlY2VjMGQ0ODljNWI4MmExOTEwMTVlMGQ5M2FjODk2OGViZjllMzc2MDczMzQ5NzQ0NTdiMDYzIiwidGFnIjoiIn0%3D; xloving_panel_session=eyJpdiI6IjJYZ3FsQnMxTEdZcmJYQ2tLb3RFcXc9PSIsInZhbHVlIjoickFRYytlT3VPYmVJQ3llNVJTWkozekRweUdvZ1hsNER2dWcxZFZiTm9BdzBteWRRK3J5ZlBONmZuKzlSRldwZ09ydWNqUVYwR1pldi8wRGhLVnRBWlVCdEtWdEZoVXR2aFByWStvWHhWNTdTdkkwbzVYUld2emNrVFVDYTZKNFoiLCJtYWMiOiI5M2RiZWY2OWRjZGM1Nzk1YTY3MmRkZDdlNDhkMDhlMmY5MzgyMjFjMDc0N2IxYWFkY2NmYTZiMjg1ZTk5YjczIiwidGFnIjoiIn0%3D\",\"cf-ray\":\"8e49242828df3bcb-WAW\",\"x-original-uri\":\"\\/\",\"x-forwarded-port\":\"80\",\"x-forwarded-ssl\":\"on\",\"x-forwarded-proto\":\"https\",\"x-forwarded-host\":\"panel.fuckrkn.club\",\"x-forwarded-for\":\"78.140.201.150, 162.158.103.36\",\"x-real-ip\":\"162.158.103.36\",\"connection\":\"close\",\"host\":\"panel.fuckrkn.club\"},\"payload\":[],\"session\":{\"_token\":\"1AxEjuiyjk47NerEt3zuyKpiMmrTv6gRNq8OYfLT\",\"_flash\":{\"old\":[],\"new\":[]},\"_previous\":{\"url\":\"http:\\/\\/panel.fuckrkn.club\"}},\"response_status\":200,\"response\":{\"view\":\"\\/var\\/www\\/html\\/resources\\/views\\/welcome.blade.php\",\"data\":[]},\"duration\":144,\"memory\":22,\"hostname\":\"e4985f5898dd\"}','2024-11-18 15:54:49');
/*!40000 ALTER TABLE `telescope_entries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `telescope_entries_tags`
--

DROP TABLE IF EXISTS `telescope_entries_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `telescope_entries_tags` (
  `entry_uuid` char(36) NOT NULL,
  `tag` varchar(255) NOT NULL,
  PRIMARY KEY (`entry_uuid`,`tag`),
  KEY `telescope_entries_tags_tag_index` (`tag`),
  CONSTRAINT `telescope_entries_tags_entry_uuid_foreign` FOREIGN KEY (`entry_uuid`) REFERENCES `telescope_entries` (`uuid`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `telescope_entries_tags`
--

LOCK TABLES `telescope_entries_tags` WRITE;
/*!40000 ALTER TABLE `telescope_entries_tags` DISABLE KEYS */;
INSERT INTO `telescope_entries_tags` VALUES
('9d84fdc5-7565-498a-a87f-bc57291843f6','App\\Models\\User'),
('9d84fdc6-59e8-4363-97a1-56ac1e955806','App\\Models\\User'),
('9d84fe1d-cd06-4c5c-a35a-2d80ab29f216','App\\Models\\User'),
('9d84fe1e-953a-410c-85ad-617ac2baff68','App\\Models\\User'),
('9d84fe5e-f9df-4c6e-93c2-6563bfcd16ab','App\\Models\\User'),
('9d84fe5e-fdf2-42ef-80b4-19d98825d52e','App\\Models\\User:1'),
('9d84fdc5-d832-431b-93e3-5a50b6d28e1c','Auth:1'),
('9d84fdc6-5b67-4798-9102-534868887dec','Auth:1'),
('9d84fdc6-5d83-4d4e-893b-ac2d09a78944','Auth:1'),
('9d84fdc6-5e4d-49b0-806e-6d7d8300dad1','Auth:1'),
('9d84fdc6-6115-4d01-b926-2f7813d61492','Auth:1'),
('9d84fe1d-cf8f-4ad9-b839-345ad6ed544e','Auth:1'),
('9d84fe1d-d062-4703-a98c-27298a1d9406','Auth:1'),
('9d84fe1d-d2ff-47f1-adc1-a4773fed9ba9','Auth:1'),
('9d84fe1e-f012-4bc1-93b8-4cc017fd39ad','Auth:1'),
('9d84fe1e-f1cd-44e8-b148-505dd77e5400','Auth:1'),
('9d84fe5e-fda4-4f41-adcb-552d8c43935a','Auth:1'),
('9d84fe5e-fdf2-42ef-80b4-19d98825d52e','Auth:1');
/*!40000 ALTER TABLE `telescope_entries_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `telescope_monitoring`
--

DROP TABLE IF EXISTS `telescope_monitoring`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `telescope_monitoring` (
  `tag` varchar(255) NOT NULL,
  PRIMARY KEY (`tag`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `telescope_monitoring`
--

LOCK TABLES `telescope_monitoring` WRITE;
/*!40000 ALTER TABLE `telescope_monitoring` DISABLE KEYS */;
/*!40000 ALTER TABLE `telescope_monitoring` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES
(1,'test1','test1','test1@test1.com',NULL,'$2y$12$ushXLqUtDFifVcCGEHGTqewTfFLPevhp/d6nDTU6.211qQIJGGXEa','FaydL1Y5Yn2fhh1lk59eElNaUu71a6fQ8GPud5VcsJMVHbDPvMubOCm0zvEw','2024-07-10 14:25:40','2024-07-10 14:25:40');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'xloving_panel'
--

--
-- Dumping routines for database 'xloving_panel'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-12-16 11:12:38
